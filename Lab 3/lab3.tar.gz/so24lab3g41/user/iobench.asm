
user/_iobench:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <io_ops>:
static char data[IO_OPSIZE];


int
io_ops()
{
   0:	7139                	addi	sp,sp,-64
   2:	fc06                	sd	ra,56(sp)
   4:	f822                	sd	s0,48(sp)
   6:	f426                	sd	s1,40(sp)
   8:	f04a                	sd	s2,32(sp)
   a:	ec4e                	sd	s3,24(sp)
   c:	0080                	addi	s0,sp,64
    int rfd, wfd;

    int pid = getpid();
   e:	00000097          	auipc	ra,0x0
  12:	4c4080e7          	jalr	1220(ra) # 4d2 <getpid>

    // Crear un path unico de archivo
    char path[] = "12iops";
  16:	6f6937b7          	lui	a5,0x6f693
  1a:	23178793          	addi	a5,a5,561 # 6f693231 <base+0x6f6921e1>
  1e:	fcf42423          	sw	a5,-56(s0)
  22:	679d                	lui	a5,0x7
  24:	37078793          	addi	a5,a5,880 # 7370 <base+0x6320>
  28:	fcf41623          	sh	a5,-52(s0)
  2c:	fc040723          	sb	zero,-50(s0)
    path[0] = '0' + (pid / 10);
  30:	4729                	li	a4,10
  32:	02e547bb          	divw	a5,a0,a4
  36:	0307879b          	addiw	a5,a5,48
  3a:	fcf40423          	sb	a5,-56(s0)
    path[1] = '0' + (pid % 10);
  3e:	02e567bb          	remw	a5,a0,a4
  42:	0307879b          	addiw	a5,a5,48
  46:	fcf404a3          	sb	a5,-55(s0)

    wfd = open(path, O_CREATE | O_WRONLY);
  4a:	20100593          	li	a1,513
  4e:	fc840513          	addi	a0,s0,-56
  52:	00000097          	auipc	ra,0x0
  56:	440080e7          	jalr	1088(ra) # 492 <open>
  5a:	892a                	mv	s2,a0
  5c:	20000493          	li	s1,512

    for(int i = 0; i < IO_EXPERIMENT_LEN; ++i){
      write(wfd, data, IO_OPSIZE);
  60:	00001997          	auipc	s3,0x1
  64:	fb098993          	addi	s3,s3,-80 # 1010 <data>
  68:	04000613          	li	a2,64
  6c:	85ce                	mv	a1,s3
  6e:	854a                	mv	a0,s2
  70:	00000097          	auipc	ra,0x0
  74:	402080e7          	jalr	1026(ra) # 472 <write>
    for(int i = 0; i < IO_EXPERIMENT_LEN; ++i){
  78:	34fd                	addiw	s1,s1,-1
  7a:	f4fd                	bnez	s1,68 <io_ops+0x68>
    }

    close(wfd);
  7c:	854a                	mv	a0,s2
  7e:	00000097          	auipc	ra,0x0
  82:	3fc080e7          	jalr	1020(ra) # 47a <close>

    rfd = open(path, O_RDONLY);
  86:	4581                	li	a1,0
  88:	fc840513          	addi	a0,s0,-56
  8c:	00000097          	auipc	ra,0x0
  90:	406080e7          	jalr	1030(ra) # 492 <open>
  94:	892a                	mv	s2,a0
  96:	20000493          	li	s1,512

    for(int i = 0; i < IO_EXPERIMENT_LEN; ++i){
      read(rfd, data, IO_OPSIZE);
  9a:	00001997          	auipc	s3,0x1
  9e:	f7698993          	addi	s3,s3,-138 # 1010 <data>
  a2:	04000613          	li	a2,64
  a6:	85ce                	mv	a1,s3
  a8:	854a                	mv	a0,s2
  aa:	00000097          	auipc	ra,0x0
  ae:	3c0080e7          	jalr	960(ra) # 46a <read>
    for(int i = 0; i < IO_EXPERIMENT_LEN; ++i){
  b2:	34fd                	addiw	s1,s1,-1
  b4:	f4fd                	bnez	s1,a2 <io_ops+0xa2>
    }

    close(rfd);
  b6:	854a                	mv	a0,s2
  b8:	00000097          	auipc	ra,0x0
  bc:	3c2080e7          	jalr	962(ra) # 47a <close>
    return 2 * IO_EXPERIMENT_LEN;
}
  c0:	40000513          	li	a0,1024
  c4:	70e2                	ld	ra,56(sp)
  c6:	7442                	ld	s0,48(sp)
  c8:	74a2                	ld	s1,40(sp)
  ca:	7902                	ld	s2,32(sp)
  cc:	69e2                	ld	s3,24(sp)
  ce:	6121                	addi	sp,sp,64
  d0:	8082                	ret

00000000000000d2 <iobench>:

void
iobench(int N, int pid)
{
  d2:	7139                	addi	sp,sp,-64
  d4:	fc06                	sd	ra,56(sp)
  d6:	f822                	sd	s0,48(sp)
  d8:	f426                	sd	s1,40(sp)
  da:	f04a                	sd	s2,32(sp)
  dc:	ec4e                	sd	s3,24(sp)
  de:	e852                	sd	s4,16(sp)
  e0:	e456                	sd	s5,8(sp)
  e2:	e05a                	sd	s6,0(sp)
  e4:	0080                	addi	s0,sp,64
  e6:	84aa                	mv	s1,a0
  e8:	8aae                	mv	s5,a1
  memset(data, 'a', sizeof(data));
  ea:	04000613          	li	a2,64
  ee:	06100593          	li	a1,97
  f2:	00001517          	auipc	a0,0x1
  f6:	f1e50513          	addi	a0,a0,-226 # 1010 <data>
  fa:	00000097          	auipc	ra,0x0
  fe:	15e080e7          	jalr	350(ra) # 258 <memset>
  uint64 start_tick, end_tick, elapsed_ticks, metric;
  int total_iops;

  int *measurements = malloc(sizeof(int) * N);
 102:	0024951b          	slliw	a0,s1,0x2
 106:	00000097          	auipc	ra,0x0
 10a:	77e080e7          	jalr	1918(ra) # 884 <malloc>

  for (int i = 0; i < N; i++){
 10e:	04905b63          	blez	s1,164 <iobench+0x92>
 112:	89aa                	mv	s3,a0
 114:	02049793          	slli	a5,s1,0x20
 118:	01e7d493          	srli	s1,a5,0x1e
 11c:	00950a33          	add	s4,a0,s1

    end_tick = uptime();
    elapsed_ticks = end_tick - start_tick;
    metric = total_iops / elapsed_ticks;  // Cambiar esto por la métrica adecuada
    measurements[i] = metric;
    printf("%d\t[iobench]\t%d\t%d\t%d\n",
 120:	00001b17          	auipc	s6,0x1
 124:	850b0b13          	addi	s6,s6,-1968 # 970 <malloc+0xec>
    start_tick = uptime();
 128:	00000097          	auipc	ra,0x0
 12c:	3c2080e7          	jalr	962(ra) # 4ea <uptime>
 130:	892a                	mv	s2,a0
    total_iops = io_ops();
 132:	00000097          	auipc	ra,0x0
 136:	ece080e7          	jalr	-306(ra) # 0 <io_ops>
 13a:	84aa                	mv	s1,a0
    end_tick = uptime();
 13c:	00000097          	auipc	ra,0x0
 140:	3ae080e7          	jalr	942(ra) # 4ea <uptime>
    elapsed_ticks = end_tick - start_tick;
 144:	41250733          	sub	a4,a0,s2
    metric = total_iops / elapsed_ticks;  // Cambiar esto por la métrica adecuada
 148:	02e4d633          	divu	a2,s1,a4
    measurements[i] = metric;
 14c:	00c9a023          	sw	a2,0(s3)
    printf("%d\t[iobench]\t%d\t%d\t%d\n",
 150:	86ca                	mv	a3,s2
 152:	85d6                	mv	a1,s5
 154:	855a                	mv	a0,s6
 156:	00000097          	auipc	ra,0x0
 15a:	676080e7          	jalr	1654(ra) # 7cc <printf>
  for (int i = 0; i < N; i++){
 15e:	0991                	addi	s3,s3,4
 160:	fd4994e3          	bne	s3,s4,128 <iobench+0x56>
           pid, metric, start_tick, elapsed_ticks);
  }
}
 164:	70e2                	ld	ra,56(sp)
 166:	7442                	ld	s0,48(sp)
 168:	74a2                	ld	s1,40(sp)
 16a:	7902                	ld	s2,32(sp)
 16c:	69e2                	ld	s3,24(sp)
 16e:	6a42                	ld	s4,16(sp)
 170:	6aa2                	ld	s5,8(sp)
 172:	6b02                	ld	s6,0(sp)
 174:	6121                	addi	sp,sp,64
 176:	8082                	ret

0000000000000178 <main>:

int
main(int argc, char *argv[])
{
 178:	1101                	addi	sp,sp,-32
 17a:	ec06                	sd	ra,24(sp)
 17c:	e822                	sd	s0,16(sp)
 17e:	e426                	sd	s1,8(sp)
 180:	1000                	addi	s0,sp,32
  int N, pid;
  if (argc != 2) {
 182:	4789                	li	a5,2
 184:	00f50f63          	beq	a0,a5,1a2 <main+0x2a>
    printf("Uso: benchmark N\n");
 188:	00001517          	auipc	a0,0x1
 18c:	80050513          	addi	a0,a0,-2048 # 988 <malloc+0x104>
 190:	00000097          	auipc	ra,0x0
 194:	63c080e7          	jalr	1596(ra) # 7cc <printf>
    exit(1);
 198:	4505                	li	a0,1
 19a:	00000097          	auipc	ra,0x0
 19e:	2b8080e7          	jalr	696(ra) # 452 <exit>
  }

  N = atoi(argv[1]);  // Número de repeticiones para los benchmarks
 1a2:	6588                	ld	a0,8(a1)
 1a4:	00000097          	auipc	ra,0x0
 1a8:	1b4080e7          	jalr	436(ra) # 358 <atoi>
 1ac:	84aa                	mv	s1,a0
  pid = getpid();
 1ae:	00000097          	auipc	ra,0x0
 1b2:	324080e7          	jalr	804(ra) # 4d2 <getpid>
 1b6:	85aa                	mv	a1,a0
  iobench(N, pid);
 1b8:	8526                	mv	a0,s1
 1ba:	00000097          	auipc	ra,0x0
 1be:	f18080e7          	jalr	-232(ra) # d2 <iobench>

  exit(0);
 1c2:	4501                	li	a0,0
 1c4:	00000097          	auipc	ra,0x0
 1c8:	28e080e7          	jalr	654(ra) # 452 <exit>

00000000000001cc <_main>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
_main()
{
 1cc:	1141                	addi	sp,sp,-16
 1ce:	e406                	sd	ra,8(sp)
 1d0:	e022                	sd	s0,0(sp)
 1d2:	0800                	addi	s0,sp,16
  extern int main();
  main();
 1d4:	00000097          	auipc	ra,0x0
 1d8:	fa4080e7          	jalr	-92(ra) # 178 <main>
  exit(0);
 1dc:	4501                	li	a0,0
 1de:	00000097          	auipc	ra,0x0
 1e2:	274080e7          	jalr	628(ra) # 452 <exit>

00000000000001e6 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 1e6:	1141                	addi	sp,sp,-16
 1e8:	e422                	sd	s0,8(sp)
 1ea:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 1ec:	87aa                	mv	a5,a0
 1ee:	0585                	addi	a1,a1,1
 1f0:	0785                	addi	a5,a5,1
 1f2:	fff5c703          	lbu	a4,-1(a1)
 1f6:	fee78fa3          	sb	a4,-1(a5)
 1fa:	fb75                	bnez	a4,1ee <strcpy+0x8>
    ;
  return os;
}
 1fc:	6422                	ld	s0,8(sp)
 1fe:	0141                	addi	sp,sp,16
 200:	8082                	ret

0000000000000202 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 202:	1141                	addi	sp,sp,-16
 204:	e422                	sd	s0,8(sp)
 206:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 208:	00054783          	lbu	a5,0(a0)
 20c:	cb91                	beqz	a5,220 <strcmp+0x1e>
 20e:	0005c703          	lbu	a4,0(a1)
 212:	00f71763          	bne	a4,a5,220 <strcmp+0x1e>
    p++, q++;
 216:	0505                	addi	a0,a0,1
 218:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 21a:	00054783          	lbu	a5,0(a0)
 21e:	fbe5                	bnez	a5,20e <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 220:	0005c503          	lbu	a0,0(a1)
}
 224:	40a7853b          	subw	a0,a5,a0
 228:	6422                	ld	s0,8(sp)
 22a:	0141                	addi	sp,sp,16
 22c:	8082                	ret

000000000000022e <strlen>:

uint
strlen(const char *s)
{
 22e:	1141                	addi	sp,sp,-16
 230:	e422                	sd	s0,8(sp)
 232:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 234:	00054783          	lbu	a5,0(a0)
 238:	cf91                	beqz	a5,254 <strlen+0x26>
 23a:	0505                	addi	a0,a0,1
 23c:	87aa                	mv	a5,a0
 23e:	4685                	li	a3,1
 240:	9e89                	subw	a3,a3,a0
 242:	00f6853b          	addw	a0,a3,a5
 246:	0785                	addi	a5,a5,1
 248:	fff7c703          	lbu	a4,-1(a5)
 24c:	fb7d                	bnez	a4,242 <strlen+0x14>
    ;
  return n;
}
 24e:	6422                	ld	s0,8(sp)
 250:	0141                	addi	sp,sp,16
 252:	8082                	ret
  for(n = 0; s[n]; n++)
 254:	4501                	li	a0,0
 256:	bfe5                	j	24e <strlen+0x20>

0000000000000258 <memset>:

void*
memset(void *dst, int c, uint n)
{
 258:	1141                	addi	sp,sp,-16
 25a:	e422                	sd	s0,8(sp)
 25c:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 25e:	ca19                	beqz	a2,274 <memset+0x1c>
 260:	87aa                	mv	a5,a0
 262:	1602                	slli	a2,a2,0x20
 264:	9201                	srli	a2,a2,0x20
 266:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 26a:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 26e:	0785                	addi	a5,a5,1
 270:	fee79de3          	bne	a5,a4,26a <memset+0x12>
  }
  return dst;
}
 274:	6422                	ld	s0,8(sp)
 276:	0141                	addi	sp,sp,16
 278:	8082                	ret

000000000000027a <strchr>:

char*
strchr(const char *s, char c)
{
 27a:	1141                	addi	sp,sp,-16
 27c:	e422                	sd	s0,8(sp)
 27e:	0800                	addi	s0,sp,16
  for(; *s; s++)
 280:	00054783          	lbu	a5,0(a0)
 284:	cb99                	beqz	a5,29a <strchr+0x20>
    if(*s == c)
 286:	00f58763          	beq	a1,a5,294 <strchr+0x1a>
  for(; *s; s++)
 28a:	0505                	addi	a0,a0,1
 28c:	00054783          	lbu	a5,0(a0)
 290:	fbfd                	bnez	a5,286 <strchr+0xc>
      return (char*)s;
  return 0;
 292:	4501                	li	a0,0
}
 294:	6422                	ld	s0,8(sp)
 296:	0141                	addi	sp,sp,16
 298:	8082                	ret
  return 0;
 29a:	4501                	li	a0,0
 29c:	bfe5                	j	294 <strchr+0x1a>

000000000000029e <gets>:

char*
gets(char *buf, int max)
{
 29e:	711d                	addi	sp,sp,-96
 2a0:	ec86                	sd	ra,88(sp)
 2a2:	e8a2                	sd	s0,80(sp)
 2a4:	e4a6                	sd	s1,72(sp)
 2a6:	e0ca                	sd	s2,64(sp)
 2a8:	fc4e                	sd	s3,56(sp)
 2aa:	f852                	sd	s4,48(sp)
 2ac:	f456                	sd	s5,40(sp)
 2ae:	f05a                	sd	s6,32(sp)
 2b0:	ec5e                	sd	s7,24(sp)
 2b2:	1080                	addi	s0,sp,96
 2b4:	8baa                	mv	s7,a0
 2b6:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 2b8:	892a                	mv	s2,a0
 2ba:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 2bc:	4aa9                	li	s5,10
 2be:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 2c0:	89a6                	mv	s3,s1
 2c2:	2485                	addiw	s1,s1,1
 2c4:	0344d863          	bge	s1,s4,2f4 <gets+0x56>
    cc = read(0, &c, 1);
 2c8:	4605                	li	a2,1
 2ca:	faf40593          	addi	a1,s0,-81
 2ce:	4501                	li	a0,0
 2d0:	00000097          	auipc	ra,0x0
 2d4:	19a080e7          	jalr	410(ra) # 46a <read>
    if(cc < 1)
 2d8:	00a05e63          	blez	a0,2f4 <gets+0x56>
    buf[i++] = c;
 2dc:	faf44783          	lbu	a5,-81(s0)
 2e0:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 2e4:	01578763          	beq	a5,s5,2f2 <gets+0x54>
 2e8:	0905                	addi	s2,s2,1
 2ea:	fd679be3          	bne	a5,s6,2c0 <gets+0x22>
  for(i=0; i+1 < max; ){
 2ee:	89a6                	mv	s3,s1
 2f0:	a011                	j	2f4 <gets+0x56>
 2f2:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 2f4:	99de                	add	s3,s3,s7
 2f6:	00098023          	sb	zero,0(s3)
  return buf;
}
 2fa:	855e                	mv	a0,s7
 2fc:	60e6                	ld	ra,88(sp)
 2fe:	6446                	ld	s0,80(sp)
 300:	64a6                	ld	s1,72(sp)
 302:	6906                	ld	s2,64(sp)
 304:	79e2                	ld	s3,56(sp)
 306:	7a42                	ld	s4,48(sp)
 308:	7aa2                	ld	s5,40(sp)
 30a:	7b02                	ld	s6,32(sp)
 30c:	6be2                	ld	s7,24(sp)
 30e:	6125                	addi	sp,sp,96
 310:	8082                	ret

0000000000000312 <stat>:

int
stat(const char *n, struct stat *st)
{
 312:	1101                	addi	sp,sp,-32
 314:	ec06                	sd	ra,24(sp)
 316:	e822                	sd	s0,16(sp)
 318:	e426                	sd	s1,8(sp)
 31a:	e04a                	sd	s2,0(sp)
 31c:	1000                	addi	s0,sp,32
 31e:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 320:	4581                	li	a1,0
 322:	00000097          	auipc	ra,0x0
 326:	170080e7          	jalr	368(ra) # 492 <open>
  if(fd < 0)
 32a:	02054563          	bltz	a0,354 <stat+0x42>
 32e:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 330:	85ca                	mv	a1,s2
 332:	00000097          	auipc	ra,0x0
 336:	178080e7          	jalr	376(ra) # 4aa <fstat>
 33a:	892a                	mv	s2,a0
  close(fd);
 33c:	8526                	mv	a0,s1
 33e:	00000097          	auipc	ra,0x0
 342:	13c080e7          	jalr	316(ra) # 47a <close>
  return r;
}
 346:	854a                	mv	a0,s2
 348:	60e2                	ld	ra,24(sp)
 34a:	6442                	ld	s0,16(sp)
 34c:	64a2                	ld	s1,8(sp)
 34e:	6902                	ld	s2,0(sp)
 350:	6105                	addi	sp,sp,32
 352:	8082                	ret
    return -1;
 354:	597d                	li	s2,-1
 356:	bfc5                	j	346 <stat+0x34>

0000000000000358 <atoi>:

int
atoi(const char *s)
{
 358:	1141                	addi	sp,sp,-16
 35a:	e422                	sd	s0,8(sp)
 35c:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 35e:	00054683          	lbu	a3,0(a0)
 362:	fd06879b          	addiw	a5,a3,-48
 366:	0ff7f793          	zext.b	a5,a5
 36a:	4625                	li	a2,9
 36c:	02f66863          	bltu	a2,a5,39c <atoi+0x44>
 370:	872a                	mv	a4,a0
  n = 0;
 372:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 374:	0705                	addi	a4,a4,1
 376:	0025179b          	slliw	a5,a0,0x2
 37a:	9fa9                	addw	a5,a5,a0
 37c:	0017979b          	slliw	a5,a5,0x1
 380:	9fb5                	addw	a5,a5,a3
 382:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 386:	00074683          	lbu	a3,0(a4)
 38a:	fd06879b          	addiw	a5,a3,-48
 38e:	0ff7f793          	zext.b	a5,a5
 392:	fef671e3          	bgeu	a2,a5,374 <atoi+0x1c>
  return n;
}
 396:	6422                	ld	s0,8(sp)
 398:	0141                	addi	sp,sp,16
 39a:	8082                	ret
  n = 0;
 39c:	4501                	li	a0,0
 39e:	bfe5                	j	396 <atoi+0x3e>

00000000000003a0 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 3a0:	1141                	addi	sp,sp,-16
 3a2:	e422                	sd	s0,8(sp)
 3a4:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 3a6:	02b57463          	bgeu	a0,a1,3ce <memmove+0x2e>
    while(n-- > 0)
 3aa:	00c05f63          	blez	a2,3c8 <memmove+0x28>
 3ae:	1602                	slli	a2,a2,0x20
 3b0:	9201                	srli	a2,a2,0x20
 3b2:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 3b6:	872a                	mv	a4,a0
      *dst++ = *src++;
 3b8:	0585                	addi	a1,a1,1
 3ba:	0705                	addi	a4,a4,1
 3bc:	fff5c683          	lbu	a3,-1(a1)
 3c0:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 3c4:	fee79ae3          	bne	a5,a4,3b8 <memmove+0x18>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 3c8:	6422                	ld	s0,8(sp)
 3ca:	0141                	addi	sp,sp,16
 3cc:	8082                	ret
    dst += n;
 3ce:	00c50733          	add	a4,a0,a2
    src += n;
 3d2:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 3d4:	fec05ae3          	blez	a2,3c8 <memmove+0x28>
 3d8:	fff6079b          	addiw	a5,a2,-1
 3dc:	1782                	slli	a5,a5,0x20
 3de:	9381                	srli	a5,a5,0x20
 3e0:	fff7c793          	not	a5,a5
 3e4:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 3e6:	15fd                	addi	a1,a1,-1
 3e8:	177d                	addi	a4,a4,-1
 3ea:	0005c683          	lbu	a3,0(a1)
 3ee:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 3f2:	fee79ae3          	bne	a5,a4,3e6 <memmove+0x46>
 3f6:	bfc9                	j	3c8 <memmove+0x28>

00000000000003f8 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 3f8:	1141                	addi	sp,sp,-16
 3fa:	e422                	sd	s0,8(sp)
 3fc:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 3fe:	ca05                	beqz	a2,42e <memcmp+0x36>
 400:	fff6069b          	addiw	a3,a2,-1
 404:	1682                	slli	a3,a3,0x20
 406:	9281                	srli	a3,a3,0x20
 408:	0685                	addi	a3,a3,1
 40a:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 40c:	00054783          	lbu	a5,0(a0)
 410:	0005c703          	lbu	a4,0(a1)
 414:	00e79863          	bne	a5,a4,424 <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 418:	0505                	addi	a0,a0,1
    p2++;
 41a:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 41c:	fed518e3          	bne	a0,a3,40c <memcmp+0x14>
  }
  return 0;
 420:	4501                	li	a0,0
 422:	a019                	j	428 <memcmp+0x30>
      return *p1 - *p2;
 424:	40e7853b          	subw	a0,a5,a4
}
 428:	6422                	ld	s0,8(sp)
 42a:	0141                	addi	sp,sp,16
 42c:	8082                	ret
  return 0;
 42e:	4501                	li	a0,0
 430:	bfe5                	j	428 <memcmp+0x30>

0000000000000432 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 432:	1141                	addi	sp,sp,-16
 434:	e406                	sd	ra,8(sp)
 436:	e022                	sd	s0,0(sp)
 438:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 43a:	00000097          	auipc	ra,0x0
 43e:	f66080e7          	jalr	-154(ra) # 3a0 <memmove>
}
 442:	60a2                	ld	ra,8(sp)
 444:	6402                	ld	s0,0(sp)
 446:	0141                	addi	sp,sp,16
 448:	8082                	ret

000000000000044a <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 44a:	4885                	li	a7,1
 ecall
 44c:	00000073          	ecall
 ret
 450:	8082                	ret

0000000000000452 <exit>:
.global exit
exit:
 li a7, SYS_exit
 452:	4889                	li	a7,2
 ecall
 454:	00000073          	ecall
 ret
 458:	8082                	ret

000000000000045a <wait>:
.global wait
wait:
 li a7, SYS_wait
 45a:	488d                	li	a7,3
 ecall
 45c:	00000073          	ecall
 ret
 460:	8082                	ret

0000000000000462 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 462:	4891                	li	a7,4
 ecall
 464:	00000073          	ecall
 ret
 468:	8082                	ret

000000000000046a <read>:
.global read
read:
 li a7, SYS_read
 46a:	4895                	li	a7,5
 ecall
 46c:	00000073          	ecall
 ret
 470:	8082                	ret

0000000000000472 <write>:
.global write
write:
 li a7, SYS_write
 472:	48c1                	li	a7,16
 ecall
 474:	00000073          	ecall
 ret
 478:	8082                	ret

000000000000047a <close>:
.global close
close:
 li a7, SYS_close
 47a:	48d5                	li	a7,21
 ecall
 47c:	00000073          	ecall
 ret
 480:	8082                	ret

0000000000000482 <kill>:
.global kill
kill:
 li a7, SYS_kill
 482:	4899                	li	a7,6
 ecall
 484:	00000073          	ecall
 ret
 488:	8082                	ret

000000000000048a <exec>:
.global exec
exec:
 li a7, SYS_exec
 48a:	489d                	li	a7,7
 ecall
 48c:	00000073          	ecall
 ret
 490:	8082                	ret

0000000000000492 <open>:
.global open
open:
 li a7, SYS_open
 492:	48bd                	li	a7,15
 ecall
 494:	00000073          	ecall
 ret
 498:	8082                	ret

000000000000049a <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 49a:	48c5                	li	a7,17
 ecall
 49c:	00000073          	ecall
 ret
 4a0:	8082                	ret

00000000000004a2 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 4a2:	48c9                	li	a7,18
 ecall
 4a4:	00000073          	ecall
 ret
 4a8:	8082                	ret

00000000000004aa <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 4aa:	48a1                	li	a7,8
 ecall
 4ac:	00000073          	ecall
 ret
 4b0:	8082                	ret

00000000000004b2 <link>:
.global link
link:
 li a7, SYS_link
 4b2:	48cd                	li	a7,19
 ecall
 4b4:	00000073          	ecall
 ret
 4b8:	8082                	ret

00000000000004ba <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 4ba:	48d1                	li	a7,20
 ecall
 4bc:	00000073          	ecall
 ret
 4c0:	8082                	ret

00000000000004c2 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 4c2:	48a5                	li	a7,9
 ecall
 4c4:	00000073          	ecall
 ret
 4c8:	8082                	ret

00000000000004ca <dup>:
.global dup
dup:
 li a7, SYS_dup
 4ca:	48a9                	li	a7,10
 ecall
 4cc:	00000073          	ecall
 ret
 4d0:	8082                	ret

00000000000004d2 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 4d2:	48ad                	li	a7,11
 ecall
 4d4:	00000073          	ecall
 ret
 4d8:	8082                	ret

00000000000004da <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 4da:	48b1                	li	a7,12
 ecall
 4dc:	00000073          	ecall
 ret
 4e0:	8082                	ret

00000000000004e2 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 4e2:	48b5                	li	a7,13
 ecall
 4e4:	00000073          	ecall
 ret
 4e8:	8082                	ret

00000000000004ea <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 4ea:	48b9                	li	a7,14
 ecall
 4ec:	00000073          	ecall
 ret
 4f0:	8082                	ret

00000000000004f2 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 4f2:	1101                	addi	sp,sp,-32
 4f4:	ec06                	sd	ra,24(sp)
 4f6:	e822                	sd	s0,16(sp)
 4f8:	1000                	addi	s0,sp,32
 4fa:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 4fe:	4605                	li	a2,1
 500:	fef40593          	addi	a1,s0,-17
 504:	00000097          	auipc	ra,0x0
 508:	f6e080e7          	jalr	-146(ra) # 472 <write>
}
 50c:	60e2                	ld	ra,24(sp)
 50e:	6442                	ld	s0,16(sp)
 510:	6105                	addi	sp,sp,32
 512:	8082                	ret

0000000000000514 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 514:	7139                	addi	sp,sp,-64
 516:	fc06                	sd	ra,56(sp)
 518:	f822                	sd	s0,48(sp)
 51a:	f426                	sd	s1,40(sp)
 51c:	f04a                	sd	s2,32(sp)
 51e:	ec4e                	sd	s3,24(sp)
 520:	0080                	addi	s0,sp,64
 522:	84aa                	mv	s1,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 524:	c299                	beqz	a3,52a <printint+0x16>
 526:	0805c963          	bltz	a1,5b8 <printint+0xa4>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 52a:	2581                	sext.w	a1,a1
  neg = 0;
 52c:	4881                	li	a7,0
 52e:	fc040693          	addi	a3,s0,-64
  }

  i = 0;
 532:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 534:	2601                	sext.w	a2,a2
 536:	00000517          	auipc	a0,0x0
 53a:	4ca50513          	addi	a0,a0,1226 # a00 <digits>
 53e:	883a                	mv	a6,a4
 540:	2705                	addiw	a4,a4,1
 542:	02c5f7bb          	remuw	a5,a1,a2
 546:	1782                	slli	a5,a5,0x20
 548:	9381                	srli	a5,a5,0x20
 54a:	97aa                	add	a5,a5,a0
 54c:	0007c783          	lbu	a5,0(a5)
 550:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 554:	0005879b          	sext.w	a5,a1
 558:	02c5d5bb          	divuw	a1,a1,a2
 55c:	0685                	addi	a3,a3,1
 55e:	fec7f0e3          	bgeu	a5,a2,53e <printint+0x2a>
  if(neg)
 562:	00088c63          	beqz	a7,57a <printint+0x66>
    buf[i++] = '-';
 566:	fd070793          	addi	a5,a4,-48
 56a:	00878733          	add	a4,a5,s0
 56e:	02d00793          	li	a5,45
 572:	fef70823          	sb	a5,-16(a4)
 576:	0028071b          	addiw	a4,a6,2

  while(--i >= 0)
 57a:	02e05863          	blez	a4,5aa <printint+0x96>
 57e:	fc040793          	addi	a5,s0,-64
 582:	00e78933          	add	s2,a5,a4
 586:	fff78993          	addi	s3,a5,-1
 58a:	99ba                	add	s3,s3,a4
 58c:	377d                	addiw	a4,a4,-1
 58e:	1702                	slli	a4,a4,0x20
 590:	9301                	srli	a4,a4,0x20
 592:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 596:	fff94583          	lbu	a1,-1(s2)
 59a:	8526                	mv	a0,s1
 59c:	00000097          	auipc	ra,0x0
 5a0:	f56080e7          	jalr	-170(ra) # 4f2 <putc>
  while(--i >= 0)
 5a4:	197d                	addi	s2,s2,-1
 5a6:	ff3918e3          	bne	s2,s3,596 <printint+0x82>
}
 5aa:	70e2                	ld	ra,56(sp)
 5ac:	7442                	ld	s0,48(sp)
 5ae:	74a2                	ld	s1,40(sp)
 5b0:	7902                	ld	s2,32(sp)
 5b2:	69e2                	ld	s3,24(sp)
 5b4:	6121                	addi	sp,sp,64
 5b6:	8082                	ret
    x = -xx;
 5b8:	40b005bb          	negw	a1,a1
    neg = 1;
 5bc:	4885                	li	a7,1
    x = -xx;
 5be:	bf85                	j	52e <printint+0x1a>

00000000000005c0 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 5c0:	7119                	addi	sp,sp,-128
 5c2:	fc86                	sd	ra,120(sp)
 5c4:	f8a2                	sd	s0,112(sp)
 5c6:	f4a6                	sd	s1,104(sp)
 5c8:	f0ca                	sd	s2,96(sp)
 5ca:	ecce                	sd	s3,88(sp)
 5cc:	e8d2                	sd	s4,80(sp)
 5ce:	e4d6                	sd	s5,72(sp)
 5d0:	e0da                	sd	s6,64(sp)
 5d2:	fc5e                	sd	s7,56(sp)
 5d4:	f862                	sd	s8,48(sp)
 5d6:	f466                	sd	s9,40(sp)
 5d8:	f06a                	sd	s10,32(sp)
 5da:	ec6e                	sd	s11,24(sp)
 5dc:	0100                	addi	s0,sp,128
  char *s;
  int c, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 5de:	0005c903          	lbu	s2,0(a1)
 5e2:	18090f63          	beqz	s2,780 <vprintf+0x1c0>
 5e6:	8aaa                	mv	s5,a0
 5e8:	8b32                	mv	s6,a2
 5ea:	00158493          	addi	s1,a1,1
  state = 0;
 5ee:	4981                	li	s3,0
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
      }
    } else if(state == '%'){
 5f0:	02500a13          	li	s4,37
 5f4:	4c55                	li	s8,21
 5f6:	00000c97          	auipc	s9,0x0
 5fa:	3b2c8c93          	addi	s9,s9,946 # 9a8 <malloc+0x124>
        printptr(fd, va_arg(ap, uint64));
      } else if(c == 's'){
        s = va_arg(ap, char*);
        if(s == 0)
          s = "(null)";
        while(*s != 0){
 5fe:	02800d93          	li	s11,40
  putc(fd, 'x');
 602:	4d41                	li	s10,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 604:	00000b97          	auipc	s7,0x0
 608:	3fcb8b93          	addi	s7,s7,1020 # a00 <digits>
 60c:	a839                	j	62a <vprintf+0x6a>
        putc(fd, c);
 60e:	85ca                	mv	a1,s2
 610:	8556                	mv	a0,s5
 612:	00000097          	auipc	ra,0x0
 616:	ee0080e7          	jalr	-288(ra) # 4f2 <putc>
 61a:	a019                	j	620 <vprintf+0x60>
    } else if(state == '%'){
 61c:	01498d63          	beq	s3,s4,636 <vprintf+0x76>
  for(i = 0; fmt[i]; i++){
 620:	0485                	addi	s1,s1,1
 622:	fff4c903          	lbu	s2,-1(s1)
 626:	14090d63          	beqz	s2,780 <vprintf+0x1c0>
    if(state == 0){
 62a:	fe0999e3          	bnez	s3,61c <vprintf+0x5c>
      if(c == '%'){
 62e:	ff4910e3          	bne	s2,s4,60e <vprintf+0x4e>
        state = '%';
 632:	89d2                	mv	s3,s4
 634:	b7f5                	j	620 <vprintf+0x60>
      if(c == 'd'){
 636:	11490c63          	beq	s2,s4,74e <vprintf+0x18e>
 63a:	f9d9079b          	addiw	a5,s2,-99
 63e:	0ff7f793          	zext.b	a5,a5
 642:	10fc6e63          	bltu	s8,a5,75e <vprintf+0x19e>
 646:	f9d9079b          	addiw	a5,s2,-99
 64a:	0ff7f713          	zext.b	a4,a5
 64e:	10ec6863          	bltu	s8,a4,75e <vprintf+0x19e>
 652:	00271793          	slli	a5,a4,0x2
 656:	97e6                	add	a5,a5,s9
 658:	439c                	lw	a5,0(a5)
 65a:	97e6                	add	a5,a5,s9
 65c:	8782                	jr	a5
        printint(fd, va_arg(ap, int), 10, 1);
 65e:	008b0913          	addi	s2,s6,8
 662:	4685                	li	a3,1
 664:	4629                	li	a2,10
 666:	000b2583          	lw	a1,0(s6)
 66a:	8556                	mv	a0,s5
 66c:	00000097          	auipc	ra,0x0
 670:	ea8080e7          	jalr	-344(ra) # 514 <printint>
 674:	8b4a                	mv	s6,s2
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
      state = 0;
 676:	4981                	li	s3,0
 678:	b765                	j	620 <vprintf+0x60>
        printint(fd, va_arg(ap, uint64), 10, 0);
 67a:	008b0913          	addi	s2,s6,8
 67e:	4681                	li	a3,0
 680:	4629                	li	a2,10
 682:	000b2583          	lw	a1,0(s6)
 686:	8556                	mv	a0,s5
 688:	00000097          	auipc	ra,0x0
 68c:	e8c080e7          	jalr	-372(ra) # 514 <printint>
 690:	8b4a                	mv	s6,s2
      state = 0;
 692:	4981                	li	s3,0
 694:	b771                	j	620 <vprintf+0x60>
        printint(fd, va_arg(ap, int), 16, 0);
 696:	008b0913          	addi	s2,s6,8
 69a:	4681                	li	a3,0
 69c:	866a                	mv	a2,s10
 69e:	000b2583          	lw	a1,0(s6)
 6a2:	8556                	mv	a0,s5
 6a4:	00000097          	auipc	ra,0x0
 6a8:	e70080e7          	jalr	-400(ra) # 514 <printint>
 6ac:	8b4a                	mv	s6,s2
      state = 0;
 6ae:	4981                	li	s3,0
 6b0:	bf85                	j	620 <vprintf+0x60>
        printptr(fd, va_arg(ap, uint64));
 6b2:	008b0793          	addi	a5,s6,8
 6b6:	f8f43423          	sd	a5,-120(s0)
 6ba:	000b3983          	ld	s3,0(s6)
  putc(fd, '0');
 6be:	03000593          	li	a1,48
 6c2:	8556                	mv	a0,s5
 6c4:	00000097          	auipc	ra,0x0
 6c8:	e2e080e7          	jalr	-466(ra) # 4f2 <putc>
  putc(fd, 'x');
 6cc:	07800593          	li	a1,120
 6d0:	8556                	mv	a0,s5
 6d2:	00000097          	auipc	ra,0x0
 6d6:	e20080e7          	jalr	-480(ra) # 4f2 <putc>
 6da:	896a                	mv	s2,s10
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 6dc:	03c9d793          	srli	a5,s3,0x3c
 6e0:	97de                	add	a5,a5,s7
 6e2:	0007c583          	lbu	a1,0(a5)
 6e6:	8556                	mv	a0,s5
 6e8:	00000097          	auipc	ra,0x0
 6ec:	e0a080e7          	jalr	-502(ra) # 4f2 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 6f0:	0992                	slli	s3,s3,0x4
 6f2:	397d                	addiw	s2,s2,-1
 6f4:	fe0914e3          	bnez	s2,6dc <vprintf+0x11c>
        printptr(fd, va_arg(ap, uint64));
 6f8:	f8843b03          	ld	s6,-120(s0)
      state = 0;
 6fc:	4981                	li	s3,0
 6fe:	b70d                	j	620 <vprintf+0x60>
        s = va_arg(ap, char*);
 700:	008b0913          	addi	s2,s6,8
 704:	000b3983          	ld	s3,0(s6)
        if(s == 0)
 708:	02098163          	beqz	s3,72a <vprintf+0x16a>
        while(*s != 0){
 70c:	0009c583          	lbu	a1,0(s3)
 710:	c5ad                	beqz	a1,77a <vprintf+0x1ba>
          putc(fd, *s);
 712:	8556                	mv	a0,s5
 714:	00000097          	auipc	ra,0x0
 718:	dde080e7          	jalr	-546(ra) # 4f2 <putc>
          s++;
 71c:	0985                	addi	s3,s3,1
        while(*s != 0){
 71e:	0009c583          	lbu	a1,0(s3)
 722:	f9e5                	bnez	a1,712 <vprintf+0x152>
        s = va_arg(ap, char*);
 724:	8b4a                	mv	s6,s2
      state = 0;
 726:	4981                	li	s3,0
 728:	bde5                	j	620 <vprintf+0x60>
          s = "(null)";
 72a:	00000997          	auipc	s3,0x0
 72e:	27698993          	addi	s3,s3,630 # 9a0 <malloc+0x11c>
        while(*s != 0){
 732:	85ee                	mv	a1,s11
 734:	bff9                	j	712 <vprintf+0x152>
        putc(fd, va_arg(ap, uint));
 736:	008b0913          	addi	s2,s6,8
 73a:	000b4583          	lbu	a1,0(s6)
 73e:	8556                	mv	a0,s5
 740:	00000097          	auipc	ra,0x0
 744:	db2080e7          	jalr	-590(ra) # 4f2 <putc>
 748:	8b4a                	mv	s6,s2
      state = 0;
 74a:	4981                	li	s3,0
 74c:	bdd1                	j	620 <vprintf+0x60>
        putc(fd, c);
 74e:	85d2                	mv	a1,s4
 750:	8556                	mv	a0,s5
 752:	00000097          	auipc	ra,0x0
 756:	da0080e7          	jalr	-608(ra) # 4f2 <putc>
      state = 0;
 75a:	4981                	li	s3,0
 75c:	b5d1                	j	620 <vprintf+0x60>
        putc(fd, '%');
 75e:	85d2                	mv	a1,s4
 760:	8556                	mv	a0,s5
 762:	00000097          	auipc	ra,0x0
 766:	d90080e7          	jalr	-624(ra) # 4f2 <putc>
        putc(fd, c);
 76a:	85ca                	mv	a1,s2
 76c:	8556                	mv	a0,s5
 76e:	00000097          	auipc	ra,0x0
 772:	d84080e7          	jalr	-636(ra) # 4f2 <putc>
      state = 0;
 776:	4981                	li	s3,0
 778:	b565                	j	620 <vprintf+0x60>
        s = va_arg(ap, char*);
 77a:	8b4a                	mv	s6,s2
      state = 0;
 77c:	4981                	li	s3,0
 77e:	b54d                	j	620 <vprintf+0x60>
    }
  }
}
 780:	70e6                	ld	ra,120(sp)
 782:	7446                	ld	s0,112(sp)
 784:	74a6                	ld	s1,104(sp)
 786:	7906                	ld	s2,96(sp)
 788:	69e6                	ld	s3,88(sp)
 78a:	6a46                	ld	s4,80(sp)
 78c:	6aa6                	ld	s5,72(sp)
 78e:	6b06                	ld	s6,64(sp)
 790:	7be2                	ld	s7,56(sp)
 792:	7c42                	ld	s8,48(sp)
 794:	7ca2                	ld	s9,40(sp)
 796:	7d02                	ld	s10,32(sp)
 798:	6de2                	ld	s11,24(sp)
 79a:	6109                	addi	sp,sp,128
 79c:	8082                	ret

000000000000079e <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 79e:	715d                	addi	sp,sp,-80
 7a0:	ec06                	sd	ra,24(sp)
 7a2:	e822                	sd	s0,16(sp)
 7a4:	1000                	addi	s0,sp,32
 7a6:	e010                	sd	a2,0(s0)
 7a8:	e414                	sd	a3,8(s0)
 7aa:	e818                	sd	a4,16(s0)
 7ac:	ec1c                	sd	a5,24(s0)
 7ae:	03043023          	sd	a6,32(s0)
 7b2:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 7b6:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 7ba:	8622                	mv	a2,s0
 7bc:	00000097          	auipc	ra,0x0
 7c0:	e04080e7          	jalr	-508(ra) # 5c0 <vprintf>
}
 7c4:	60e2                	ld	ra,24(sp)
 7c6:	6442                	ld	s0,16(sp)
 7c8:	6161                	addi	sp,sp,80
 7ca:	8082                	ret

00000000000007cc <printf>:

void
printf(const char *fmt, ...)
{
 7cc:	711d                	addi	sp,sp,-96
 7ce:	ec06                	sd	ra,24(sp)
 7d0:	e822                	sd	s0,16(sp)
 7d2:	1000                	addi	s0,sp,32
 7d4:	e40c                	sd	a1,8(s0)
 7d6:	e810                	sd	a2,16(s0)
 7d8:	ec14                	sd	a3,24(s0)
 7da:	f018                	sd	a4,32(s0)
 7dc:	f41c                	sd	a5,40(s0)
 7de:	03043823          	sd	a6,48(s0)
 7e2:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 7e6:	00840613          	addi	a2,s0,8
 7ea:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 7ee:	85aa                	mv	a1,a0
 7f0:	4505                	li	a0,1
 7f2:	00000097          	auipc	ra,0x0
 7f6:	dce080e7          	jalr	-562(ra) # 5c0 <vprintf>
}
 7fa:	60e2                	ld	ra,24(sp)
 7fc:	6442                	ld	s0,16(sp)
 7fe:	6125                	addi	sp,sp,96
 800:	8082                	ret

0000000000000802 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 802:	1141                	addi	sp,sp,-16
 804:	e422                	sd	s0,8(sp)
 806:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 808:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 80c:	00000797          	auipc	a5,0x0
 810:	7f47b783          	ld	a5,2036(a5) # 1000 <freep>
 814:	a02d                	j	83e <free+0x3c>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 816:	4618                	lw	a4,8(a2)
 818:	9f2d                	addw	a4,a4,a1
 81a:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 81e:	6398                	ld	a4,0(a5)
 820:	6310                	ld	a2,0(a4)
 822:	a83d                	j	860 <free+0x5e>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 824:	ff852703          	lw	a4,-8(a0)
 828:	9f31                	addw	a4,a4,a2
 82a:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 82c:	ff053683          	ld	a3,-16(a0)
 830:	a091                	j	874 <free+0x72>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 832:	6398                	ld	a4,0(a5)
 834:	00e7e463          	bltu	a5,a4,83c <free+0x3a>
 838:	00e6ea63          	bltu	a3,a4,84c <free+0x4a>
{
 83c:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 83e:	fed7fae3          	bgeu	a5,a3,832 <free+0x30>
 842:	6398                	ld	a4,0(a5)
 844:	00e6e463          	bltu	a3,a4,84c <free+0x4a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 848:	fee7eae3          	bltu	a5,a4,83c <free+0x3a>
  if(bp + bp->s.size == p->s.ptr){
 84c:	ff852583          	lw	a1,-8(a0)
 850:	6390                	ld	a2,0(a5)
 852:	02059813          	slli	a6,a1,0x20
 856:	01c85713          	srli	a4,a6,0x1c
 85a:	9736                	add	a4,a4,a3
 85c:	fae60de3          	beq	a2,a4,816 <free+0x14>
    bp->s.ptr = p->s.ptr->s.ptr;
 860:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 864:	4790                	lw	a2,8(a5)
 866:	02061593          	slli	a1,a2,0x20
 86a:	01c5d713          	srli	a4,a1,0x1c
 86e:	973e                	add	a4,a4,a5
 870:	fae68ae3          	beq	a3,a4,824 <free+0x22>
    p->s.ptr = bp->s.ptr;
 874:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 876:	00000717          	auipc	a4,0x0
 87a:	78f73523          	sd	a5,1930(a4) # 1000 <freep>
}
 87e:	6422                	ld	s0,8(sp)
 880:	0141                	addi	sp,sp,16
 882:	8082                	ret

0000000000000884 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 884:	7139                	addi	sp,sp,-64
 886:	fc06                	sd	ra,56(sp)
 888:	f822                	sd	s0,48(sp)
 88a:	f426                	sd	s1,40(sp)
 88c:	f04a                	sd	s2,32(sp)
 88e:	ec4e                	sd	s3,24(sp)
 890:	e852                	sd	s4,16(sp)
 892:	e456                	sd	s5,8(sp)
 894:	e05a                	sd	s6,0(sp)
 896:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 898:	02051493          	slli	s1,a0,0x20
 89c:	9081                	srli	s1,s1,0x20
 89e:	04bd                	addi	s1,s1,15
 8a0:	8091                	srli	s1,s1,0x4
 8a2:	0014899b          	addiw	s3,s1,1
 8a6:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 8a8:	00000517          	auipc	a0,0x0
 8ac:	75853503          	ld	a0,1880(a0) # 1000 <freep>
 8b0:	c515                	beqz	a0,8dc <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 8b2:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 8b4:	4798                	lw	a4,8(a5)
 8b6:	02977f63          	bgeu	a4,s1,8f4 <malloc+0x70>
 8ba:	8a4e                	mv	s4,s3
 8bc:	0009871b          	sext.w	a4,s3
 8c0:	6685                	lui	a3,0x1
 8c2:	00d77363          	bgeu	a4,a3,8c8 <malloc+0x44>
 8c6:	6a05                	lui	s4,0x1
 8c8:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 8cc:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 8d0:	00000917          	auipc	s2,0x0
 8d4:	73090913          	addi	s2,s2,1840 # 1000 <freep>
  if(p == (char*)-1)
 8d8:	5afd                	li	s5,-1
 8da:	a895                	j	94e <malloc+0xca>
    base.s.ptr = freep = prevp = &base;
 8dc:	00000797          	auipc	a5,0x0
 8e0:	77478793          	addi	a5,a5,1908 # 1050 <base>
 8e4:	00000717          	auipc	a4,0x0
 8e8:	70f73e23          	sd	a5,1820(a4) # 1000 <freep>
 8ec:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 8ee:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 8f2:	b7e1                	j	8ba <malloc+0x36>
      if(p->s.size == nunits)
 8f4:	02e48c63          	beq	s1,a4,92c <malloc+0xa8>
        p->s.size -= nunits;
 8f8:	4137073b          	subw	a4,a4,s3
 8fc:	c798                	sw	a4,8(a5)
        p += p->s.size;
 8fe:	02071693          	slli	a3,a4,0x20
 902:	01c6d713          	srli	a4,a3,0x1c
 906:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 908:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 90c:	00000717          	auipc	a4,0x0
 910:	6ea73a23          	sd	a0,1780(a4) # 1000 <freep>
      return (void*)(p + 1);
 914:	01078513          	addi	a0,a5,16
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 918:	70e2                	ld	ra,56(sp)
 91a:	7442                	ld	s0,48(sp)
 91c:	74a2                	ld	s1,40(sp)
 91e:	7902                	ld	s2,32(sp)
 920:	69e2                	ld	s3,24(sp)
 922:	6a42                	ld	s4,16(sp)
 924:	6aa2                	ld	s5,8(sp)
 926:	6b02                	ld	s6,0(sp)
 928:	6121                	addi	sp,sp,64
 92a:	8082                	ret
        prevp->s.ptr = p->s.ptr;
 92c:	6398                	ld	a4,0(a5)
 92e:	e118                	sd	a4,0(a0)
 930:	bff1                	j	90c <malloc+0x88>
  hp->s.size = nu;
 932:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 936:	0541                	addi	a0,a0,16
 938:	00000097          	auipc	ra,0x0
 93c:	eca080e7          	jalr	-310(ra) # 802 <free>
  return freep;
 940:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 944:	d971                	beqz	a0,918 <malloc+0x94>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 946:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 948:	4798                	lw	a4,8(a5)
 94a:	fa9775e3          	bgeu	a4,s1,8f4 <malloc+0x70>
    if(p == freep)
 94e:	00093703          	ld	a4,0(s2)
 952:	853e                	mv	a0,a5
 954:	fef719e3          	bne	a4,a5,946 <malloc+0xc2>
  p = sbrk(nu * sizeof(Header));
 958:	8552                	mv	a0,s4
 95a:	00000097          	auipc	ra,0x0
 95e:	b80080e7          	jalr	-1152(ra) # 4da <sbrk>
  if(p == (char*)-1)
 962:	fd5518e3          	bne	a0,s5,932 <malloc+0xae>
        return 0;
 966:	4501                	li	a0,0
 968:	bf45                	j	918 <malloc+0x94>
