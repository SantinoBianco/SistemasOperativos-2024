
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	00009117          	auipc	sp,0x9
    80000004:	89013103          	ld	sp,-1904(sp) # 80008890 <_GLOBAL_OFFSET_TABLE_+0x8>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	074000ef          	jal	ra,8000008a <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
// at timervec in kernelvec.S,
// which turns them into software interrupts for
// devintr() in trap.c.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e422                	sd	s0,8(sp)
    80000020:	0800                	addi	s0,sp,16
// which hart (core) is this?
static inline uint64
r_mhartid()
{
  uint64 x;
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    80000022:	f14027f3          	csrr	a5,mhartid
  // each CPU has a separate source of timer interrupts.
  int id = r_mhartid();
    80000026:	0007859b          	sext.w	a1,a5

  // ask the CLINT for a timer interrupt.
  int interval = 100000; // cycles; about 1/10th second in qemu.
  *(uint64*)CLINT_MTIMECMP(id) = *(uint64*)CLINT_MTIME + interval;
    8000002a:	0037979b          	slliw	a5,a5,0x3
    8000002e:	02004737          	lui	a4,0x2004
    80000032:	97ba                	add	a5,a5,a4
    80000034:	0200c737          	lui	a4,0x200c
    80000038:	ff873703          	ld	a4,-8(a4) # 200bff8 <_entry-0x7dff4008>
    8000003c:	6661                	lui	a2,0x18
    8000003e:	6a060613          	addi	a2,a2,1696 # 186a0 <_entry-0x7ffe7960>
    80000042:	9732                	add	a4,a4,a2
    80000044:	e398                	sd	a4,0(a5)

  // prepare information in scratch[] for timervec.
  // scratch[0..2] : space for timervec to save registers.
  // scratch[3] : address of CLINT MTIMECMP register.
  // scratch[4] : desired interval (in cycles) between timer interrupts.
  uint64 *scratch = &timer_scratch[id][0];
    80000046:	00259693          	slli	a3,a1,0x2
    8000004a:	96ae                	add	a3,a3,a1
    8000004c:	068e                	slli	a3,a3,0x3
    8000004e:	00009717          	auipc	a4,0x9
    80000052:	8a270713          	addi	a4,a4,-1886 # 800088f0 <timer_scratch>
    80000056:	9736                	add	a4,a4,a3
  scratch[3] = CLINT_MTIMECMP(id);
    80000058:	ef1c                	sd	a5,24(a4)
  scratch[4] = interval;
    8000005a:	f310                	sd	a2,32(a4)
}

static inline void 
w_mscratch(uint64 x)
{
  asm volatile("csrw mscratch, %0" : : "r" (x));
    8000005c:	34071073          	csrw	mscratch,a4
  asm volatile("csrw mtvec, %0" : : "r" (x));
    80000060:	00006797          	auipc	a5,0x6
    80000064:	c6078793          	addi	a5,a5,-928 # 80005cc0 <timervec>
    80000068:	30579073          	csrw	mtvec,a5
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    8000006c:	300027f3          	csrr	a5,mstatus

  // set the machine-mode trap handler.
  w_mtvec((uint64)timervec);

  // enable machine-mode interrupts.
  w_mstatus(r_mstatus() | MSTATUS_MIE);
    80000070:	0087e793          	ori	a5,a5,8
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80000074:	30079073          	csrw	mstatus,a5
  asm volatile("csrr %0, mie" : "=r" (x) );
    80000078:	304027f3          	csrr	a5,mie

  // enable machine-mode timer interrupts.
  w_mie(r_mie() | MIE_MTIE);
    8000007c:	0807e793          	ori	a5,a5,128
  asm volatile("csrw mie, %0" : : "r" (x));
    80000080:	30479073          	csrw	mie,a5
}
    80000084:	6422                	ld	s0,8(sp)
    80000086:	0141                	addi	sp,sp,16
    80000088:	8082                	ret

000000008000008a <start>:
{
    8000008a:	1141                	addi	sp,sp,-16
    8000008c:	e406                	sd	ra,8(sp)
    8000008e:	e022                	sd	s0,0(sp)
    80000090:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80000092:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000096:	7779                	lui	a4,0xffffe
    80000098:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdc69f>
    8000009c:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    8000009e:	6705                	lui	a4,0x1
    800000a0:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    800000a4:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    800000a6:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    800000aa:	00001797          	auipc	a5,0x1
    800000ae:	dcc78793          	addi	a5,a5,-564 # 80000e76 <main>
    800000b2:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    800000b6:	4781                	li	a5,0
    800000b8:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    800000bc:	67c1                	lui	a5,0x10
    800000be:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    800000c0:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    800000c4:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    800000c8:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    800000cc:	2227e793          	ori	a5,a5,546
  asm volatile("csrw sie, %0" : : "r" (x));
    800000d0:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000d4:	57fd                	li	a5,-1
    800000d6:	83a9                	srli	a5,a5,0xa
    800000d8:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000dc:	47bd                	li	a5,15
    800000de:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000e2:	00000097          	auipc	ra,0x0
    800000e6:	f3a080e7          	jalr	-198(ra) # 8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000ea:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000ee:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000f0:	823e                	mv	tp,a5
  asm volatile("mret");
    800000f2:	30200073          	mret
}
    800000f6:	60a2                	ld	ra,8(sp)
    800000f8:	6402                	ld	s0,0(sp)
    800000fa:	0141                	addi	sp,sp,16
    800000fc:	8082                	ret

00000000800000fe <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000fe:	715d                	addi	sp,sp,-80
    80000100:	e486                	sd	ra,72(sp)
    80000102:	e0a2                	sd	s0,64(sp)
    80000104:	fc26                	sd	s1,56(sp)
    80000106:	f84a                	sd	s2,48(sp)
    80000108:	f44e                	sd	s3,40(sp)
    8000010a:	f052                	sd	s4,32(sp)
    8000010c:	ec56                	sd	s5,24(sp)
    8000010e:	0880                	addi	s0,sp,80
  int i;

  for(i = 0; i < n; i++){
    80000110:	04c05763          	blez	a2,8000015e <consolewrite+0x60>
    80000114:	8a2a                	mv	s4,a0
    80000116:	84ae                	mv	s1,a1
    80000118:	89b2                	mv	s3,a2
    8000011a:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    8000011c:	5afd                	li	s5,-1
    8000011e:	4685                	li	a3,1
    80000120:	8626                	mv	a2,s1
    80000122:	85d2                	mv	a1,s4
    80000124:	fbf40513          	addi	a0,s0,-65
    80000128:	00002097          	auipc	ra,0x2
    8000012c:	49e080e7          	jalr	1182(ra) # 800025c6 <either_copyin>
    80000130:	01550d63          	beq	a0,s5,8000014a <consolewrite+0x4c>
      break;
    uartputc(c);
    80000134:	fbf44503          	lbu	a0,-65(s0)
    80000138:	00000097          	auipc	ra,0x0
    8000013c:	784080e7          	jalr	1924(ra) # 800008bc <uartputc>
  for(i = 0; i < n; i++){
    80000140:	2905                	addiw	s2,s2,1
    80000142:	0485                	addi	s1,s1,1
    80000144:	fd299de3          	bne	s3,s2,8000011e <consolewrite+0x20>
    80000148:	894e                	mv	s2,s3
  }

  return i;
}
    8000014a:	854a                	mv	a0,s2
    8000014c:	60a6                	ld	ra,72(sp)
    8000014e:	6406                	ld	s0,64(sp)
    80000150:	74e2                	ld	s1,56(sp)
    80000152:	7942                	ld	s2,48(sp)
    80000154:	79a2                	ld	s3,40(sp)
    80000156:	7a02                	ld	s4,32(sp)
    80000158:	6ae2                	ld	s5,24(sp)
    8000015a:	6161                	addi	sp,sp,80
    8000015c:	8082                	ret
  for(i = 0; i < n; i++){
    8000015e:	4901                	li	s2,0
    80000160:	b7ed                	j	8000014a <consolewrite+0x4c>

0000000080000162 <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000162:	7159                	addi	sp,sp,-112
    80000164:	f486                	sd	ra,104(sp)
    80000166:	f0a2                	sd	s0,96(sp)
    80000168:	eca6                	sd	s1,88(sp)
    8000016a:	e8ca                	sd	s2,80(sp)
    8000016c:	e4ce                	sd	s3,72(sp)
    8000016e:	e0d2                	sd	s4,64(sp)
    80000170:	fc56                	sd	s5,56(sp)
    80000172:	f85a                	sd	s6,48(sp)
    80000174:	f45e                	sd	s7,40(sp)
    80000176:	f062                	sd	s8,32(sp)
    80000178:	ec66                	sd	s9,24(sp)
    8000017a:	e86a                	sd	s10,16(sp)
    8000017c:	1880                	addi	s0,sp,112
    8000017e:	8aaa                	mv	s5,a0
    80000180:	8a2e                	mv	s4,a1
    80000182:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000184:	00060b1b          	sext.w	s6,a2
  acquire(&cons.lock);
    80000188:	00011517          	auipc	a0,0x11
    8000018c:	8a850513          	addi	a0,a0,-1880 # 80010a30 <cons>
    80000190:	00001097          	auipc	ra,0x1
    80000194:	a44080e7          	jalr	-1468(ra) # 80000bd4 <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    80000198:	00011497          	auipc	s1,0x11
    8000019c:	89848493          	addi	s1,s1,-1896 # 80010a30 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    800001a0:	00011917          	auipc	s2,0x11
    800001a4:	92890913          	addi	s2,s2,-1752 # 80010ac8 <cons+0x98>
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];

    if(c == C('D')){  // end-of-file
    800001a8:	4b91                	li	s7,4
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    800001aa:	5c7d                	li	s8,-1
      break;

    dst++;
    --n;

    if(c == '\n'){
    800001ac:	4ca9                	li	s9,10
  while(n > 0){
    800001ae:	07305b63          	blez	s3,80000224 <consoleread+0xc2>
    while(cons.r == cons.w){
    800001b2:	0984a783          	lw	a5,152(s1)
    800001b6:	09c4a703          	lw	a4,156(s1)
    800001ba:	02f71763          	bne	a4,a5,800001e8 <consoleread+0x86>
      if(killed(myproc())){
    800001be:	00001097          	auipc	ra,0x1
    800001c2:	7ec080e7          	jalr	2028(ra) # 800019aa <myproc>
    800001c6:	00002097          	auipc	ra,0x2
    800001ca:	24a080e7          	jalr	586(ra) # 80002410 <killed>
    800001ce:	e535                	bnez	a0,8000023a <consoleread+0xd8>
      sleep(&cons.r, &cons.lock);
    800001d0:	85a6                	mv	a1,s1
    800001d2:	854a                	mv	a0,s2
    800001d4:	00002097          	auipc	ra,0x2
    800001d8:	f82080e7          	jalr	-126(ra) # 80002156 <sleep>
    while(cons.r == cons.w){
    800001dc:	0984a783          	lw	a5,152(s1)
    800001e0:	09c4a703          	lw	a4,156(s1)
    800001e4:	fcf70de3          	beq	a4,a5,800001be <consoleread+0x5c>
    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001e8:	0017871b          	addiw	a4,a5,1
    800001ec:	08e4ac23          	sw	a4,152(s1)
    800001f0:	07f7f713          	andi	a4,a5,127
    800001f4:	9726                	add	a4,a4,s1
    800001f6:	01874703          	lbu	a4,24(a4)
    800001fa:	00070d1b          	sext.w	s10,a4
    if(c == C('D')){  // end-of-file
    800001fe:	077d0563          	beq	s10,s7,80000268 <consoleread+0x106>
    cbuf = c;
    80000202:	f8e40fa3          	sb	a4,-97(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000206:	4685                	li	a3,1
    80000208:	f9f40613          	addi	a2,s0,-97
    8000020c:	85d2                	mv	a1,s4
    8000020e:	8556                	mv	a0,s5
    80000210:	00002097          	auipc	ra,0x2
    80000214:	360080e7          	jalr	864(ra) # 80002570 <either_copyout>
    80000218:	01850663          	beq	a0,s8,80000224 <consoleread+0xc2>
    dst++;
    8000021c:	0a05                	addi	s4,s4,1
    --n;
    8000021e:	39fd                	addiw	s3,s3,-1
    if(c == '\n'){
    80000220:	f99d17e3          	bne	s10,s9,800001ae <consoleread+0x4c>
      // a whole line has arrived, return to
      // the user-level read().
      break;
    }
  }
  release(&cons.lock);
    80000224:	00011517          	auipc	a0,0x11
    80000228:	80c50513          	addi	a0,a0,-2036 # 80010a30 <cons>
    8000022c:	00001097          	auipc	ra,0x1
    80000230:	a5c080e7          	jalr	-1444(ra) # 80000c88 <release>

  return target - n;
    80000234:	413b053b          	subw	a0,s6,s3
    80000238:	a811                	j	8000024c <consoleread+0xea>
        release(&cons.lock);
    8000023a:	00010517          	auipc	a0,0x10
    8000023e:	7f650513          	addi	a0,a0,2038 # 80010a30 <cons>
    80000242:	00001097          	auipc	ra,0x1
    80000246:	a46080e7          	jalr	-1466(ra) # 80000c88 <release>
        return -1;
    8000024a:	557d                	li	a0,-1
}
    8000024c:	70a6                	ld	ra,104(sp)
    8000024e:	7406                	ld	s0,96(sp)
    80000250:	64e6                	ld	s1,88(sp)
    80000252:	6946                	ld	s2,80(sp)
    80000254:	69a6                	ld	s3,72(sp)
    80000256:	6a06                	ld	s4,64(sp)
    80000258:	7ae2                	ld	s5,56(sp)
    8000025a:	7b42                	ld	s6,48(sp)
    8000025c:	7ba2                	ld	s7,40(sp)
    8000025e:	7c02                	ld	s8,32(sp)
    80000260:	6ce2                	ld	s9,24(sp)
    80000262:	6d42                	ld	s10,16(sp)
    80000264:	6165                	addi	sp,sp,112
    80000266:	8082                	ret
      if(n < target){
    80000268:	0009871b          	sext.w	a4,s3
    8000026c:	fb677ce3          	bgeu	a4,s6,80000224 <consoleread+0xc2>
        cons.r--;
    80000270:	00011717          	auipc	a4,0x11
    80000274:	84f72c23          	sw	a5,-1960(a4) # 80010ac8 <cons+0x98>
    80000278:	b775                	j	80000224 <consoleread+0xc2>

000000008000027a <consputc>:
{
    8000027a:	1141                	addi	sp,sp,-16
    8000027c:	e406                	sd	ra,8(sp)
    8000027e:	e022                	sd	s0,0(sp)
    80000280:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80000282:	10000793          	li	a5,256
    80000286:	00f50a63          	beq	a0,a5,8000029a <consputc+0x20>
    uartputc_sync(c);
    8000028a:	00000097          	auipc	ra,0x0
    8000028e:	560080e7          	jalr	1376(ra) # 800007ea <uartputc_sync>
}
    80000292:	60a2                	ld	ra,8(sp)
    80000294:	6402                	ld	s0,0(sp)
    80000296:	0141                	addi	sp,sp,16
    80000298:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    8000029a:	4521                	li	a0,8
    8000029c:	00000097          	auipc	ra,0x0
    800002a0:	54e080e7          	jalr	1358(ra) # 800007ea <uartputc_sync>
    800002a4:	02000513          	li	a0,32
    800002a8:	00000097          	auipc	ra,0x0
    800002ac:	542080e7          	jalr	1346(ra) # 800007ea <uartputc_sync>
    800002b0:	4521                	li	a0,8
    800002b2:	00000097          	auipc	ra,0x0
    800002b6:	538080e7          	jalr	1336(ra) # 800007ea <uartputc_sync>
    800002ba:	bfe1                	j	80000292 <consputc+0x18>

00000000800002bc <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002bc:	1101                	addi	sp,sp,-32
    800002be:	ec06                	sd	ra,24(sp)
    800002c0:	e822                	sd	s0,16(sp)
    800002c2:	e426                	sd	s1,8(sp)
    800002c4:	e04a                	sd	s2,0(sp)
    800002c6:	1000                	addi	s0,sp,32
    800002c8:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002ca:	00010517          	auipc	a0,0x10
    800002ce:	76650513          	addi	a0,a0,1894 # 80010a30 <cons>
    800002d2:	00001097          	auipc	ra,0x1
    800002d6:	902080e7          	jalr	-1790(ra) # 80000bd4 <acquire>

  switch(c){
    800002da:	47d5                	li	a5,21
    800002dc:	0af48663          	beq	s1,a5,80000388 <consoleintr+0xcc>
    800002e0:	0297ca63          	blt	a5,s1,80000314 <consoleintr+0x58>
    800002e4:	47a1                	li	a5,8
    800002e6:	0ef48763          	beq	s1,a5,800003d4 <consoleintr+0x118>
    800002ea:	47c1                	li	a5,16
    800002ec:	10f49a63          	bne	s1,a5,80000400 <consoleintr+0x144>
  case C('P'):  // Print process list.
    procdump();
    800002f0:	00002097          	auipc	ra,0x2
    800002f4:	32c080e7          	jalr	812(ra) # 8000261c <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800002f8:	00010517          	auipc	a0,0x10
    800002fc:	73850513          	addi	a0,a0,1848 # 80010a30 <cons>
    80000300:	00001097          	auipc	ra,0x1
    80000304:	988080e7          	jalr	-1656(ra) # 80000c88 <release>
}
    80000308:	60e2                	ld	ra,24(sp)
    8000030a:	6442                	ld	s0,16(sp)
    8000030c:	64a2                	ld	s1,8(sp)
    8000030e:	6902                	ld	s2,0(sp)
    80000310:	6105                	addi	sp,sp,32
    80000312:	8082                	ret
  switch(c){
    80000314:	07f00793          	li	a5,127
    80000318:	0af48e63          	beq	s1,a5,800003d4 <consoleintr+0x118>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    8000031c:	00010717          	auipc	a4,0x10
    80000320:	71470713          	addi	a4,a4,1812 # 80010a30 <cons>
    80000324:	0a072783          	lw	a5,160(a4)
    80000328:	09872703          	lw	a4,152(a4)
    8000032c:	9f99                	subw	a5,a5,a4
    8000032e:	07f00713          	li	a4,127
    80000332:	fcf763e3          	bltu	a4,a5,800002f8 <consoleintr+0x3c>
      c = (c == '\r') ? '\n' : c;
    80000336:	47b5                	li	a5,13
    80000338:	0cf48763          	beq	s1,a5,80000406 <consoleintr+0x14a>
      consputc(c);
    8000033c:	8526                	mv	a0,s1
    8000033e:	00000097          	auipc	ra,0x0
    80000342:	f3c080e7          	jalr	-196(ra) # 8000027a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000346:	00010797          	auipc	a5,0x10
    8000034a:	6ea78793          	addi	a5,a5,1770 # 80010a30 <cons>
    8000034e:	0a07a683          	lw	a3,160(a5)
    80000352:	0016871b          	addiw	a4,a3,1
    80000356:	0007061b          	sext.w	a2,a4
    8000035a:	0ae7a023          	sw	a4,160(a5)
    8000035e:	07f6f693          	andi	a3,a3,127
    80000362:	97b6                	add	a5,a5,a3
    80000364:	00978c23          	sb	s1,24(a5)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80000368:	47a9                	li	a5,10
    8000036a:	0cf48563          	beq	s1,a5,80000434 <consoleintr+0x178>
    8000036e:	4791                	li	a5,4
    80000370:	0cf48263          	beq	s1,a5,80000434 <consoleintr+0x178>
    80000374:	00010797          	auipc	a5,0x10
    80000378:	7547a783          	lw	a5,1876(a5) # 80010ac8 <cons+0x98>
    8000037c:	9f1d                	subw	a4,a4,a5
    8000037e:	08000793          	li	a5,128
    80000382:	f6f71be3          	bne	a4,a5,800002f8 <consoleintr+0x3c>
    80000386:	a07d                	j	80000434 <consoleintr+0x178>
    while(cons.e != cons.w &&
    80000388:	00010717          	auipc	a4,0x10
    8000038c:	6a870713          	addi	a4,a4,1704 # 80010a30 <cons>
    80000390:	0a072783          	lw	a5,160(a4)
    80000394:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000398:	00010497          	auipc	s1,0x10
    8000039c:	69848493          	addi	s1,s1,1688 # 80010a30 <cons>
    while(cons.e != cons.w &&
    800003a0:	4929                	li	s2,10
    800003a2:	f4f70be3          	beq	a4,a5,800002f8 <consoleintr+0x3c>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    800003a6:	37fd                	addiw	a5,a5,-1
    800003a8:	07f7f713          	andi	a4,a5,127
    800003ac:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    800003ae:	01874703          	lbu	a4,24(a4)
    800003b2:	f52703e3          	beq	a4,s2,800002f8 <consoleintr+0x3c>
      cons.e--;
    800003b6:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    800003ba:	10000513          	li	a0,256
    800003be:	00000097          	auipc	ra,0x0
    800003c2:	ebc080e7          	jalr	-324(ra) # 8000027a <consputc>
    while(cons.e != cons.w &&
    800003c6:	0a04a783          	lw	a5,160(s1)
    800003ca:	09c4a703          	lw	a4,156(s1)
    800003ce:	fcf71ce3          	bne	a4,a5,800003a6 <consoleintr+0xea>
    800003d2:	b71d                	j	800002f8 <consoleintr+0x3c>
    if(cons.e != cons.w){
    800003d4:	00010717          	auipc	a4,0x10
    800003d8:	65c70713          	addi	a4,a4,1628 # 80010a30 <cons>
    800003dc:	0a072783          	lw	a5,160(a4)
    800003e0:	09c72703          	lw	a4,156(a4)
    800003e4:	f0f70ae3          	beq	a4,a5,800002f8 <consoleintr+0x3c>
      cons.e--;
    800003e8:	37fd                	addiw	a5,a5,-1
    800003ea:	00010717          	auipc	a4,0x10
    800003ee:	6ef72323          	sw	a5,1766(a4) # 80010ad0 <cons+0xa0>
      consputc(BACKSPACE);
    800003f2:	10000513          	li	a0,256
    800003f6:	00000097          	auipc	ra,0x0
    800003fa:	e84080e7          	jalr	-380(ra) # 8000027a <consputc>
    800003fe:	bded                	j	800002f8 <consoleintr+0x3c>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80000400:	ee048ce3          	beqz	s1,800002f8 <consoleintr+0x3c>
    80000404:	bf21                	j	8000031c <consoleintr+0x60>
      consputc(c);
    80000406:	4529                	li	a0,10
    80000408:	00000097          	auipc	ra,0x0
    8000040c:	e72080e7          	jalr	-398(ra) # 8000027a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000410:	00010797          	auipc	a5,0x10
    80000414:	62078793          	addi	a5,a5,1568 # 80010a30 <cons>
    80000418:	0a07a703          	lw	a4,160(a5)
    8000041c:	0017069b          	addiw	a3,a4,1
    80000420:	0006861b          	sext.w	a2,a3
    80000424:	0ad7a023          	sw	a3,160(a5)
    80000428:	07f77713          	andi	a4,a4,127
    8000042c:	97ba                	add	a5,a5,a4
    8000042e:	4729                	li	a4,10
    80000430:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    80000434:	00010797          	auipc	a5,0x10
    80000438:	68c7ac23          	sw	a2,1688(a5) # 80010acc <cons+0x9c>
        wakeup(&cons.r);
    8000043c:	00010517          	auipc	a0,0x10
    80000440:	68c50513          	addi	a0,a0,1676 # 80010ac8 <cons+0x98>
    80000444:	00002097          	auipc	ra,0x2
    80000448:	d88080e7          	jalr	-632(ra) # 800021cc <wakeup>
    8000044c:	b575                	j	800002f8 <consoleintr+0x3c>

000000008000044e <consoleinit>:

void
consoleinit(void)
{
    8000044e:	1141                	addi	sp,sp,-16
    80000450:	e406                	sd	ra,8(sp)
    80000452:	e022                	sd	s0,0(sp)
    80000454:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80000456:	00008597          	auipc	a1,0x8
    8000045a:	bba58593          	addi	a1,a1,-1094 # 80008010 <etext+0x10>
    8000045e:	00010517          	auipc	a0,0x10
    80000462:	5d250513          	addi	a0,a0,1490 # 80010a30 <cons>
    80000466:	00000097          	auipc	ra,0x0
    8000046a:	6de080e7          	jalr	1758(ra) # 80000b44 <initlock>

  uartinit();
    8000046e:	00000097          	auipc	ra,0x0
    80000472:	32c080e7          	jalr	812(ra) # 8000079a <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000476:	00021797          	auipc	a5,0x21
    8000047a:	b5278793          	addi	a5,a5,-1198 # 80020fc8 <devsw>
    8000047e:	00000717          	auipc	a4,0x0
    80000482:	ce470713          	addi	a4,a4,-796 # 80000162 <consoleread>
    80000486:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80000488:	00000717          	auipc	a4,0x0
    8000048c:	c7670713          	addi	a4,a4,-906 # 800000fe <consolewrite>
    80000490:	ef98                	sd	a4,24(a5)
}
    80000492:	60a2                	ld	ra,8(sp)
    80000494:	6402                	ld	s0,0(sp)
    80000496:	0141                	addi	sp,sp,16
    80000498:	8082                	ret

000000008000049a <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(int xx, int base, int sign)
{
    8000049a:	7179                	addi	sp,sp,-48
    8000049c:	f406                	sd	ra,40(sp)
    8000049e:	f022                	sd	s0,32(sp)
    800004a0:	ec26                	sd	s1,24(sp)
    800004a2:	e84a                	sd	s2,16(sp)
    800004a4:	1800                	addi	s0,sp,48
  char buf[16];
  int i;
  uint x;

  if(sign && (sign = xx < 0))
    800004a6:	c219                	beqz	a2,800004ac <printint+0x12>
    800004a8:	08054763          	bltz	a0,80000536 <printint+0x9c>
    x = -xx;
  else
    x = xx;
    800004ac:	2501                	sext.w	a0,a0
    800004ae:	4881                	li	a7,0
    800004b0:	fd040693          	addi	a3,s0,-48

  i = 0;
    800004b4:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    800004b6:	2581                	sext.w	a1,a1
    800004b8:	00008617          	auipc	a2,0x8
    800004bc:	b8860613          	addi	a2,a2,-1144 # 80008040 <digits>
    800004c0:	883a                	mv	a6,a4
    800004c2:	2705                	addiw	a4,a4,1
    800004c4:	02b577bb          	remuw	a5,a0,a1
    800004c8:	1782                	slli	a5,a5,0x20
    800004ca:	9381                	srli	a5,a5,0x20
    800004cc:	97b2                	add	a5,a5,a2
    800004ce:	0007c783          	lbu	a5,0(a5)
    800004d2:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    800004d6:	0005079b          	sext.w	a5,a0
    800004da:	02b5553b          	divuw	a0,a0,a1
    800004de:	0685                	addi	a3,a3,1
    800004e0:	feb7f0e3          	bgeu	a5,a1,800004c0 <printint+0x26>

  if(sign)
    800004e4:	00088c63          	beqz	a7,800004fc <printint+0x62>
    buf[i++] = '-';
    800004e8:	fe070793          	addi	a5,a4,-32
    800004ec:	00878733          	add	a4,a5,s0
    800004f0:	02d00793          	li	a5,45
    800004f4:	fef70823          	sb	a5,-16(a4)
    800004f8:	0028071b          	addiw	a4,a6,2

  while(--i >= 0)
    800004fc:	02e05763          	blez	a4,8000052a <printint+0x90>
    80000500:	fd040793          	addi	a5,s0,-48
    80000504:	00e784b3          	add	s1,a5,a4
    80000508:	fff78913          	addi	s2,a5,-1
    8000050c:	993a                	add	s2,s2,a4
    8000050e:	377d                	addiw	a4,a4,-1
    80000510:	1702                	slli	a4,a4,0x20
    80000512:	9301                	srli	a4,a4,0x20
    80000514:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    80000518:	fff4c503          	lbu	a0,-1(s1)
    8000051c:	00000097          	auipc	ra,0x0
    80000520:	d5e080e7          	jalr	-674(ra) # 8000027a <consputc>
  while(--i >= 0)
    80000524:	14fd                	addi	s1,s1,-1
    80000526:	ff2499e3          	bne	s1,s2,80000518 <printint+0x7e>
}
    8000052a:	70a2                	ld	ra,40(sp)
    8000052c:	7402                	ld	s0,32(sp)
    8000052e:	64e2                	ld	s1,24(sp)
    80000530:	6942                	ld	s2,16(sp)
    80000532:	6145                	addi	sp,sp,48
    80000534:	8082                	ret
    x = -xx;
    80000536:	40a0053b          	negw	a0,a0
  if(sign && (sign = xx < 0))
    8000053a:	4885                	li	a7,1
    x = -xx;
    8000053c:	bf95                	j	800004b0 <printint+0x16>

000000008000053e <panic>:
    release(&pr.lock);
}

void
panic(char *s)
{
    8000053e:	1101                	addi	sp,sp,-32
    80000540:	ec06                	sd	ra,24(sp)
    80000542:	e822                	sd	s0,16(sp)
    80000544:	e426                	sd	s1,8(sp)
    80000546:	1000                	addi	s0,sp,32
    80000548:	84aa                	mv	s1,a0
  pr.locking = 0;
    8000054a:	00010797          	auipc	a5,0x10
    8000054e:	5a07a323          	sw	zero,1446(a5) # 80010af0 <pr+0x18>
  printf("panic: ");
    80000552:	00008517          	auipc	a0,0x8
    80000556:	ac650513          	addi	a0,a0,-1338 # 80008018 <etext+0x18>
    8000055a:	00000097          	auipc	ra,0x0
    8000055e:	02e080e7          	jalr	46(ra) # 80000588 <printf>
  printf(s);
    80000562:	8526                	mv	a0,s1
    80000564:	00000097          	auipc	ra,0x0
    80000568:	024080e7          	jalr	36(ra) # 80000588 <printf>
  printf("\n");
    8000056c:	00008517          	auipc	a0,0x8
    80000570:	b5c50513          	addi	a0,a0,-1188 # 800080c8 <digits+0x88>
    80000574:	00000097          	auipc	ra,0x0
    80000578:	014080e7          	jalr	20(ra) # 80000588 <printf>
  panicked = 1; // freeze uart output from other CPUs
    8000057c:	4785                	li	a5,1
    8000057e:	00008717          	auipc	a4,0x8
    80000582:	32f72923          	sw	a5,818(a4) # 800088b0 <panicked>
  for(;;)
    80000586:	a001                	j	80000586 <panic+0x48>

0000000080000588 <printf>:
{
    80000588:	7131                	addi	sp,sp,-192
    8000058a:	fc86                	sd	ra,120(sp)
    8000058c:	f8a2                	sd	s0,112(sp)
    8000058e:	f4a6                	sd	s1,104(sp)
    80000590:	f0ca                	sd	s2,96(sp)
    80000592:	ecce                	sd	s3,88(sp)
    80000594:	e8d2                	sd	s4,80(sp)
    80000596:	e4d6                	sd	s5,72(sp)
    80000598:	e0da                	sd	s6,64(sp)
    8000059a:	fc5e                	sd	s7,56(sp)
    8000059c:	f862                	sd	s8,48(sp)
    8000059e:	f466                	sd	s9,40(sp)
    800005a0:	f06a                	sd	s10,32(sp)
    800005a2:	ec6e                	sd	s11,24(sp)
    800005a4:	0100                	addi	s0,sp,128
    800005a6:	8a2a                	mv	s4,a0
    800005a8:	e40c                	sd	a1,8(s0)
    800005aa:	e810                	sd	a2,16(s0)
    800005ac:	ec14                	sd	a3,24(s0)
    800005ae:	f018                	sd	a4,32(s0)
    800005b0:	f41c                	sd	a5,40(s0)
    800005b2:	03043823          	sd	a6,48(s0)
    800005b6:	03143c23          	sd	a7,56(s0)
  locking = pr.locking;
    800005ba:	00010d97          	auipc	s11,0x10
    800005be:	536dad83          	lw	s11,1334(s11) # 80010af0 <pr+0x18>
  if(locking)
    800005c2:	020d9b63          	bnez	s11,800005f8 <printf+0x70>
  if (fmt == 0)
    800005c6:	040a0263          	beqz	s4,8000060a <printf+0x82>
  va_start(ap, fmt);
    800005ca:	00840793          	addi	a5,s0,8
    800005ce:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
    800005d2:	000a4503          	lbu	a0,0(s4)
    800005d6:	14050f63          	beqz	a0,80000734 <printf+0x1ac>
    800005da:	4981                	li	s3,0
    if(c != '%'){
    800005dc:	02500a93          	li	s5,37
    switch(c){
    800005e0:	07000b93          	li	s7,112
  consputc('x');
    800005e4:	4d41                	li	s10,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800005e6:	00008b17          	auipc	s6,0x8
    800005ea:	a5ab0b13          	addi	s6,s6,-1446 # 80008040 <digits>
    switch(c){
    800005ee:	07300c93          	li	s9,115
    800005f2:	06400c13          	li	s8,100
    800005f6:	a82d                	j	80000630 <printf+0xa8>
    acquire(&pr.lock);
    800005f8:	00010517          	auipc	a0,0x10
    800005fc:	4e050513          	addi	a0,a0,1248 # 80010ad8 <pr>
    80000600:	00000097          	auipc	ra,0x0
    80000604:	5d4080e7          	jalr	1492(ra) # 80000bd4 <acquire>
    80000608:	bf7d                	j	800005c6 <printf+0x3e>
    panic("null fmt");
    8000060a:	00008517          	auipc	a0,0x8
    8000060e:	a1e50513          	addi	a0,a0,-1506 # 80008028 <etext+0x28>
    80000612:	00000097          	auipc	ra,0x0
    80000616:	f2c080e7          	jalr	-212(ra) # 8000053e <panic>
      consputc(c);
    8000061a:	00000097          	auipc	ra,0x0
    8000061e:	c60080e7          	jalr	-928(ra) # 8000027a <consputc>
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
    80000622:	2985                	addiw	s3,s3,1
    80000624:	013a07b3          	add	a5,s4,s3
    80000628:	0007c503          	lbu	a0,0(a5)
    8000062c:	10050463          	beqz	a0,80000734 <printf+0x1ac>
    if(c != '%'){
    80000630:	ff5515e3          	bne	a0,s5,8000061a <printf+0x92>
    c = fmt[++i] & 0xff;
    80000634:	2985                	addiw	s3,s3,1
    80000636:	013a07b3          	add	a5,s4,s3
    8000063a:	0007c783          	lbu	a5,0(a5)
    8000063e:	0007849b          	sext.w	s1,a5
    if(c == 0)
    80000642:	cbed                	beqz	a5,80000734 <printf+0x1ac>
    switch(c){
    80000644:	05778a63          	beq	a5,s7,80000698 <printf+0x110>
    80000648:	02fbf663          	bgeu	s7,a5,80000674 <printf+0xec>
    8000064c:	09978863          	beq	a5,s9,800006dc <printf+0x154>
    80000650:	07800713          	li	a4,120
    80000654:	0ce79563          	bne	a5,a4,8000071e <printf+0x196>
      printint(va_arg(ap, int), 16, 1);
    80000658:	f8843783          	ld	a5,-120(s0)
    8000065c:	00878713          	addi	a4,a5,8
    80000660:	f8e43423          	sd	a4,-120(s0)
    80000664:	4605                	li	a2,1
    80000666:	85ea                	mv	a1,s10
    80000668:	4388                	lw	a0,0(a5)
    8000066a:	00000097          	auipc	ra,0x0
    8000066e:	e30080e7          	jalr	-464(ra) # 8000049a <printint>
      break;
    80000672:	bf45                	j	80000622 <printf+0x9a>
    switch(c){
    80000674:	09578f63          	beq	a5,s5,80000712 <printf+0x18a>
    80000678:	0b879363          	bne	a5,s8,8000071e <printf+0x196>
      printint(va_arg(ap, int), 10, 1);
    8000067c:	f8843783          	ld	a5,-120(s0)
    80000680:	00878713          	addi	a4,a5,8
    80000684:	f8e43423          	sd	a4,-120(s0)
    80000688:	4605                	li	a2,1
    8000068a:	45a9                	li	a1,10
    8000068c:	4388                	lw	a0,0(a5)
    8000068e:	00000097          	auipc	ra,0x0
    80000692:	e0c080e7          	jalr	-500(ra) # 8000049a <printint>
      break;
    80000696:	b771                	j	80000622 <printf+0x9a>
      printptr(va_arg(ap, uint64));
    80000698:	f8843783          	ld	a5,-120(s0)
    8000069c:	00878713          	addi	a4,a5,8
    800006a0:	f8e43423          	sd	a4,-120(s0)
    800006a4:	0007b903          	ld	s2,0(a5)
  consputc('0');
    800006a8:	03000513          	li	a0,48
    800006ac:	00000097          	auipc	ra,0x0
    800006b0:	bce080e7          	jalr	-1074(ra) # 8000027a <consputc>
  consputc('x');
    800006b4:	07800513          	li	a0,120
    800006b8:	00000097          	auipc	ra,0x0
    800006bc:	bc2080e7          	jalr	-1086(ra) # 8000027a <consputc>
    800006c0:	84ea                	mv	s1,s10
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006c2:	03c95793          	srli	a5,s2,0x3c
    800006c6:	97da                	add	a5,a5,s6
    800006c8:	0007c503          	lbu	a0,0(a5)
    800006cc:	00000097          	auipc	ra,0x0
    800006d0:	bae080e7          	jalr	-1106(ra) # 8000027a <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006d4:	0912                	slli	s2,s2,0x4
    800006d6:	34fd                	addiw	s1,s1,-1
    800006d8:	f4ed                	bnez	s1,800006c2 <printf+0x13a>
    800006da:	b7a1                	j	80000622 <printf+0x9a>
      if((s = va_arg(ap, char*)) == 0)
    800006dc:	f8843783          	ld	a5,-120(s0)
    800006e0:	00878713          	addi	a4,a5,8
    800006e4:	f8e43423          	sd	a4,-120(s0)
    800006e8:	6384                	ld	s1,0(a5)
    800006ea:	cc89                	beqz	s1,80000704 <printf+0x17c>
      for(; *s; s++)
    800006ec:	0004c503          	lbu	a0,0(s1)
    800006f0:	d90d                	beqz	a0,80000622 <printf+0x9a>
        consputc(*s);
    800006f2:	00000097          	auipc	ra,0x0
    800006f6:	b88080e7          	jalr	-1144(ra) # 8000027a <consputc>
      for(; *s; s++)
    800006fa:	0485                	addi	s1,s1,1
    800006fc:	0004c503          	lbu	a0,0(s1)
    80000700:	f96d                	bnez	a0,800006f2 <printf+0x16a>
    80000702:	b705                	j	80000622 <printf+0x9a>
        s = "(null)";
    80000704:	00008497          	auipc	s1,0x8
    80000708:	91c48493          	addi	s1,s1,-1764 # 80008020 <etext+0x20>
      for(; *s; s++)
    8000070c:	02800513          	li	a0,40
    80000710:	b7cd                	j	800006f2 <printf+0x16a>
      consputc('%');
    80000712:	8556                	mv	a0,s5
    80000714:	00000097          	auipc	ra,0x0
    80000718:	b66080e7          	jalr	-1178(ra) # 8000027a <consputc>
      break;
    8000071c:	b719                	j	80000622 <printf+0x9a>
      consputc('%');
    8000071e:	8556                	mv	a0,s5
    80000720:	00000097          	auipc	ra,0x0
    80000724:	b5a080e7          	jalr	-1190(ra) # 8000027a <consputc>
      consputc(c);
    80000728:	8526                	mv	a0,s1
    8000072a:	00000097          	auipc	ra,0x0
    8000072e:	b50080e7          	jalr	-1200(ra) # 8000027a <consputc>
      break;
    80000732:	bdc5                	j	80000622 <printf+0x9a>
  if(locking)
    80000734:	020d9163          	bnez	s11,80000756 <printf+0x1ce>
}
    80000738:	70e6                	ld	ra,120(sp)
    8000073a:	7446                	ld	s0,112(sp)
    8000073c:	74a6                	ld	s1,104(sp)
    8000073e:	7906                	ld	s2,96(sp)
    80000740:	69e6                	ld	s3,88(sp)
    80000742:	6a46                	ld	s4,80(sp)
    80000744:	6aa6                	ld	s5,72(sp)
    80000746:	6b06                	ld	s6,64(sp)
    80000748:	7be2                	ld	s7,56(sp)
    8000074a:	7c42                	ld	s8,48(sp)
    8000074c:	7ca2                	ld	s9,40(sp)
    8000074e:	7d02                	ld	s10,32(sp)
    80000750:	6de2                	ld	s11,24(sp)
    80000752:	6129                	addi	sp,sp,192
    80000754:	8082                	ret
    release(&pr.lock);
    80000756:	00010517          	auipc	a0,0x10
    8000075a:	38250513          	addi	a0,a0,898 # 80010ad8 <pr>
    8000075e:	00000097          	auipc	ra,0x0
    80000762:	52a080e7          	jalr	1322(ra) # 80000c88 <release>
}
    80000766:	bfc9                	j	80000738 <printf+0x1b0>

0000000080000768 <printfinit>:
    ;
}

void
printfinit(void)
{
    80000768:	1101                	addi	sp,sp,-32
    8000076a:	ec06                	sd	ra,24(sp)
    8000076c:	e822                	sd	s0,16(sp)
    8000076e:	e426                	sd	s1,8(sp)
    80000770:	1000                	addi	s0,sp,32
  initlock(&pr.lock, "pr");
    80000772:	00010497          	auipc	s1,0x10
    80000776:	36648493          	addi	s1,s1,870 # 80010ad8 <pr>
    8000077a:	00008597          	auipc	a1,0x8
    8000077e:	8be58593          	addi	a1,a1,-1858 # 80008038 <etext+0x38>
    80000782:	8526                	mv	a0,s1
    80000784:	00000097          	auipc	ra,0x0
    80000788:	3c0080e7          	jalr	960(ra) # 80000b44 <initlock>
  pr.locking = 1;
    8000078c:	4785                	li	a5,1
    8000078e:	cc9c                	sw	a5,24(s1)
}
    80000790:	60e2                	ld	ra,24(sp)
    80000792:	6442                	ld	s0,16(sp)
    80000794:	64a2                	ld	s1,8(sp)
    80000796:	6105                	addi	sp,sp,32
    80000798:	8082                	ret

000000008000079a <uartinit>:

void uartstart();

void
uartinit(void)
{
    8000079a:	1141                	addi	sp,sp,-16
    8000079c:	e406                	sd	ra,8(sp)
    8000079e:	e022                	sd	s0,0(sp)
    800007a0:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    800007a2:	100007b7          	lui	a5,0x10000
    800007a6:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    800007aa:	f8000713          	li	a4,-128
    800007ae:	00e781a3          	sb	a4,3(a5)

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    800007b2:	470d                	li	a4,3
    800007b4:	00e78023          	sb	a4,0(a5)

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    800007b8:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    800007bc:	00e781a3          	sb	a4,3(a5)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    800007c0:	469d                	li	a3,7
    800007c2:	00d78123          	sb	a3,2(a5)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    800007c6:	00e780a3          	sb	a4,1(a5)

  initlock(&uart_tx_lock, "uart");
    800007ca:	00008597          	auipc	a1,0x8
    800007ce:	88e58593          	addi	a1,a1,-1906 # 80008058 <digits+0x18>
    800007d2:	00010517          	auipc	a0,0x10
    800007d6:	32650513          	addi	a0,a0,806 # 80010af8 <uart_tx_lock>
    800007da:	00000097          	auipc	ra,0x0
    800007de:	36a080e7          	jalr	874(ra) # 80000b44 <initlock>
}
    800007e2:	60a2                	ld	ra,8(sp)
    800007e4:	6402                	ld	s0,0(sp)
    800007e6:	0141                	addi	sp,sp,16
    800007e8:	8082                	ret

00000000800007ea <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    800007ea:	1101                	addi	sp,sp,-32
    800007ec:	ec06                	sd	ra,24(sp)
    800007ee:	e822                	sd	s0,16(sp)
    800007f0:	e426                	sd	s1,8(sp)
    800007f2:	1000                	addi	s0,sp,32
    800007f4:	84aa                	mv	s1,a0
  push_off();
    800007f6:	00000097          	auipc	ra,0x0
    800007fa:	392080e7          	jalr	914(ra) # 80000b88 <push_off>

  if(panicked){
    800007fe:	00008797          	auipc	a5,0x8
    80000802:	0b27a783          	lw	a5,178(a5) # 800088b0 <panicked>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    80000806:	10000737          	lui	a4,0x10000
  if(panicked){
    8000080a:	c391                	beqz	a5,8000080e <uartputc_sync+0x24>
    for(;;)
    8000080c:	a001                	j	8000080c <uartputc_sync+0x22>
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000080e:	00574783          	lbu	a5,5(a4) # 10000005 <_entry-0x6ffffffb>
    80000812:	0207f793          	andi	a5,a5,32
    80000816:	dfe5                	beqz	a5,8000080e <uartputc_sync+0x24>
    ;
  WriteReg(THR, c);
    80000818:	0ff4f513          	zext.b	a0,s1
    8000081c:	100007b7          	lui	a5,0x10000
    80000820:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  pop_off();
    80000824:	00000097          	auipc	ra,0x0
    80000828:	404080e7          	jalr	1028(ra) # 80000c28 <pop_off>
}
    8000082c:	60e2                	ld	ra,24(sp)
    8000082e:	6442                	ld	s0,16(sp)
    80000830:	64a2                	ld	s1,8(sp)
    80000832:	6105                	addi	sp,sp,32
    80000834:	8082                	ret

0000000080000836 <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    80000836:	00008797          	auipc	a5,0x8
    8000083a:	0827b783          	ld	a5,130(a5) # 800088b8 <uart_tx_r>
    8000083e:	00008717          	auipc	a4,0x8
    80000842:	08273703          	ld	a4,130(a4) # 800088c0 <uart_tx_w>
    80000846:	06f70a63          	beq	a4,a5,800008ba <uartstart+0x84>
{
    8000084a:	7139                	addi	sp,sp,-64
    8000084c:	fc06                	sd	ra,56(sp)
    8000084e:	f822                	sd	s0,48(sp)
    80000850:	f426                	sd	s1,40(sp)
    80000852:	f04a                	sd	s2,32(sp)
    80000854:	ec4e                	sd	s3,24(sp)
    80000856:	e852                	sd	s4,16(sp)
    80000858:	e456                	sd	s5,8(sp)
    8000085a:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    8000085c:	10000937          	lui	s2,0x10000
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80000860:	00010a17          	auipc	s4,0x10
    80000864:	298a0a13          	addi	s4,s4,664 # 80010af8 <uart_tx_lock>
    uart_tx_r += 1;
    80000868:	00008497          	auipc	s1,0x8
    8000086c:	05048493          	addi	s1,s1,80 # 800088b8 <uart_tx_r>
    if(uart_tx_w == uart_tx_r){
    80000870:	00008997          	auipc	s3,0x8
    80000874:	05098993          	addi	s3,s3,80 # 800088c0 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    80000878:	00594703          	lbu	a4,5(s2) # 10000005 <_entry-0x6ffffffb>
    8000087c:	02077713          	andi	a4,a4,32
    80000880:	c705                	beqz	a4,800008a8 <uartstart+0x72>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80000882:	01f7f713          	andi	a4,a5,31
    80000886:	9752                	add	a4,a4,s4
    80000888:	01874a83          	lbu	s5,24(a4)
    uart_tx_r += 1;
    8000088c:	0785                	addi	a5,a5,1
    8000088e:	e09c                	sd	a5,0(s1)
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    80000890:	8526                	mv	a0,s1
    80000892:	00002097          	auipc	ra,0x2
    80000896:	93a080e7          	jalr	-1734(ra) # 800021cc <wakeup>
    
    WriteReg(THR, c);
    8000089a:	01590023          	sb	s5,0(s2)
    if(uart_tx_w == uart_tx_r){
    8000089e:	609c                	ld	a5,0(s1)
    800008a0:	0009b703          	ld	a4,0(s3)
    800008a4:	fcf71ae3          	bne	a4,a5,80000878 <uartstart+0x42>
  }
}
    800008a8:	70e2                	ld	ra,56(sp)
    800008aa:	7442                	ld	s0,48(sp)
    800008ac:	74a2                	ld	s1,40(sp)
    800008ae:	7902                	ld	s2,32(sp)
    800008b0:	69e2                	ld	s3,24(sp)
    800008b2:	6a42                	ld	s4,16(sp)
    800008b4:	6aa2                	ld	s5,8(sp)
    800008b6:	6121                	addi	sp,sp,64
    800008b8:	8082                	ret
    800008ba:	8082                	ret

00000000800008bc <uartputc>:
{
    800008bc:	7179                	addi	sp,sp,-48
    800008be:	f406                	sd	ra,40(sp)
    800008c0:	f022                	sd	s0,32(sp)
    800008c2:	ec26                	sd	s1,24(sp)
    800008c4:	e84a                	sd	s2,16(sp)
    800008c6:	e44e                	sd	s3,8(sp)
    800008c8:	e052                	sd	s4,0(sp)
    800008ca:	1800                	addi	s0,sp,48
    800008cc:	8a2a                	mv	s4,a0
  acquire(&uart_tx_lock);
    800008ce:	00010517          	auipc	a0,0x10
    800008d2:	22a50513          	addi	a0,a0,554 # 80010af8 <uart_tx_lock>
    800008d6:	00000097          	auipc	ra,0x0
    800008da:	2fe080e7          	jalr	766(ra) # 80000bd4 <acquire>
  if(panicked){
    800008de:	00008797          	auipc	a5,0x8
    800008e2:	fd27a783          	lw	a5,-46(a5) # 800088b0 <panicked>
    800008e6:	e7c9                	bnez	a5,80000970 <uartputc+0xb4>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800008e8:	00008717          	auipc	a4,0x8
    800008ec:	fd873703          	ld	a4,-40(a4) # 800088c0 <uart_tx_w>
    800008f0:	00008797          	auipc	a5,0x8
    800008f4:	fc87b783          	ld	a5,-56(a5) # 800088b8 <uart_tx_r>
    800008f8:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    800008fc:	00010997          	auipc	s3,0x10
    80000900:	1fc98993          	addi	s3,s3,508 # 80010af8 <uart_tx_lock>
    80000904:	00008497          	auipc	s1,0x8
    80000908:	fb448493          	addi	s1,s1,-76 # 800088b8 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    8000090c:	00008917          	auipc	s2,0x8
    80000910:	fb490913          	addi	s2,s2,-76 # 800088c0 <uart_tx_w>
    80000914:	00e79f63          	bne	a5,a4,80000932 <uartputc+0x76>
    sleep(&uart_tx_r, &uart_tx_lock);
    80000918:	85ce                	mv	a1,s3
    8000091a:	8526                	mv	a0,s1
    8000091c:	00002097          	auipc	ra,0x2
    80000920:	83a080e7          	jalr	-1990(ra) # 80002156 <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    80000924:	00093703          	ld	a4,0(s2)
    80000928:	609c                	ld	a5,0(s1)
    8000092a:	02078793          	addi	a5,a5,32
    8000092e:	fee785e3          	beq	a5,a4,80000918 <uartputc+0x5c>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    80000932:	00010497          	auipc	s1,0x10
    80000936:	1c648493          	addi	s1,s1,454 # 80010af8 <uart_tx_lock>
    8000093a:	01f77793          	andi	a5,a4,31
    8000093e:	97a6                	add	a5,a5,s1
    80000940:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    80000944:	0705                	addi	a4,a4,1
    80000946:	00008797          	auipc	a5,0x8
    8000094a:	f6e7bd23          	sd	a4,-134(a5) # 800088c0 <uart_tx_w>
  uartstart();
    8000094e:	00000097          	auipc	ra,0x0
    80000952:	ee8080e7          	jalr	-280(ra) # 80000836 <uartstart>
  release(&uart_tx_lock);
    80000956:	8526                	mv	a0,s1
    80000958:	00000097          	auipc	ra,0x0
    8000095c:	330080e7          	jalr	816(ra) # 80000c88 <release>
}
    80000960:	70a2                	ld	ra,40(sp)
    80000962:	7402                	ld	s0,32(sp)
    80000964:	64e2                	ld	s1,24(sp)
    80000966:	6942                	ld	s2,16(sp)
    80000968:	69a2                	ld	s3,8(sp)
    8000096a:	6a02                	ld	s4,0(sp)
    8000096c:	6145                	addi	sp,sp,48
    8000096e:	8082                	ret
    for(;;)
    80000970:	a001                	j	80000970 <uartputc+0xb4>

0000000080000972 <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    80000972:	1141                	addi	sp,sp,-16
    80000974:	e422                	sd	s0,8(sp)
    80000976:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & 0x01){
    80000978:	100007b7          	lui	a5,0x10000
    8000097c:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80000980:	8b85                	andi	a5,a5,1
    80000982:	cb81                	beqz	a5,80000992 <uartgetc+0x20>
    // input data is ready.
    return ReadReg(RHR);
    80000984:	100007b7          	lui	a5,0x10000
    80000988:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    8000098c:	6422                	ld	s0,8(sp)
    8000098e:	0141                	addi	sp,sp,16
    80000990:	8082                	ret
    return -1;
    80000992:	557d                	li	a0,-1
    80000994:	bfe5                	j	8000098c <uartgetc+0x1a>

0000000080000996 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    80000996:	1101                	addi	sp,sp,-32
    80000998:	ec06                	sd	ra,24(sp)
    8000099a:	e822                	sd	s0,16(sp)
    8000099c:	e426                	sd	s1,8(sp)
    8000099e:	1000                	addi	s0,sp,32
  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    800009a0:	54fd                	li	s1,-1
    800009a2:	a029                	j	800009ac <uartintr+0x16>
      break;
    consoleintr(c);
    800009a4:	00000097          	auipc	ra,0x0
    800009a8:	918080e7          	jalr	-1768(ra) # 800002bc <consoleintr>
    int c = uartgetc();
    800009ac:	00000097          	auipc	ra,0x0
    800009b0:	fc6080e7          	jalr	-58(ra) # 80000972 <uartgetc>
    if(c == -1)
    800009b4:	fe9518e3          	bne	a0,s1,800009a4 <uartintr+0xe>
  }

  // send buffered characters.
  acquire(&uart_tx_lock);
    800009b8:	00010497          	auipc	s1,0x10
    800009bc:	14048493          	addi	s1,s1,320 # 80010af8 <uart_tx_lock>
    800009c0:	8526                	mv	a0,s1
    800009c2:	00000097          	auipc	ra,0x0
    800009c6:	212080e7          	jalr	530(ra) # 80000bd4 <acquire>
  uartstart();
    800009ca:	00000097          	auipc	ra,0x0
    800009ce:	e6c080e7          	jalr	-404(ra) # 80000836 <uartstart>
  release(&uart_tx_lock);
    800009d2:	8526                	mv	a0,s1
    800009d4:	00000097          	auipc	ra,0x0
    800009d8:	2b4080e7          	jalr	692(ra) # 80000c88 <release>
}
    800009dc:	60e2                	ld	ra,24(sp)
    800009de:	6442                	ld	s0,16(sp)
    800009e0:	64a2                	ld	s1,8(sp)
    800009e2:	6105                	addi	sp,sp,32
    800009e4:	8082                	ret

00000000800009e6 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    800009e6:	1101                	addi	sp,sp,-32
    800009e8:	ec06                	sd	ra,24(sp)
    800009ea:	e822                	sd	s0,16(sp)
    800009ec:	e426                	sd	s1,8(sp)
    800009ee:	e04a                	sd	s2,0(sp)
    800009f0:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    800009f2:	03451793          	slli	a5,a0,0x34
    800009f6:	ebb9                	bnez	a5,80000a4c <kfree+0x66>
    800009f8:	84aa                	mv	s1,a0
    800009fa:	00021797          	auipc	a5,0x21
    800009fe:	76678793          	addi	a5,a5,1894 # 80022160 <end>
    80000a02:	04f56563          	bltu	a0,a5,80000a4c <kfree+0x66>
    80000a06:	47c5                	li	a5,17
    80000a08:	07ee                	slli	a5,a5,0x1b
    80000a0a:	04f57163          	bgeu	a0,a5,80000a4c <kfree+0x66>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a0e:	6605                	lui	a2,0x1
    80000a10:	4585                	li	a1,1
    80000a12:	00000097          	auipc	ra,0x0
    80000a16:	2be080e7          	jalr	702(ra) # 80000cd0 <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000a1a:	00010917          	auipc	s2,0x10
    80000a1e:	11690913          	addi	s2,s2,278 # 80010b30 <kmem>
    80000a22:	854a                	mv	a0,s2
    80000a24:	00000097          	auipc	ra,0x0
    80000a28:	1b0080e7          	jalr	432(ra) # 80000bd4 <acquire>
  r->next = kmem.freelist;
    80000a2c:	01893783          	ld	a5,24(s2)
    80000a30:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000a32:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000a36:	854a                	mv	a0,s2
    80000a38:	00000097          	auipc	ra,0x0
    80000a3c:	250080e7          	jalr	592(ra) # 80000c88 <release>
}
    80000a40:	60e2                	ld	ra,24(sp)
    80000a42:	6442                	ld	s0,16(sp)
    80000a44:	64a2                	ld	s1,8(sp)
    80000a46:	6902                	ld	s2,0(sp)
    80000a48:	6105                	addi	sp,sp,32
    80000a4a:	8082                	ret
    panic("kfree");
    80000a4c:	00007517          	auipc	a0,0x7
    80000a50:	61450513          	addi	a0,a0,1556 # 80008060 <digits+0x20>
    80000a54:	00000097          	auipc	ra,0x0
    80000a58:	aea080e7          	jalr	-1302(ra) # 8000053e <panic>

0000000080000a5c <freerange>:
{
    80000a5c:	7179                	addi	sp,sp,-48
    80000a5e:	f406                	sd	ra,40(sp)
    80000a60:	f022                	sd	s0,32(sp)
    80000a62:	ec26                	sd	s1,24(sp)
    80000a64:	e84a                	sd	s2,16(sp)
    80000a66:	e44e                	sd	s3,8(sp)
    80000a68:	e052                	sd	s4,0(sp)
    80000a6a:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000a6c:	6785                	lui	a5,0x1
    80000a6e:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000a72:	00e504b3          	add	s1,a0,a4
    80000a76:	777d                	lui	a4,0xfffff
    80000a78:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000a7a:	94be                	add	s1,s1,a5
    80000a7c:	0095ee63          	bltu	a1,s1,80000a98 <freerange+0x3c>
    80000a80:	892e                	mv	s2,a1
    kfree(p);
    80000a82:	7a7d                	lui	s4,0xfffff
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000a84:	6985                	lui	s3,0x1
    kfree(p);
    80000a86:	01448533          	add	a0,s1,s4
    80000a8a:	00000097          	auipc	ra,0x0
    80000a8e:	f5c080e7          	jalr	-164(ra) # 800009e6 <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000a92:	94ce                	add	s1,s1,s3
    80000a94:	fe9979e3          	bgeu	s2,s1,80000a86 <freerange+0x2a>
}
    80000a98:	70a2                	ld	ra,40(sp)
    80000a9a:	7402                	ld	s0,32(sp)
    80000a9c:	64e2                	ld	s1,24(sp)
    80000a9e:	6942                	ld	s2,16(sp)
    80000aa0:	69a2                	ld	s3,8(sp)
    80000aa2:	6a02                	ld	s4,0(sp)
    80000aa4:	6145                	addi	sp,sp,48
    80000aa6:	8082                	ret

0000000080000aa8 <kinit>:
{
    80000aa8:	1141                	addi	sp,sp,-16
    80000aaa:	e406                	sd	ra,8(sp)
    80000aac:	e022                	sd	s0,0(sp)
    80000aae:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000ab0:	00007597          	auipc	a1,0x7
    80000ab4:	5b858593          	addi	a1,a1,1464 # 80008068 <digits+0x28>
    80000ab8:	00010517          	auipc	a0,0x10
    80000abc:	07850513          	addi	a0,a0,120 # 80010b30 <kmem>
    80000ac0:	00000097          	auipc	ra,0x0
    80000ac4:	084080e7          	jalr	132(ra) # 80000b44 <initlock>
  freerange(end, (void*)PHYSTOP);
    80000ac8:	45c5                	li	a1,17
    80000aca:	05ee                	slli	a1,a1,0x1b
    80000acc:	00021517          	auipc	a0,0x21
    80000ad0:	69450513          	addi	a0,a0,1684 # 80022160 <end>
    80000ad4:	00000097          	auipc	ra,0x0
    80000ad8:	f88080e7          	jalr	-120(ra) # 80000a5c <freerange>
}
    80000adc:	60a2                	ld	ra,8(sp)
    80000ade:	6402                	ld	s0,0(sp)
    80000ae0:	0141                	addi	sp,sp,16
    80000ae2:	8082                	ret

0000000080000ae4 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000ae4:	1101                	addi	sp,sp,-32
    80000ae6:	ec06                	sd	ra,24(sp)
    80000ae8:	e822                	sd	s0,16(sp)
    80000aea:	e426                	sd	s1,8(sp)
    80000aec:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000aee:	00010497          	auipc	s1,0x10
    80000af2:	04248493          	addi	s1,s1,66 # 80010b30 <kmem>
    80000af6:	8526                	mv	a0,s1
    80000af8:	00000097          	auipc	ra,0x0
    80000afc:	0dc080e7          	jalr	220(ra) # 80000bd4 <acquire>
  r = kmem.freelist;
    80000b00:	6c84                	ld	s1,24(s1)
  if(r)
    80000b02:	c885                	beqz	s1,80000b32 <kalloc+0x4e>
    kmem.freelist = r->next;
    80000b04:	609c                	ld	a5,0(s1)
    80000b06:	00010517          	auipc	a0,0x10
    80000b0a:	02a50513          	addi	a0,a0,42 # 80010b30 <kmem>
    80000b0e:	ed1c                	sd	a5,24(a0)
  release(&kmem.lock);
    80000b10:	00000097          	auipc	ra,0x0
    80000b14:	178080e7          	jalr	376(ra) # 80000c88 <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000b18:	6605                	lui	a2,0x1
    80000b1a:	4595                	li	a1,5
    80000b1c:	8526                	mv	a0,s1
    80000b1e:	00000097          	auipc	ra,0x0
    80000b22:	1b2080e7          	jalr	434(ra) # 80000cd0 <memset>
  return (void*)r;
}
    80000b26:	8526                	mv	a0,s1
    80000b28:	60e2                	ld	ra,24(sp)
    80000b2a:	6442                	ld	s0,16(sp)
    80000b2c:	64a2                	ld	s1,8(sp)
    80000b2e:	6105                	addi	sp,sp,32
    80000b30:	8082                	ret
  release(&kmem.lock);
    80000b32:	00010517          	auipc	a0,0x10
    80000b36:	ffe50513          	addi	a0,a0,-2 # 80010b30 <kmem>
    80000b3a:	00000097          	auipc	ra,0x0
    80000b3e:	14e080e7          	jalr	334(ra) # 80000c88 <release>
  if(r)
    80000b42:	b7d5                	j	80000b26 <kalloc+0x42>

0000000080000b44 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000b44:	1141                	addi	sp,sp,-16
    80000b46:	e422                	sd	s0,8(sp)
    80000b48:	0800                	addi	s0,sp,16
  lk->name = name;
    80000b4a:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000b4c:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000b50:	00053823          	sd	zero,16(a0)
}
    80000b54:	6422                	ld	s0,8(sp)
    80000b56:	0141                	addi	sp,sp,16
    80000b58:	8082                	ret

0000000080000b5a <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000b5a:	411c                	lw	a5,0(a0)
    80000b5c:	e399                	bnez	a5,80000b62 <holding+0x8>
    80000b5e:	4501                	li	a0,0
  return r;
}
    80000b60:	8082                	ret
{
    80000b62:	1101                	addi	sp,sp,-32
    80000b64:	ec06                	sd	ra,24(sp)
    80000b66:	e822                	sd	s0,16(sp)
    80000b68:	e426                	sd	s1,8(sp)
    80000b6a:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000b6c:	6904                	ld	s1,16(a0)
    80000b6e:	00001097          	auipc	ra,0x1
    80000b72:	e20080e7          	jalr	-480(ra) # 8000198e <mycpu>
    80000b76:	40a48533          	sub	a0,s1,a0
    80000b7a:	00153513          	seqz	a0,a0
}
    80000b7e:	60e2                	ld	ra,24(sp)
    80000b80:	6442                	ld	s0,16(sp)
    80000b82:	64a2                	ld	s1,8(sp)
    80000b84:	6105                	addi	sp,sp,32
    80000b86:	8082                	ret

0000000080000b88 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000b88:	1101                	addi	sp,sp,-32
    80000b8a:	ec06                	sd	ra,24(sp)
    80000b8c:	e822                	sd	s0,16(sp)
    80000b8e:	e426                	sd	s1,8(sp)
    80000b90:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000b92:	100024f3          	csrr	s1,sstatus
    80000b96:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000b9a:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000b9c:	10079073          	csrw	sstatus,a5
  int old = intr_get();

  intr_off();
  if(mycpu()->noff == 0)
    80000ba0:	00001097          	auipc	ra,0x1
    80000ba4:	dee080e7          	jalr	-530(ra) # 8000198e <mycpu>
    80000ba8:	5d3c                	lw	a5,120(a0)
    80000baa:	cf89                	beqz	a5,80000bc4 <push_off+0x3c>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000bac:	00001097          	auipc	ra,0x1
    80000bb0:	de2080e7          	jalr	-542(ra) # 8000198e <mycpu>
    80000bb4:	5d3c                	lw	a5,120(a0)
    80000bb6:	2785                	addiw	a5,a5,1
    80000bb8:	dd3c                	sw	a5,120(a0)
}
    80000bba:	60e2                	ld	ra,24(sp)
    80000bbc:	6442                	ld	s0,16(sp)
    80000bbe:	64a2                	ld	s1,8(sp)
    80000bc0:	6105                	addi	sp,sp,32
    80000bc2:	8082                	ret
    mycpu()->intena = old;
    80000bc4:	00001097          	auipc	ra,0x1
    80000bc8:	dca080e7          	jalr	-566(ra) # 8000198e <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000bcc:	8085                	srli	s1,s1,0x1
    80000bce:	8885                	andi	s1,s1,1
    80000bd0:	dd64                	sw	s1,124(a0)
    80000bd2:	bfe9                	j	80000bac <push_off+0x24>

0000000080000bd4 <acquire>:
{
    80000bd4:	1101                	addi	sp,sp,-32
    80000bd6:	ec06                	sd	ra,24(sp)
    80000bd8:	e822                	sd	s0,16(sp)
    80000bda:	e426                	sd	s1,8(sp)
    80000bdc:	1000                	addi	s0,sp,32
    80000bde:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000be0:	00000097          	auipc	ra,0x0
    80000be4:	fa8080e7          	jalr	-88(ra) # 80000b88 <push_off>
  if(holding(lk))
    80000be8:	8526                	mv	a0,s1
    80000bea:	00000097          	auipc	ra,0x0
    80000bee:	f70080e7          	jalr	-144(ra) # 80000b5a <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000bf2:	4705                	li	a4,1
  if(holding(lk))
    80000bf4:	e115                	bnez	a0,80000c18 <acquire+0x44>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000bf6:	87ba                	mv	a5,a4
    80000bf8:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000bfc:	2781                	sext.w	a5,a5
    80000bfe:	ffe5                	bnez	a5,80000bf6 <acquire+0x22>
  __sync_synchronize();
    80000c00:	0ff0000f          	fence
  lk->cpu = mycpu();
    80000c04:	00001097          	auipc	ra,0x1
    80000c08:	d8a080e7          	jalr	-630(ra) # 8000198e <mycpu>
    80000c0c:	e888                	sd	a0,16(s1)
}
    80000c0e:	60e2                	ld	ra,24(sp)
    80000c10:	6442                	ld	s0,16(sp)
    80000c12:	64a2                	ld	s1,8(sp)
    80000c14:	6105                	addi	sp,sp,32
    80000c16:	8082                	ret
    panic("acquire");
    80000c18:	00007517          	auipc	a0,0x7
    80000c1c:	45850513          	addi	a0,a0,1112 # 80008070 <digits+0x30>
    80000c20:	00000097          	auipc	ra,0x0
    80000c24:	91e080e7          	jalr	-1762(ra) # 8000053e <panic>

0000000080000c28 <pop_off>:

void
pop_off(void)
{
    80000c28:	1141                	addi	sp,sp,-16
    80000c2a:	e406                	sd	ra,8(sp)
    80000c2c:	e022                	sd	s0,0(sp)
    80000c2e:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c30:	00001097          	auipc	ra,0x1
    80000c34:	d5e080e7          	jalr	-674(ra) # 8000198e <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c38:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000c3c:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000c3e:	e78d                	bnez	a5,80000c68 <pop_off+0x40>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000c40:	5d3c                	lw	a5,120(a0)
    80000c42:	02f05b63          	blez	a5,80000c78 <pop_off+0x50>
    panic("pop_off");
  c->noff -= 1;
    80000c46:	37fd                	addiw	a5,a5,-1
    80000c48:	0007871b          	sext.w	a4,a5
    80000c4c:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000c4e:	eb09                	bnez	a4,80000c60 <pop_off+0x38>
    80000c50:	5d7c                	lw	a5,124(a0)
    80000c52:	c799                	beqz	a5,80000c60 <pop_off+0x38>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c54:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000c58:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000c5c:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000c60:	60a2                	ld	ra,8(sp)
    80000c62:	6402                	ld	s0,0(sp)
    80000c64:	0141                	addi	sp,sp,16
    80000c66:	8082                	ret
    panic("pop_off - interruptible");
    80000c68:	00007517          	auipc	a0,0x7
    80000c6c:	41050513          	addi	a0,a0,1040 # 80008078 <digits+0x38>
    80000c70:	00000097          	auipc	ra,0x0
    80000c74:	8ce080e7          	jalr	-1842(ra) # 8000053e <panic>
    panic("pop_off");
    80000c78:	00007517          	auipc	a0,0x7
    80000c7c:	41850513          	addi	a0,a0,1048 # 80008090 <digits+0x50>
    80000c80:	00000097          	auipc	ra,0x0
    80000c84:	8be080e7          	jalr	-1858(ra) # 8000053e <panic>

0000000080000c88 <release>:
{
    80000c88:	1101                	addi	sp,sp,-32
    80000c8a:	ec06                	sd	ra,24(sp)
    80000c8c:	e822                	sd	s0,16(sp)
    80000c8e:	e426                	sd	s1,8(sp)
    80000c90:	1000                	addi	s0,sp,32
    80000c92:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000c94:	00000097          	auipc	ra,0x0
    80000c98:	ec6080e7          	jalr	-314(ra) # 80000b5a <holding>
    80000c9c:	c115                	beqz	a0,80000cc0 <release+0x38>
  lk->cpu = 0;
    80000c9e:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000ca2:	0ff0000f          	fence
  __sync_lock_release(&lk->locked);
    80000ca6:	0f50000f          	fence	iorw,ow
    80000caa:	0804a02f          	amoswap.w	zero,zero,(s1)
  pop_off();
    80000cae:	00000097          	auipc	ra,0x0
    80000cb2:	f7a080e7          	jalr	-134(ra) # 80000c28 <pop_off>
}
    80000cb6:	60e2                	ld	ra,24(sp)
    80000cb8:	6442                	ld	s0,16(sp)
    80000cba:	64a2                	ld	s1,8(sp)
    80000cbc:	6105                	addi	sp,sp,32
    80000cbe:	8082                	ret
    panic("release");
    80000cc0:	00007517          	auipc	a0,0x7
    80000cc4:	3d850513          	addi	a0,a0,984 # 80008098 <digits+0x58>
    80000cc8:	00000097          	auipc	ra,0x0
    80000ccc:	876080e7          	jalr	-1930(ra) # 8000053e <panic>

0000000080000cd0 <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000cd0:	1141                	addi	sp,sp,-16
    80000cd2:	e422                	sd	s0,8(sp)
    80000cd4:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000cd6:	ca19                	beqz	a2,80000cec <memset+0x1c>
    80000cd8:	87aa                	mv	a5,a0
    80000cda:	1602                	slli	a2,a2,0x20
    80000cdc:	9201                	srli	a2,a2,0x20
    80000cde:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000ce2:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000ce6:	0785                	addi	a5,a5,1
    80000ce8:	fee79de3          	bne	a5,a4,80000ce2 <memset+0x12>
  }
  return dst;
}
    80000cec:	6422                	ld	s0,8(sp)
    80000cee:	0141                	addi	sp,sp,16
    80000cf0:	8082                	ret

0000000080000cf2 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000cf2:	1141                	addi	sp,sp,-16
    80000cf4:	e422                	sd	s0,8(sp)
    80000cf6:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000cf8:	ca05                	beqz	a2,80000d28 <memcmp+0x36>
    80000cfa:	fff6069b          	addiw	a3,a2,-1 # fff <_entry-0x7ffff001>
    80000cfe:	1682                	slli	a3,a3,0x20
    80000d00:	9281                	srli	a3,a3,0x20
    80000d02:	0685                	addi	a3,a3,1
    80000d04:	96aa                	add	a3,a3,a0
    if(*s1 != *s2)
    80000d06:	00054783          	lbu	a5,0(a0)
    80000d0a:	0005c703          	lbu	a4,0(a1)
    80000d0e:	00e79863          	bne	a5,a4,80000d1e <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    80000d12:	0505                	addi	a0,a0,1
    80000d14:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000d16:	fed518e3          	bne	a0,a3,80000d06 <memcmp+0x14>
  }

  return 0;
    80000d1a:	4501                	li	a0,0
    80000d1c:	a019                	j	80000d22 <memcmp+0x30>
      return *s1 - *s2;
    80000d1e:	40e7853b          	subw	a0,a5,a4
}
    80000d22:	6422                	ld	s0,8(sp)
    80000d24:	0141                	addi	sp,sp,16
    80000d26:	8082                	ret
  return 0;
    80000d28:	4501                	li	a0,0
    80000d2a:	bfe5                	j	80000d22 <memcmp+0x30>

0000000080000d2c <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000d2c:	1141                	addi	sp,sp,-16
    80000d2e:	e422                	sd	s0,8(sp)
    80000d30:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000d32:	c205                	beqz	a2,80000d52 <memmove+0x26>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000d34:	02a5e263          	bltu	a1,a0,80000d58 <memmove+0x2c>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000d38:	1602                	slli	a2,a2,0x20
    80000d3a:	9201                	srli	a2,a2,0x20
    80000d3c:	00c587b3          	add	a5,a1,a2
{
    80000d40:	872a                	mv	a4,a0
      *d++ = *s++;
    80000d42:	0585                	addi	a1,a1,1
    80000d44:	0705                	addi	a4,a4,1 # fffffffffffff001 <end+0xffffffff7ffdcea1>
    80000d46:	fff5c683          	lbu	a3,-1(a1)
    80000d4a:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000d4e:	fef59ae3          	bne	a1,a5,80000d42 <memmove+0x16>

  return dst;
}
    80000d52:	6422                	ld	s0,8(sp)
    80000d54:	0141                	addi	sp,sp,16
    80000d56:	8082                	ret
  if(s < d && s + n > d){
    80000d58:	02061693          	slli	a3,a2,0x20
    80000d5c:	9281                	srli	a3,a3,0x20
    80000d5e:	00d58733          	add	a4,a1,a3
    80000d62:	fce57be3          	bgeu	a0,a4,80000d38 <memmove+0xc>
    d += n;
    80000d66:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000d68:	fff6079b          	addiw	a5,a2,-1
    80000d6c:	1782                	slli	a5,a5,0x20
    80000d6e:	9381                	srli	a5,a5,0x20
    80000d70:	fff7c793          	not	a5,a5
    80000d74:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000d76:	177d                	addi	a4,a4,-1
    80000d78:	16fd                	addi	a3,a3,-1
    80000d7a:	00074603          	lbu	a2,0(a4)
    80000d7e:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000d82:	fee79ae3          	bne	a5,a4,80000d76 <memmove+0x4a>
    80000d86:	b7f1                	j	80000d52 <memmove+0x26>

0000000080000d88 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000d88:	1141                	addi	sp,sp,-16
    80000d8a:	e406                	sd	ra,8(sp)
    80000d8c:	e022                	sd	s0,0(sp)
    80000d8e:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000d90:	00000097          	auipc	ra,0x0
    80000d94:	f9c080e7          	jalr	-100(ra) # 80000d2c <memmove>
}
    80000d98:	60a2                	ld	ra,8(sp)
    80000d9a:	6402                	ld	s0,0(sp)
    80000d9c:	0141                	addi	sp,sp,16
    80000d9e:	8082                	ret

0000000080000da0 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000da0:	1141                	addi	sp,sp,-16
    80000da2:	e422                	sd	s0,8(sp)
    80000da4:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000da6:	ce11                	beqz	a2,80000dc2 <strncmp+0x22>
    80000da8:	00054783          	lbu	a5,0(a0)
    80000dac:	cf89                	beqz	a5,80000dc6 <strncmp+0x26>
    80000dae:	0005c703          	lbu	a4,0(a1)
    80000db2:	00f71a63          	bne	a4,a5,80000dc6 <strncmp+0x26>
    n--, p++, q++;
    80000db6:	367d                	addiw	a2,a2,-1
    80000db8:	0505                	addi	a0,a0,1
    80000dba:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000dbc:	f675                	bnez	a2,80000da8 <strncmp+0x8>
  if(n == 0)
    return 0;
    80000dbe:	4501                	li	a0,0
    80000dc0:	a809                	j	80000dd2 <strncmp+0x32>
    80000dc2:	4501                	li	a0,0
    80000dc4:	a039                	j	80000dd2 <strncmp+0x32>
  if(n == 0)
    80000dc6:	ca09                	beqz	a2,80000dd8 <strncmp+0x38>
  return (uchar)*p - (uchar)*q;
    80000dc8:	00054503          	lbu	a0,0(a0)
    80000dcc:	0005c783          	lbu	a5,0(a1)
    80000dd0:	9d1d                	subw	a0,a0,a5
}
    80000dd2:	6422                	ld	s0,8(sp)
    80000dd4:	0141                	addi	sp,sp,16
    80000dd6:	8082                	ret
    return 0;
    80000dd8:	4501                	li	a0,0
    80000dda:	bfe5                	j	80000dd2 <strncmp+0x32>

0000000080000ddc <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000ddc:	1141                	addi	sp,sp,-16
    80000dde:	e422                	sd	s0,8(sp)
    80000de0:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000de2:	872a                	mv	a4,a0
    80000de4:	8832                	mv	a6,a2
    80000de6:	367d                	addiw	a2,a2,-1
    80000de8:	01005963          	blez	a6,80000dfa <strncpy+0x1e>
    80000dec:	0705                	addi	a4,a4,1
    80000dee:	0005c783          	lbu	a5,0(a1)
    80000df2:	fef70fa3          	sb	a5,-1(a4)
    80000df6:	0585                	addi	a1,a1,1
    80000df8:	f7f5                	bnez	a5,80000de4 <strncpy+0x8>
    ;
  while(n-- > 0)
    80000dfa:	86ba                	mv	a3,a4
    80000dfc:	00c05c63          	blez	a2,80000e14 <strncpy+0x38>
    *s++ = 0;
    80000e00:	0685                	addi	a3,a3,1
    80000e02:	fe068fa3          	sb	zero,-1(a3)
  while(n-- > 0)
    80000e06:	40d707bb          	subw	a5,a4,a3
    80000e0a:	37fd                	addiw	a5,a5,-1
    80000e0c:	010787bb          	addw	a5,a5,a6
    80000e10:	fef048e3          	bgtz	a5,80000e00 <strncpy+0x24>
  return os;
}
    80000e14:	6422                	ld	s0,8(sp)
    80000e16:	0141                	addi	sp,sp,16
    80000e18:	8082                	ret

0000000080000e1a <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000e1a:	1141                	addi	sp,sp,-16
    80000e1c:	e422                	sd	s0,8(sp)
    80000e1e:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000e20:	02c05363          	blez	a2,80000e46 <safestrcpy+0x2c>
    80000e24:	fff6069b          	addiw	a3,a2,-1
    80000e28:	1682                	slli	a3,a3,0x20
    80000e2a:	9281                	srli	a3,a3,0x20
    80000e2c:	96ae                	add	a3,a3,a1
    80000e2e:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000e30:	00d58963          	beq	a1,a3,80000e42 <safestrcpy+0x28>
    80000e34:	0585                	addi	a1,a1,1
    80000e36:	0785                	addi	a5,a5,1
    80000e38:	fff5c703          	lbu	a4,-1(a1)
    80000e3c:	fee78fa3          	sb	a4,-1(a5)
    80000e40:	fb65                	bnez	a4,80000e30 <safestrcpy+0x16>
    ;
  *s = 0;
    80000e42:	00078023          	sb	zero,0(a5)
  return os;
}
    80000e46:	6422                	ld	s0,8(sp)
    80000e48:	0141                	addi	sp,sp,16
    80000e4a:	8082                	ret

0000000080000e4c <strlen>:

int
strlen(const char *s)
{
    80000e4c:	1141                	addi	sp,sp,-16
    80000e4e:	e422                	sd	s0,8(sp)
    80000e50:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80000e52:	00054783          	lbu	a5,0(a0)
    80000e56:	cf91                	beqz	a5,80000e72 <strlen+0x26>
    80000e58:	0505                	addi	a0,a0,1
    80000e5a:	87aa                	mv	a5,a0
    80000e5c:	4685                	li	a3,1
    80000e5e:	9e89                	subw	a3,a3,a0
    80000e60:	00f6853b          	addw	a0,a3,a5
    80000e64:	0785                	addi	a5,a5,1
    80000e66:	fff7c703          	lbu	a4,-1(a5)
    80000e6a:	fb7d                	bnez	a4,80000e60 <strlen+0x14>
    ;
  return n;
}
    80000e6c:	6422                	ld	s0,8(sp)
    80000e6e:	0141                	addi	sp,sp,16
    80000e70:	8082                	ret
  for(n = 0; s[n]; n++)
    80000e72:	4501                	li	a0,0
    80000e74:	bfe5                	j	80000e6c <strlen+0x20>

0000000080000e76 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000e76:	1141                	addi	sp,sp,-16
    80000e78:	e406                	sd	ra,8(sp)
    80000e7a:	e022                	sd	s0,0(sp)
    80000e7c:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000e7e:	00001097          	auipc	ra,0x1
    80000e82:	b00080e7          	jalr	-1280(ra) # 8000197e <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000e86:	00008717          	auipc	a4,0x8
    80000e8a:	a4270713          	addi	a4,a4,-1470 # 800088c8 <started>
  if(cpuid() == 0){
    80000e8e:	c139                	beqz	a0,80000ed4 <main+0x5e>
    while(started == 0)
    80000e90:	431c                	lw	a5,0(a4)
    80000e92:	2781                	sext.w	a5,a5
    80000e94:	dff5                	beqz	a5,80000e90 <main+0x1a>
      ;
    __sync_synchronize();
    80000e96:	0ff0000f          	fence
    printf("hart %d starting\n", cpuid());
    80000e9a:	00001097          	auipc	ra,0x1
    80000e9e:	ae4080e7          	jalr	-1308(ra) # 8000197e <cpuid>
    80000ea2:	85aa                	mv	a1,a0
    80000ea4:	00007517          	auipc	a0,0x7
    80000ea8:	21450513          	addi	a0,a0,532 # 800080b8 <digits+0x78>
    80000eac:	fffff097          	auipc	ra,0xfffff
    80000eb0:	6dc080e7          	jalr	1756(ra) # 80000588 <printf>
    kvminithart();    // turn on paging
    80000eb4:	00000097          	auipc	ra,0x0
    80000eb8:	0d8080e7          	jalr	216(ra) # 80000f8c <kvminithart>
    trapinithart();   // install kernel trap vector
    80000ebc:	00002097          	auipc	ra,0x2
    80000ec0:	8a4080e7          	jalr	-1884(ra) # 80002760 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000ec4:	00005097          	auipc	ra,0x5
    80000ec8:	e3c080e7          	jalr	-452(ra) # 80005d00 <plicinithart>
  }

  scheduler();        
    80000ecc:	00001097          	auipc	ra,0x1
    80000ed0:	fe2080e7          	jalr	-30(ra) # 80001eae <scheduler>
    consoleinit();
    80000ed4:	fffff097          	auipc	ra,0xfffff
    80000ed8:	57a080e7          	jalr	1402(ra) # 8000044e <consoleinit>
    printfinit();
    80000edc:	00000097          	auipc	ra,0x0
    80000ee0:	88c080e7          	jalr	-1908(ra) # 80000768 <printfinit>
    printf("\n");
    80000ee4:	00007517          	auipc	a0,0x7
    80000ee8:	1e450513          	addi	a0,a0,484 # 800080c8 <digits+0x88>
    80000eec:	fffff097          	auipc	ra,0xfffff
    80000ef0:	69c080e7          	jalr	1692(ra) # 80000588 <printf>
    printf("xv6 kernel is booting\n");
    80000ef4:	00007517          	auipc	a0,0x7
    80000ef8:	1ac50513          	addi	a0,a0,428 # 800080a0 <digits+0x60>
    80000efc:	fffff097          	auipc	ra,0xfffff
    80000f00:	68c080e7          	jalr	1676(ra) # 80000588 <printf>
    printf("\n");
    80000f04:	00007517          	auipc	a0,0x7
    80000f08:	1c450513          	addi	a0,a0,452 # 800080c8 <digits+0x88>
    80000f0c:	fffff097          	auipc	ra,0xfffff
    80000f10:	67c080e7          	jalr	1660(ra) # 80000588 <printf>
    kinit();         // physical page allocator
    80000f14:	00000097          	auipc	ra,0x0
    80000f18:	b94080e7          	jalr	-1132(ra) # 80000aa8 <kinit>
    kvminit();       // create kernel page table
    80000f1c:	00000097          	auipc	ra,0x0
    80000f20:	326080e7          	jalr	806(ra) # 80001242 <kvminit>
    kvminithart();   // turn on paging
    80000f24:	00000097          	auipc	ra,0x0
    80000f28:	068080e7          	jalr	104(ra) # 80000f8c <kvminithart>
    procinit();      // process table
    80000f2c:	00001097          	auipc	ra,0x1
    80000f30:	99e080e7          	jalr	-1634(ra) # 800018ca <procinit>
    trapinit();      // trap vectors
    80000f34:	00002097          	auipc	ra,0x2
    80000f38:	804080e7          	jalr	-2044(ra) # 80002738 <trapinit>
    trapinithart();  // install kernel trap vector
    80000f3c:	00002097          	auipc	ra,0x2
    80000f40:	824080e7          	jalr	-2012(ra) # 80002760 <trapinithart>
    plicinit();      // set up interrupt controller
    80000f44:	00005097          	auipc	ra,0x5
    80000f48:	da6080e7          	jalr	-602(ra) # 80005cea <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000f4c:	00005097          	auipc	ra,0x5
    80000f50:	db4080e7          	jalr	-588(ra) # 80005d00 <plicinithart>
    binit();         // buffer cache
    80000f54:	00002097          	auipc	ra,0x2
    80000f58:	f48080e7          	jalr	-184(ra) # 80002e9c <binit>
    iinit();         // inode table
    80000f5c:	00002097          	auipc	ra,0x2
    80000f60:	5e8080e7          	jalr	1512(ra) # 80003544 <iinit>
    fileinit();      // file table
    80000f64:	00003097          	auipc	ra,0x3
    80000f68:	58e080e7          	jalr	1422(ra) # 800044f2 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000f6c:	00005097          	auipc	ra,0x5
    80000f70:	e9c080e7          	jalr	-356(ra) # 80005e08 <virtio_disk_init>
    userinit();      // first user process
    80000f74:	00001097          	auipc	ra,0x1
    80000f78:	d1c080e7          	jalr	-740(ra) # 80001c90 <userinit>
    __sync_synchronize();
    80000f7c:	0ff0000f          	fence
    started = 1;
    80000f80:	4785                	li	a5,1
    80000f82:	00008717          	auipc	a4,0x8
    80000f86:	94f72323          	sw	a5,-1722(a4) # 800088c8 <started>
    80000f8a:	b789                	j	80000ecc <main+0x56>

0000000080000f8c <kvminithart>:

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
    80000f8c:	1141                	addi	sp,sp,-16
    80000f8e:	e422                	sd	s0,8(sp)
    80000f90:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80000f92:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000f96:	00008797          	auipc	a5,0x8
    80000f9a:	93a7b783          	ld	a5,-1734(a5) # 800088d0 <kernel_pagetable>
    80000f9e:	83b1                	srli	a5,a5,0xc
    80000fa0:	577d                	li	a4,-1
    80000fa2:	177e                	slli	a4,a4,0x3f
    80000fa4:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80000fa6:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80000faa:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000fae:	6422                	ld	s0,8(sp)
    80000fb0:	0141                	addi	sp,sp,16
    80000fb2:	8082                	ret

0000000080000fb4 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000fb4:	7139                	addi	sp,sp,-64
    80000fb6:	fc06                	sd	ra,56(sp)
    80000fb8:	f822                	sd	s0,48(sp)
    80000fba:	f426                	sd	s1,40(sp)
    80000fbc:	f04a                	sd	s2,32(sp)
    80000fbe:	ec4e                	sd	s3,24(sp)
    80000fc0:	e852                	sd	s4,16(sp)
    80000fc2:	e456                	sd	s5,8(sp)
    80000fc4:	e05a                	sd	s6,0(sp)
    80000fc6:	0080                	addi	s0,sp,64
    80000fc8:	84aa                	mv	s1,a0
    80000fca:	89ae                	mv	s3,a1
    80000fcc:	8ab2                	mv	s5,a2
  if(va >= MAXVA)
    80000fce:	57fd                	li	a5,-1
    80000fd0:	83e9                	srli	a5,a5,0x1a
    80000fd2:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000fd4:	4b31                	li	s6,12
  if(va >= MAXVA)
    80000fd6:	04b7f263          	bgeu	a5,a1,8000101a <walk+0x66>
    panic("walk");
    80000fda:	00007517          	auipc	a0,0x7
    80000fde:	0f650513          	addi	a0,a0,246 # 800080d0 <digits+0x90>
    80000fe2:	fffff097          	auipc	ra,0xfffff
    80000fe6:	55c080e7          	jalr	1372(ra) # 8000053e <panic>
    pte_t *pte = &pagetable[PX(level, va)];
    if(*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80000fea:	060a8663          	beqz	s5,80001056 <walk+0xa2>
    80000fee:	00000097          	auipc	ra,0x0
    80000ff2:	af6080e7          	jalr	-1290(ra) # 80000ae4 <kalloc>
    80000ff6:	84aa                	mv	s1,a0
    80000ff8:	c529                	beqz	a0,80001042 <walk+0x8e>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80000ffa:	6605                	lui	a2,0x1
    80000ffc:	4581                	li	a1,0
    80000ffe:	00000097          	auipc	ra,0x0
    80001002:	cd2080e7          	jalr	-814(ra) # 80000cd0 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80001006:	00c4d793          	srli	a5,s1,0xc
    8000100a:	07aa                	slli	a5,a5,0xa
    8000100c:	0017e793          	ori	a5,a5,1
    80001010:	00f93023          	sd	a5,0(s2)
  for(int level = 2; level > 0; level--) {
    80001014:	3a5d                	addiw	s4,s4,-9 # ffffffffffffeff7 <end+0xffffffff7ffdce97>
    80001016:	036a0063          	beq	s4,s6,80001036 <walk+0x82>
    pte_t *pte = &pagetable[PX(level, va)];
    8000101a:	0149d933          	srl	s2,s3,s4
    8000101e:	1ff97913          	andi	s2,s2,511
    80001022:	090e                	slli	s2,s2,0x3
    80001024:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80001026:	00093483          	ld	s1,0(s2)
    8000102a:	0014f793          	andi	a5,s1,1
    8000102e:	dfd5                	beqz	a5,80000fea <walk+0x36>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80001030:	80a9                	srli	s1,s1,0xa
    80001032:	04b2                	slli	s1,s1,0xc
    80001034:	b7c5                	j	80001014 <walk+0x60>
    }
  }
  return &pagetable[PX(0, va)];
    80001036:	00c9d513          	srli	a0,s3,0xc
    8000103a:	1ff57513          	andi	a0,a0,511
    8000103e:	050e                	slli	a0,a0,0x3
    80001040:	9526                	add	a0,a0,s1
}
    80001042:	70e2                	ld	ra,56(sp)
    80001044:	7442                	ld	s0,48(sp)
    80001046:	74a2                	ld	s1,40(sp)
    80001048:	7902                	ld	s2,32(sp)
    8000104a:	69e2                	ld	s3,24(sp)
    8000104c:	6a42                	ld	s4,16(sp)
    8000104e:	6aa2                	ld	s5,8(sp)
    80001050:	6b02                	ld	s6,0(sp)
    80001052:	6121                	addi	sp,sp,64
    80001054:	8082                	ret
        return 0;
    80001056:	4501                	li	a0,0
    80001058:	b7ed                	j	80001042 <walk+0x8e>

000000008000105a <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    8000105a:	57fd                	li	a5,-1
    8000105c:	83e9                	srli	a5,a5,0x1a
    8000105e:	00b7f463          	bgeu	a5,a1,80001066 <walkaddr+0xc>
    return 0;
    80001062:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80001064:	8082                	ret
{
    80001066:	1141                	addi	sp,sp,-16
    80001068:	e406                	sd	ra,8(sp)
    8000106a:	e022                	sd	s0,0(sp)
    8000106c:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    8000106e:	4601                	li	a2,0
    80001070:	00000097          	auipc	ra,0x0
    80001074:	f44080e7          	jalr	-188(ra) # 80000fb4 <walk>
  if(pte == 0)
    80001078:	c105                	beqz	a0,80001098 <walkaddr+0x3e>
  if((*pte & PTE_V) == 0)
    8000107a:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    8000107c:	0117f693          	andi	a3,a5,17
    80001080:	4745                	li	a4,17
    return 0;
    80001082:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    80001084:	00e68663          	beq	a3,a4,80001090 <walkaddr+0x36>
}
    80001088:	60a2                	ld	ra,8(sp)
    8000108a:	6402                	ld	s0,0(sp)
    8000108c:	0141                	addi	sp,sp,16
    8000108e:	8082                	ret
  pa = PTE2PA(*pte);
    80001090:	83a9                	srli	a5,a5,0xa
    80001092:	00c79513          	slli	a0,a5,0xc
  return pa;
    80001096:	bfcd                	j	80001088 <walkaddr+0x2e>
    return 0;
    80001098:	4501                	li	a0,0
    8000109a:	b7fd                	j	80001088 <walkaddr+0x2e>

000000008000109c <mappages>:
// physical addresses starting at pa. va and size might not
// be page-aligned. Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    8000109c:	715d                	addi	sp,sp,-80
    8000109e:	e486                	sd	ra,72(sp)
    800010a0:	e0a2                	sd	s0,64(sp)
    800010a2:	fc26                	sd	s1,56(sp)
    800010a4:	f84a                	sd	s2,48(sp)
    800010a6:	f44e                	sd	s3,40(sp)
    800010a8:	f052                	sd	s4,32(sp)
    800010aa:	ec56                	sd	s5,24(sp)
    800010ac:	e85a                	sd	s6,16(sp)
    800010ae:	e45e                	sd	s7,8(sp)
    800010b0:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if(size == 0)
    800010b2:	c639                	beqz	a2,80001100 <mappages+0x64>
    800010b4:	8aaa                	mv	s5,a0
    800010b6:	8b3a                	mv	s6,a4
    panic("mappages: size");
  
  a = PGROUNDDOWN(va);
    800010b8:	777d                	lui	a4,0xfffff
    800010ba:	00e5f7b3          	and	a5,a1,a4
  last = PGROUNDDOWN(va + size - 1);
    800010be:	fff58993          	addi	s3,a1,-1
    800010c2:	99b2                	add	s3,s3,a2
    800010c4:	00e9f9b3          	and	s3,s3,a4
  a = PGROUNDDOWN(va);
    800010c8:	893e                	mv	s2,a5
    800010ca:	40f68a33          	sub	s4,a3,a5
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    800010ce:	6b85                	lui	s7,0x1
    800010d0:	012a04b3          	add	s1,s4,s2
    if((pte = walk(pagetable, a, 1)) == 0)
    800010d4:	4605                	li	a2,1
    800010d6:	85ca                	mv	a1,s2
    800010d8:	8556                	mv	a0,s5
    800010da:	00000097          	auipc	ra,0x0
    800010de:	eda080e7          	jalr	-294(ra) # 80000fb4 <walk>
    800010e2:	cd1d                	beqz	a0,80001120 <mappages+0x84>
    if(*pte & PTE_V)
    800010e4:	611c                	ld	a5,0(a0)
    800010e6:	8b85                	andi	a5,a5,1
    800010e8:	e785                	bnez	a5,80001110 <mappages+0x74>
    *pte = PA2PTE(pa) | perm | PTE_V;
    800010ea:	80b1                	srli	s1,s1,0xc
    800010ec:	04aa                	slli	s1,s1,0xa
    800010ee:	0164e4b3          	or	s1,s1,s6
    800010f2:	0014e493          	ori	s1,s1,1
    800010f6:	e104                	sd	s1,0(a0)
    if(a == last)
    800010f8:	05390063          	beq	s2,s3,80001138 <mappages+0x9c>
    a += PGSIZE;
    800010fc:	995e                	add	s2,s2,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    800010fe:	bfc9                	j	800010d0 <mappages+0x34>
    panic("mappages: size");
    80001100:	00007517          	auipc	a0,0x7
    80001104:	fd850513          	addi	a0,a0,-40 # 800080d8 <digits+0x98>
    80001108:	fffff097          	auipc	ra,0xfffff
    8000110c:	436080e7          	jalr	1078(ra) # 8000053e <panic>
      panic("mappages: remap");
    80001110:	00007517          	auipc	a0,0x7
    80001114:	fd850513          	addi	a0,a0,-40 # 800080e8 <digits+0xa8>
    80001118:	fffff097          	auipc	ra,0xfffff
    8000111c:	426080e7          	jalr	1062(ra) # 8000053e <panic>
      return -1;
    80001120:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    80001122:	60a6                	ld	ra,72(sp)
    80001124:	6406                	ld	s0,64(sp)
    80001126:	74e2                	ld	s1,56(sp)
    80001128:	7942                	ld	s2,48(sp)
    8000112a:	79a2                	ld	s3,40(sp)
    8000112c:	7a02                	ld	s4,32(sp)
    8000112e:	6ae2                	ld	s5,24(sp)
    80001130:	6b42                	ld	s6,16(sp)
    80001132:	6ba2                	ld	s7,8(sp)
    80001134:	6161                	addi	sp,sp,80
    80001136:	8082                	ret
  return 0;
    80001138:	4501                	li	a0,0
    8000113a:	b7e5                	j	80001122 <mappages+0x86>

000000008000113c <kvmmap>:
{
    8000113c:	1141                	addi	sp,sp,-16
    8000113e:	e406                	sd	ra,8(sp)
    80001140:	e022                	sd	s0,0(sp)
    80001142:	0800                	addi	s0,sp,16
    80001144:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    80001146:	86b2                	mv	a3,a2
    80001148:	863e                	mv	a2,a5
    8000114a:	00000097          	auipc	ra,0x0
    8000114e:	f52080e7          	jalr	-174(ra) # 8000109c <mappages>
    80001152:	e509                	bnez	a0,8000115c <kvmmap+0x20>
}
    80001154:	60a2                	ld	ra,8(sp)
    80001156:	6402                	ld	s0,0(sp)
    80001158:	0141                	addi	sp,sp,16
    8000115a:	8082                	ret
    panic("kvmmap");
    8000115c:	00007517          	auipc	a0,0x7
    80001160:	f9c50513          	addi	a0,a0,-100 # 800080f8 <digits+0xb8>
    80001164:	fffff097          	auipc	ra,0xfffff
    80001168:	3da080e7          	jalr	986(ra) # 8000053e <panic>

000000008000116c <kvmmake>:
{
    8000116c:	1101                	addi	sp,sp,-32
    8000116e:	ec06                	sd	ra,24(sp)
    80001170:	e822                	sd	s0,16(sp)
    80001172:	e426                	sd	s1,8(sp)
    80001174:	e04a                	sd	s2,0(sp)
    80001176:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    80001178:	00000097          	auipc	ra,0x0
    8000117c:	96c080e7          	jalr	-1684(ra) # 80000ae4 <kalloc>
    80001180:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    80001182:	6605                	lui	a2,0x1
    80001184:	4581                	li	a1,0
    80001186:	00000097          	auipc	ra,0x0
    8000118a:	b4a080e7          	jalr	-1206(ra) # 80000cd0 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    8000118e:	4719                	li	a4,6
    80001190:	6685                	lui	a3,0x1
    80001192:	10000637          	lui	a2,0x10000
    80001196:	100005b7          	lui	a1,0x10000
    8000119a:	8526                	mv	a0,s1
    8000119c:	00000097          	auipc	ra,0x0
    800011a0:	fa0080e7          	jalr	-96(ra) # 8000113c <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    800011a4:	4719                	li	a4,6
    800011a6:	6685                	lui	a3,0x1
    800011a8:	10001637          	lui	a2,0x10001
    800011ac:	100015b7          	lui	a1,0x10001
    800011b0:	8526                	mv	a0,s1
    800011b2:	00000097          	auipc	ra,0x0
    800011b6:	f8a080e7          	jalr	-118(ra) # 8000113c <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x400000, PTE_R | PTE_W);
    800011ba:	4719                	li	a4,6
    800011bc:	004006b7          	lui	a3,0x400
    800011c0:	0c000637          	lui	a2,0xc000
    800011c4:	0c0005b7          	lui	a1,0xc000
    800011c8:	8526                	mv	a0,s1
    800011ca:	00000097          	auipc	ra,0x0
    800011ce:	f72080e7          	jalr	-142(ra) # 8000113c <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    800011d2:	00007917          	auipc	s2,0x7
    800011d6:	e2e90913          	addi	s2,s2,-466 # 80008000 <etext>
    800011da:	4729                	li	a4,10
    800011dc:	80007697          	auipc	a3,0x80007
    800011e0:	e2468693          	addi	a3,a3,-476 # 8000 <_entry-0x7fff8000>
    800011e4:	4605                	li	a2,1
    800011e6:	067e                	slli	a2,a2,0x1f
    800011e8:	85b2                	mv	a1,a2
    800011ea:	8526                	mv	a0,s1
    800011ec:	00000097          	auipc	ra,0x0
    800011f0:	f50080e7          	jalr	-176(ra) # 8000113c <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    800011f4:	4719                	li	a4,6
    800011f6:	46c5                	li	a3,17
    800011f8:	06ee                	slli	a3,a3,0x1b
    800011fa:	412686b3          	sub	a3,a3,s2
    800011fe:	864a                	mv	a2,s2
    80001200:	85ca                	mv	a1,s2
    80001202:	8526                	mv	a0,s1
    80001204:	00000097          	auipc	ra,0x0
    80001208:	f38080e7          	jalr	-200(ra) # 8000113c <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    8000120c:	4729                	li	a4,10
    8000120e:	6685                	lui	a3,0x1
    80001210:	00006617          	auipc	a2,0x6
    80001214:	df060613          	addi	a2,a2,-528 # 80007000 <_trampoline>
    80001218:	040005b7          	lui	a1,0x4000
    8000121c:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    8000121e:	05b2                	slli	a1,a1,0xc
    80001220:	8526                	mv	a0,s1
    80001222:	00000097          	auipc	ra,0x0
    80001226:	f1a080e7          	jalr	-230(ra) # 8000113c <kvmmap>
  proc_mapstacks(kpgtbl);
    8000122a:	8526                	mv	a0,s1
    8000122c:	00000097          	auipc	ra,0x0
    80001230:	608080e7          	jalr	1544(ra) # 80001834 <proc_mapstacks>
}
    80001234:	8526                	mv	a0,s1
    80001236:	60e2                	ld	ra,24(sp)
    80001238:	6442                	ld	s0,16(sp)
    8000123a:	64a2                	ld	s1,8(sp)
    8000123c:	6902                	ld	s2,0(sp)
    8000123e:	6105                	addi	sp,sp,32
    80001240:	8082                	ret

0000000080001242 <kvminit>:
{
    80001242:	1141                	addi	sp,sp,-16
    80001244:	e406                	sd	ra,8(sp)
    80001246:	e022                	sd	s0,0(sp)
    80001248:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    8000124a:	00000097          	auipc	ra,0x0
    8000124e:	f22080e7          	jalr	-222(ra) # 8000116c <kvmmake>
    80001252:	00007797          	auipc	a5,0x7
    80001256:	66a7bf23          	sd	a0,1662(a5) # 800088d0 <kernel_pagetable>
}
    8000125a:	60a2                	ld	ra,8(sp)
    8000125c:	6402                	ld	s0,0(sp)
    8000125e:	0141                	addi	sp,sp,16
    80001260:	8082                	ret

0000000080001262 <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. The mappings must exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    80001262:	715d                	addi	sp,sp,-80
    80001264:	e486                	sd	ra,72(sp)
    80001266:	e0a2                	sd	s0,64(sp)
    80001268:	fc26                	sd	s1,56(sp)
    8000126a:	f84a                	sd	s2,48(sp)
    8000126c:	f44e                	sd	s3,40(sp)
    8000126e:	f052                	sd	s4,32(sp)
    80001270:	ec56                	sd	s5,24(sp)
    80001272:	e85a                	sd	s6,16(sp)
    80001274:	e45e                	sd	s7,8(sp)
    80001276:	0880                	addi	s0,sp,80
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001278:	03459793          	slli	a5,a1,0x34
    8000127c:	e795                	bnez	a5,800012a8 <uvmunmap+0x46>
    8000127e:	8a2a                	mv	s4,a0
    80001280:	892e                	mv	s2,a1
    80001282:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001284:	0632                	slli	a2,a2,0xc
    80001286:	00b609b3          	add	s3,a2,a1
    if((pte = walk(pagetable, a, 0)) == 0)
      panic("uvmunmap: walk");
    if((*pte & PTE_V) == 0)
      panic("uvmunmap: not mapped");
    if(PTE_FLAGS(*pte) == PTE_V)
    8000128a:	4b85                	li	s7,1
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    8000128c:	6b05                	lui	s6,0x1
    8000128e:	0735e263          	bltu	a1,s3,800012f2 <uvmunmap+0x90>
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
  }
}
    80001292:	60a6                	ld	ra,72(sp)
    80001294:	6406                	ld	s0,64(sp)
    80001296:	74e2                	ld	s1,56(sp)
    80001298:	7942                	ld	s2,48(sp)
    8000129a:	79a2                	ld	s3,40(sp)
    8000129c:	7a02                	ld	s4,32(sp)
    8000129e:	6ae2                	ld	s5,24(sp)
    800012a0:	6b42                	ld	s6,16(sp)
    800012a2:	6ba2                	ld	s7,8(sp)
    800012a4:	6161                	addi	sp,sp,80
    800012a6:	8082                	ret
    panic("uvmunmap: not aligned");
    800012a8:	00007517          	auipc	a0,0x7
    800012ac:	e5850513          	addi	a0,a0,-424 # 80008100 <digits+0xc0>
    800012b0:	fffff097          	auipc	ra,0xfffff
    800012b4:	28e080e7          	jalr	654(ra) # 8000053e <panic>
      panic("uvmunmap: walk");
    800012b8:	00007517          	auipc	a0,0x7
    800012bc:	e6050513          	addi	a0,a0,-416 # 80008118 <digits+0xd8>
    800012c0:	fffff097          	auipc	ra,0xfffff
    800012c4:	27e080e7          	jalr	638(ra) # 8000053e <panic>
      panic("uvmunmap: not mapped");
    800012c8:	00007517          	auipc	a0,0x7
    800012cc:	e6050513          	addi	a0,a0,-416 # 80008128 <digits+0xe8>
    800012d0:	fffff097          	auipc	ra,0xfffff
    800012d4:	26e080e7          	jalr	622(ra) # 8000053e <panic>
      panic("uvmunmap: not a leaf");
    800012d8:	00007517          	auipc	a0,0x7
    800012dc:	e6850513          	addi	a0,a0,-408 # 80008140 <digits+0x100>
    800012e0:	fffff097          	auipc	ra,0xfffff
    800012e4:	25e080e7          	jalr	606(ra) # 8000053e <panic>
    *pte = 0;
    800012e8:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    800012ec:	995a                	add	s2,s2,s6
    800012ee:	fb3972e3          	bgeu	s2,s3,80001292 <uvmunmap+0x30>
    if((pte = walk(pagetable, a, 0)) == 0)
    800012f2:	4601                	li	a2,0
    800012f4:	85ca                	mv	a1,s2
    800012f6:	8552                	mv	a0,s4
    800012f8:	00000097          	auipc	ra,0x0
    800012fc:	cbc080e7          	jalr	-836(ra) # 80000fb4 <walk>
    80001300:	84aa                	mv	s1,a0
    80001302:	d95d                	beqz	a0,800012b8 <uvmunmap+0x56>
    if((*pte & PTE_V) == 0)
    80001304:	6108                	ld	a0,0(a0)
    80001306:	00157793          	andi	a5,a0,1
    8000130a:	dfdd                	beqz	a5,800012c8 <uvmunmap+0x66>
    if(PTE_FLAGS(*pte) == PTE_V)
    8000130c:	3ff57793          	andi	a5,a0,1023
    80001310:	fd7784e3          	beq	a5,s7,800012d8 <uvmunmap+0x76>
    if(do_free){
    80001314:	fc0a8ae3          	beqz	s5,800012e8 <uvmunmap+0x86>
      uint64 pa = PTE2PA(*pte);
    80001318:	8129                	srli	a0,a0,0xa
      kfree((void*)pa);
    8000131a:	0532                	slli	a0,a0,0xc
    8000131c:	fffff097          	auipc	ra,0xfffff
    80001320:	6ca080e7          	jalr	1738(ra) # 800009e6 <kfree>
    80001324:	b7d1                	j	800012e8 <uvmunmap+0x86>

0000000080001326 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    80001326:	1101                	addi	sp,sp,-32
    80001328:	ec06                	sd	ra,24(sp)
    8000132a:	e822                	sd	s0,16(sp)
    8000132c:	e426                	sd	s1,8(sp)
    8000132e:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    80001330:	fffff097          	auipc	ra,0xfffff
    80001334:	7b4080e7          	jalr	1972(ra) # 80000ae4 <kalloc>
    80001338:	84aa                	mv	s1,a0
  if(pagetable == 0)
    8000133a:	c519                	beqz	a0,80001348 <uvmcreate+0x22>
    return 0;
  memset(pagetable, 0, PGSIZE);
    8000133c:	6605                	lui	a2,0x1
    8000133e:	4581                	li	a1,0
    80001340:	00000097          	auipc	ra,0x0
    80001344:	990080e7          	jalr	-1648(ra) # 80000cd0 <memset>
  return pagetable;
}
    80001348:	8526                	mv	a0,s1
    8000134a:	60e2                	ld	ra,24(sp)
    8000134c:	6442                	ld	s0,16(sp)
    8000134e:	64a2                	ld	s1,8(sp)
    80001350:	6105                	addi	sp,sp,32
    80001352:	8082                	ret

0000000080001354 <uvmfirst>:
// Load the user initcode into address 0 of pagetable,
// for the very first process.
// sz must be less than a page.
void
uvmfirst(pagetable_t pagetable, uchar *src, uint sz)
{
    80001354:	7179                	addi	sp,sp,-48
    80001356:	f406                	sd	ra,40(sp)
    80001358:	f022                	sd	s0,32(sp)
    8000135a:	ec26                	sd	s1,24(sp)
    8000135c:	e84a                	sd	s2,16(sp)
    8000135e:	e44e                	sd	s3,8(sp)
    80001360:	e052                	sd	s4,0(sp)
    80001362:	1800                	addi	s0,sp,48
  char *mem;

  if(sz >= PGSIZE)
    80001364:	6785                	lui	a5,0x1
    80001366:	04f67863          	bgeu	a2,a5,800013b6 <uvmfirst+0x62>
    8000136a:	8a2a                	mv	s4,a0
    8000136c:	89ae                	mv	s3,a1
    8000136e:	84b2                	mv	s1,a2
    panic("uvmfirst: more than a page");
  mem = kalloc();
    80001370:	fffff097          	auipc	ra,0xfffff
    80001374:	774080e7          	jalr	1908(ra) # 80000ae4 <kalloc>
    80001378:	892a                	mv	s2,a0
  memset(mem, 0, PGSIZE);
    8000137a:	6605                	lui	a2,0x1
    8000137c:	4581                	li	a1,0
    8000137e:	00000097          	auipc	ra,0x0
    80001382:	952080e7          	jalr	-1710(ra) # 80000cd0 <memset>
  mappages(pagetable, 0, PGSIZE, (uint64)mem, PTE_W|PTE_R|PTE_X|PTE_U);
    80001386:	4779                	li	a4,30
    80001388:	86ca                	mv	a3,s2
    8000138a:	6605                	lui	a2,0x1
    8000138c:	4581                	li	a1,0
    8000138e:	8552                	mv	a0,s4
    80001390:	00000097          	auipc	ra,0x0
    80001394:	d0c080e7          	jalr	-756(ra) # 8000109c <mappages>
  memmove(mem, src, sz);
    80001398:	8626                	mv	a2,s1
    8000139a:	85ce                	mv	a1,s3
    8000139c:	854a                	mv	a0,s2
    8000139e:	00000097          	auipc	ra,0x0
    800013a2:	98e080e7          	jalr	-1650(ra) # 80000d2c <memmove>
}
    800013a6:	70a2                	ld	ra,40(sp)
    800013a8:	7402                	ld	s0,32(sp)
    800013aa:	64e2                	ld	s1,24(sp)
    800013ac:	6942                	ld	s2,16(sp)
    800013ae:	69a2                	ld	s3,8(sp)
    800013b0:	6a02                	ld	s4,0(sp)
    800013b2:	6145                	addi	sp,sp,48
    800013b4:	8082                	ret
    panic("uvmfirst: more than a page");
    800013b6:	00007517          	auipc	a0,0x7
    800013ba:	da250513          	addi	a0,a0,-606 # 80008158 <digits+0x118>
    800013be:	fffff097          	auipc	ra,0xfffff
    800013c2:	180080e7          	jalr	384(ra) # 8000053e <panic>

00000000800013c6 <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    800013c6:	1101                	addi	sp,sp,-32
    800013c8:	ec06                	sd	ra,24(sp)
    800013ca:	e822                	sd	s0,16(sp)
    800013cc:	e426                	sd	s1,8(sp)
    800013ce:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    800013d0:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    800013d2:	00b67d63          	bgeu	a2,a1,800013ec <uvmdealloc+0x26>
    800013d6:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    800013d8:	6785                	lui	a5,0x1
    800013da:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800013dc:	00f60733          	add	a4,a2,a5
    800013e0:	76fd                	lui	a3,0xfffff
    800013e2:	8f75                	and	a4,a4,a3
    800013e4:	97ae                	add	a5,a5,a1
    800013e6:	8ff5                	and	a5,a5,a3
    800013e8:	00f76863          	bltu	a4,a5,800013f8 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    800013ec:	8526                	mv	a0,s1
    800013ee:	60e2                	ld	ra,24(sp)
    800013f0:	6442                	ld	s0,16(sp)
    800013f2:	64a2                	ld	s1,8(sp)
    800013f4:	6105                	addi	sp,sp,32
    800013f6:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    800013f8:	8f99                	sub	a5,a5,a4
    800013fa:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800013fc:	4685                	li	a3,1
    800013fe:	0007861b          	sext.w	a2,a5
    80001402:	85ba                	mv	a1,a4
    80001404:	00000097          	auipc	ra,0x0
    80001408:	e5e080e7          	jalr	-418(ra) # 80001262 <uvmunmap>
    8000140c:	b7c5                	j	800013ec <uvmdealloc+0x26>

000000008000140e <uvmalloc>:
  if(newsz < oldsz)
    8000140e:	0ab66563          	bltu	a2,a1,800014b8 <uvmalloc+0xaa>
{
    80001412:	7139                	addi	sp,sp,-64
    80001414:	fc06                	sd	ra,56(sp)
    80001416:	f822                	sd	s0,48(sp)
    80001418:	f426                	sd	s1,40(sp)
    8000141a:	f04a                	sd	s2,32(sp)
    8000141c:	ec4e                	sd	s3,24(sp)
    8000141e:	e852                	sd	s4,16(sp)
    80001420:	e456                	sd	s5,8(sp)
    80001422:	e05a                	sd	s6,0(sp)
    80001424:	0080                	addi	s0,sp,64
    80001426:	8aaa                	mv	s5,a0
    80001428:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    8000142a:	6785                	lui	a5,0x1
    8000142c:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000142e:	95be                	add	a1,a1,a5
    80001430:	77fd                	lui	a5,0xfffff
    80001432:	00f5f9b3          	and	s3,a1,a5
  for(a = oldsz; a < newsz; a += PGSIZE){
    80001436:	08c9f363          	bgeu	s3,a2,800014bc <uvmalloc+0xae>
    8000143a:	894e                	mv	s2,s3
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    8000143c:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    80001440:	fffff097          	auipc	ra,0xfffff
    80001444:	6a4080e7          	jalr	1700(ra) # 80000ae4 <kalloc>
    80001448:	84aa                	mv	s1,a0
    if(mem == 0){
    8000144a:	c51d                	beqz	a0,80001478 <uvmalloc+0x6a>
    memset(mem, 0, PGSIZE);
    8000144c:	6605                	lui	a2,0x1
    8000144e:	4581                	li	a1,0
    80001450:	00000097          	auipc	ra,0x0
    80001454:	880080e7          	jalr	-1920(ra) # 80000cd0 <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80001458:	875a                	mv	a4,s6
    8000145a:	86a6                	mv	a3,s1
    8000145c:	6605                	lui	a2,0x1
    8000145e:	85ca                	mv	a1,s2
    80001460:	8556                	mv	a0,s5
    80001462:	00000097          	auipc	ra,0x0
    80001466:	c3a080e7          	jalr	-966(ra) # 8000109c <mappages>
    8000146a:	e90d                	bnez	a0,8000149c <uvmalloc+0x8e>
  for(a = oldsz; a < newsz; a += PGSIZE){
    8000146c:	6785                	lui	a5,0x1
    8000146e:	993e                	add	s2,s2,a5
    80001470:	fd4968e3          	bltu	s2,s4,80001440 <uvmalloc+0x32>
  return newsz;
    80001474:	8552                	mv	a0,s4
    80001476:	a809                	j	80001488 <uvmalloc+0x7a>
      uvmdealloc(pagetable, a, oldsz);
    80001478:	864e                	mv	a2,s3
    8000147a:	85ca                	mv	a1,s2
    8000147c:	8556                	mv	a0,s5
    8000147e:	00000097          	auipc	ra,0x0
    80001482:	f48080e7          	jalr	-184(ra) # 800013c6 <uvmdealloc>
      return 0;
    80001486:	4501                	li	a0,0
}
    80001488:	70e2                	ld	ra,56(sp)
    8000148a:	7442                	ld	s0,48(sp)
    8000148c:	74a2                	ld	s1,40(sp)
    8000148e:	7902                	ld	s2,32(sp)
    80001490:	69e2                	ld	s3,24(sp)
    80001492:	6a42                	ld	s4,16(sp)
    80001494:	6aa2                	ld	s5,8(sp)
    80001496:	6b02                	ld	s6,0(sp)
    80001498:	6121                	addi	sp,sp,64
    8000149a:	8082                	ret
      kfree(mem);
    8000149c:	8526                	mv	a0,s1
    8000149e:	fffff097          	auipc	ra,0xfffff
    800014a2:	548080e7          	jalr	1352(ra) # 800009e6 <kfree>
      uvmdealloc(pagetable, a, oldsz);
    800014a6:	864e                	mv	a2,s3
    800014a8:	85ca                	mv	a1,s2
    800014aa:	8556                	mv	a0,s5
    800014ac:	00000097          	auipc	ra,0x0
    800014b0:	f1a080e7          	jalr	-230(ra) # 800013c6 <uvmdealloc>
      return 0;
    800014b4:	4501                	li	a0,0
    800014b6:	bfc9                	j	80001488 <uvmalloc+0x7a>
    return oldsz;
    800014b8:	852e                	mv	a0,a1
}
    800014ba:	8082                	ret
  return newsz;
    800014bc:	8532                	mv	a0,a2
    800014be:	b7e9                	j	80001488 <uvmalloc+0x7a>

00000000800014c0 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    800014c0:	7179                	addi	sp,sp,-48
    800014c2:	f406                	sd	ra,40(sp)
    800014c4:	f022                	sd	s0,32(sp)
    800014c6:	ec26                	sd	s1,24(sp)
    800014c8:	e84a                	sd	s2,16(sp)
    800014ca:	e44e                	sd	s3,8(sp)
    800014cc:	e052                	sd	s4,0(sp)
    800014ce:	1800                	addi	s0,sp,48
    800014d0:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    800014d2:	84aa                	mv	s1,a0
    800014d4:	6905                	lui	s2,0x1
    800014d6:	992a                	add	s2,s2,a0
    pte_t pte = pagetable[i];
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800014d8:	4985                	li	s3,1
    800014da:	a829                	j	800014f4 <freewalk+0x34>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    800014dc:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    800014de:	00c79513          	slli	a0,a5,0xc
    800014e2:	00000097          	auipc	ra,0x0
    800014e6:	fde080e7          	jalr	-34(ra) # 800014c0 <freewalk>
      pagetable[i] = 0;
    800014ea:	0004b023          	sd	zero,0(s1)
  for(int i = 0; i < 512; i++){
    800014ee:	04a1                	addi	s1,s1,8
    800014f0:	03248163          	beq	s1,s2,80001512 <freewalk+0x52>
    pte_t pte = pagetable[i];
    800014f4:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800014f6:	00f7f713          	andi	a4,a5,15
    800014fa:	ff3701e3          	beq	a4,s3,800014dc <freewalk+0x1c>
    } else if(pte & PTE_V){
    800014fe:	8b85                	andi	a5,a5,1
    80001500:	d7fd                	beqz	a5,800014ee <freewalk+0x2e>
      panic("freewalk: leaf");
    80001502:	00007517          	auipc	a0,0x7
    80001506:	c7650513          	addi	a0,a0,-906 # 80008178 <digits+0x138>
    8000150a:	fffff097          	auipc	ra,0xfffff
    8000150e:	034080e7          	jalr	52(ra) # 8000053e <panic>
    }
  }
  kfree((void*)pagetable);
    80001512:	8552                	mv	a0,s4
    80001514:	fffff097          	auipc	ra,0xfffff
    80001518:	4d2080e7          	jalr	1234(ra) # 800009e6 <kfree>
}
    8000151c:	70a2                	ld	ra,40(sp)
    8000151e:	7402                	ld	s0,32(sp)
    80001520:	64e2                	ld	s1,24(sp)
    80001522:	6942                	ld	s2,16(sp)
    80001524:	69a2                	ld	s3,8(sp)
    80001526:	6a02                	ld	s4,0(sp)
    80001528:	6145                	addi	sp,sp,48
    8000152a:	8082                	ret

000000008000152c <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    8000152c:	1101                	addi	sp,sp,-32
    8000152e:	ec06                	sd	ra,24(sp)
    80001530:	e822                	sd	s0,16(sp)
    80001532:	e426                	sd	s1,8(sp)
    80001534:	1000                	addi	s0,sp,32
    80001536:	84aa                	mv	s1,a0
  if(sz > 0)
    80001538:	e999                	bnez	a1,8000154e <uvmfree+0x22>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    8000153a:	8526                	mv	a0,s1
    8000153c:	00000097          	auipc	ra,0x0
    80001540:	f84080e7          	jalr	-124(ra) # 800014c0 <freewalk>
}
    80001544:	60e2                	ld	ra,24(sp)
    80001546:	6442                	ld	s0,16(sp)
    80001548:	64a2                	ld	s1,8(sp)
    8000154a:	6105                	addi	sp,sp,32
    8000154c:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    8000154e:	6785                	lui	a5,0x1
    80001550:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001552:	95be                	add	a1,a1,a5
    80001554:	4685                	li	a3,1
    80001556:	00c5d613          	srli	a2,a1,0xc
    8000155a:	4581                	li	a1,0
    8000155c:	00000097          	auipc	ra,0x0
    80001560:	d06080e7          	jalr	-762(ra) # 80001262 <uvmunmap>
    80001564:	bfd9                	j	8000153a <uvmfree+0xe>

0000000080001566 <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    80001566:	c679                	beqz	a2,80001634 <uvmcopy+0xce>
{
    80001568:	715d                	addi	sp,sp,-80
    8000156a:	e486                	sd	ra,72(sp)
    8000156c:	e0a2                	sd	s0,64(sp)
    8000156e:	fc26                	sd	s1,56(sp)
    80001570:	f84a                	sd	s2,48(sp)
    80001572:	f44e                	sd	s3,40(sp)
    80001574:	f052                	sd	s4,32(sp)
    80001576:	ec56                	sd	s5,24(sp)
    80001578:	e85a                	sd	s6,16(sp)
    8000157a:	e45e                	sd	s7,8(sp)
    8000157c:	0880                	addi	s0,sp,80
    8000157e:	8b2a                	mv	s6,a0
    80001580:	8aae                	mv	s5,a1
    80001582:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += PGSIZE){
    80001584:	4981                	li	s3,0
    if((pte = walk(old, i, 0)) == 0)
    80001586:	4601                	li	a2,0
    80001588:	85ce                	mv	a1,s3
    8000158a:	855a                	mv	a0,s6
    8000158c:	00000097          	auipc	ra,0x0
    80001590:	a28080e7          	jalr	-1496(ra) # 80000fb4 <walk>
    80001594:	c531                	beqz	a0,800015e0 <uvmcopy+0x7a>
      panic("uvmcopy: pte should exist");
    if((*pte & PTE_V) == 0)
    80001596:	6118                	ld	a4,0(a0)
    80001598:	00177793          	andi	a5,a4,1
    8000159c:	cbb1                	beqz	a5,800015f0 <uvmcopy+0x8a>
      panic("uvmcopy: page not present");
    pa = PTE2PA(*pte);
    8000159e:	00a75593          	srli	a1,a4,0xa
    800015a2:	00c59b93          	slli	s7,a1,0xc
    flags = PTE_FLAGS(*pte);
    800015a6:	3ff77493          	andi	s1,a4,1023
    if((mem = kalloc()) == 0)
    800015aa:	fffff097          	auipc	ra,0xfffff
    800015ae:	53a080e7          	jalr	1338(ra) # 80000ae4 <kalloc>
    800015b2:	892a                	mv	s2,a0
    800015b4:	c939                	beqz	a0,8000160a <uvmcopy+0xa4>
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    800015b6:	6605                	lui	a2,0x1
    800015b8:	85de                	mv	a1,s7
    800015ba:	fffff097          	auipc	ra,0xfffff
    800015be:	772080e7          	jalr	1906(ra) # 80000d2c <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    800015c2:	8726                	mv	a4,s1
    800015c4:	86ca                	mv	a3,s2
    800015c6:	6605                	lui	a2,0x1
    800015c8:	85ce                	mv	a1,s3
    800015ca:	8556                	mv	a0,s5
    800015cc:	00000097          	auipc	ra,0x0
    800015d0:	ad0080e7          	jalr	-1328(ra) # 8000109c <mappages>
    800015d4:	e515                	bnez	a0,80001600 <uvmcopy+0x9a>
  for(i = 0; i < sz; i += PGSIZE){
    800015d6:	6785                	lui	a5,0x1
    800015d8:	99be                	add	s3,s3,a5
    800015da:	fb49e6e3          	bltu	s3,s4,80001586 <uvmcopy+0x20>
    800015de:	a081                	j	8000161e <uvmcopy+0xb8>
      panic("uvmcopy: pte should exist");
    800015e0:	00007517          	auipc	a0,0x7
    800015e4:	ba850513          	addi	a0,a0,-1112 # 80008188 <digits+0x148>
    800015e8:	fffff097          	auipc	ra,0xfffff
    800015ec:	f56080e7          	jalr	-170(ra) # 8000053e <panic>
      panic("uvmcopy: page not present");
    800015f0:	00007517          	auipc	a0,0x7
    800015f4:	bb850513          	addi	a0,a0,-1096 # 800081a8 <digits+0x168>
    800015f8:	fffff097          	auipc	ra,0xfffff
    800015fc:	f46080e7          	jalr	-186(ra) # 8000053e <panic>
      kfree(mem);
    80001600:	854a                	mv	a0,s2
    80001602:	fffff097          	auipc	ra,0xfffff
    80001606:	3e4080e7          	jalr	996(ra) # 800009e6 <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    8000160a:	4685                	li	a3,1
    8000160c:	00c9d613          	srli	a2,s3,0xc
    80001610:	4581                	li	a1,0
    80001612:	8556                	mv	a0,s5
    80001614:	00000097          	auipc	ra,0x0
    80001618:	c4e080e7          	jalr	-946(ra) # 80001262 <uvmunmap>
  return -1;
    8000161c:	557d                	li	a0,-1
}
    8000161e:	60a6                	ld	ra,72(sp)
    80001620:	6406                	ld	s0,64(sp)
    80001622:	74e2                	ld	s1,56(sp)
    80001624:	7942                	ld	s2,48(sp)
    80001626:	79a2                	ld	s3,40(sp)
    80001628:	7a02                	ld	s4,32(sp)
    8000162a:	6ae2                	ld	s5,24(sp)
    8000162c:	6b42                	ld	s6,16(sp)
    8000162e:	6ba2                	ld	s7,8(sp)
    80001630:	6161                	addi	sp,sp,80
    80001632:	8082                	ret
  return 0;
    80001634:	4501                	li	a0,0
}
    80001636:	8082                	ret

0000000080001638 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    80001638:	1141                	addi	sp,sp,-16
    8000163a:	e406                	sd	ra,8(sp)
    8000163c:	e022                	sd	s0,0(sp)
    8000163e:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    80001640:	4601                	li	a2,0
    80001642:	00000097          	auipc	ra,0x0
    80001646:	972080e7          	jalr	-1678(ra) # 80000fb4 <walk>
  if(pte == 0)
    8000164a:	c901                	beqz	a0,8000165a <uvmclear+0x22>
    panic("uvmclear");
  *pte &= ~PTE_U;
    8000164c:	611c                	ld	a5,0(a0)
    8000164e:	9bbd                	andi	a5,a5,-17
    80001650:	e11c                	sd	a5,0(a0)
}
    80001652:	60a2                	ld	ra,8(sp)
    80001654:	6402                	ld	s0,0(sp)
    80001656:	0141                	addi	sp,sp,16
    80001658:	8082                	ret
    panic("uvmclear");
    8000165a:	00007517          	auipc	a0,0x7
    8000165e:	b6e50513          	addi	a0,a0,-1170 # 800081c8 <digits+0x188>
    80001662:	fffff097          	auipc	ra,0xfffff
    80001666:	edc080e7          	jalr	-292(ra) # 8000053e <panic>

000000008000166a <copyout>:
int
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    8000166a:	c6bd                	beqz	a3,800016d8 <copyout+0x6e>
{
    8000166c:	715d                	addi	sp,sp,-80
    8000166e:	e486                	sd	ra,72(sp)
    80001670:	e0a2                	sd	s0,64(sp)
    80001672:	fc26                	sd	s1,56(sp)
    80001674:	f84a                	sd	s2,48(sp)
    80001676:	f44e                	sd	s3,40(sp)
    80001678:	f052                	sd	s4,32(sp)
    8000167a:	ec56                	sd	s5,24(sp)
    8000167c:	e85a                	sd	s6,16(sp)
    8000167e:	e45e                	sd	s7,8(sp)
    80001680:	e062                	sd	s8,0(sp)
    80001682:	0880                	addi	s0,sp,80
    80001684:	8b2a                	mv	s6,a0
    80001686:	8c2e                	mv	s8,a1
    80001688:	8a32                	mv	s4,a2
    8000168a:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(dstva);
    8000168c:	7bfd                	lui	s7,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (dstva - va0);
    8000168e:	6a85                	lui	s5,0x1
    80001690:	a015                	j	800016b4 <copyout+0x4a>
    if(n > len)
      n = len;
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80001692:	9562                	add	a0,a0,s8
    80001694:	0004861b          	sext.w	a2,s1
    80001698:	85d2                	mv	a1,s4
    8000169a:	41250533          	sub	a0,a0,s2
    8000169e:	fffff097          	auipc	ra,0xfffff
    800016a2:	68e080e7          	jalr	1678(ra) # 80000d2c <memmove>

    len -= n;
    800016a6:	409989b3          	sub	s3,s3,s1
    src += n;
    800016aa:	9a26                	add	s4,s4,s1
    dstva = va0 + PGSIZE;
    800016ac:	01590c33          	add	s8,s2,s5
  while(len > 0){
    800016b0:	02098263          	beqz	s3,800016d4 <copyout+0x6a>
    va0 = PGROUNDDOWN(dstva);
    800016b4:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    800016b8:	85ca                	mv	a1,s2
    800016ba:	855a                	mv	a0,s6
    800016bc:	00000097          	auipc	ra,0x0
    800016c0:	99e080e7          	jalr	-1634(ra) # 8000105a <walkaddr>
    if(pa0 == 0)
    800016c4:	cd01                	beqz	a0,800016dc <copyout+0x72>
    n = PGSIZE - (dstva - va0);
    800016c6:	418904b3          	sub	s1,s2,s8
    800016ca:	94d6                	add	s1,s1,s5
    800016cc:	fc99f3e3          	bgeu	s3,s1,80001692 <copyout+0x28>
    800016d0:	84ce                	mv	s1,s3
    800016d2:	b7c1                	j	80001692 <copyout+0x28>
  }
  return 0;
    800016d4:	4501                	li	a0,0
    800016d6:	a021                	j	800016de <copyout+0x74>
    800016d8:	4501                	li	a0,0
}
    800016da:	8082                	ret
      return -1;
    800016dc:	557d                	li	a0,-1
}
    800016de:	60a6                	ld	ra,72(sp)
    800016e0:	6406                	ld	s0,64(sp)
    800016e2:	74e2                	ld	s1,56(sp)
    800016e4:	7942                	ld	s2,48(sp)
    800016e6:	79a2                	ld	s3,40(sp)
    800016e8:	7a02                	ld	s4,32(sp)
    800016ea:	6ae2                	ld	s5,24(sp)
    800016ec:	6b42                	ld	s6,16(sp)
    800016ee:	6ba2                	ld	s7,8(sp)
    800016f0:	6c02                	ld	s8,0(sp)
    800016f2:	6161                	addi	sp,sp,80
    800016f4:	8082                	ret

00000000800016f6 <copyin>:
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    800016f6:	caa5                	beqz	a3,80001766 <copyin+0x70>
{
    800016f8:	715d                	addi	sp,sp,-80
    800016fa:	e486                	sd	ra,72(sp)
    800016fc:	e0a2                	sd	s0,64(sp)
    800016fe:	fc26                	sd	s1,56(sp)
    80001700:	f84a                	sd	s2,48(sp)
    80001702:	f44e                	sd	s3,40(sp)
    80001704:	f052                	sd	s4,32(sp)
    80001706:	ec56                	sd	s5,24(sp)
    80001708:	e85a                	sd	s6,16(sp)
    8000170a:	e45e                	sd	s7,8(sp)
    8000170c:	e062                	sd	s8,0(sp)
    8000170e:	0880                	addi	s0,sp,80
    80001710:	8b2a                	mv	s6,a0
    80001712:	8a2e                	mv	s4,a1
    80001714:	8c32                	mv	s8,a2
    80001716:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80001718:	7bfd                	lui	s7,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    8000171a:	6a85                	lui	s5,0x1
    8000171c:	a01d                	j	80001742 <copyin+0x4c>
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    8000171e:	018505b3          	add	a1,a0,s8
    80001722:	0004861b          	sext.w	a2,s1
    80001726:	412585b3          	sub	a1,a1,s2
    8000172a:	8552                	mv	a0,s4
    8000172c:	fffff097          	auipc	ra,0xfffff
    80001730:	600080e7          	jalr	1536(ra) # 80000d2c <memmove>

    len -= n;
    80001734:	409989b3          	sub	s3,s3,s1
    dst += n;
    80001738:	9a26                	add	s4,s4,s1
    srcva = va0 + PGSIZE;
    8000173a:	01590c33          	add	s8,s2,s5
  while(len > 0){
    8000173e:	02098263          	beqz	s3,80001762 <copyin+0x6c>
    va0 = PGROUNDDOWN(srcva);
    80001742:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    80001746:	85ca                	mv	a1,s2
    80001748:	855a                	mv	a0,s6
    8000174a:	00000097          	auipc	ra,0x0
    8000174e:	910080e7          	jalr	-1776(ra) # 8000105a <walkaddr>
    if(pa0 == 0)
    80001752:	cd01                	beqz	a0,8000176a <copyin+0x74>
    n = PGSIZE - (srcva - va0);
    80001754:	418904b3          	sub	s1,s2,s8
    80001758:	94d6                	add	s1,s1,s5
    8000175a:	fc99f2e3          	bgeu	s3,s1,8000171e <copyin+0x28>
    8000175e:	84ce                	mv	s1,s3
    80001760:	bf7d                	j	8000171e <copyin+0x28>
  }
  return 0;
    80001762:	4501                	li	a0,0
    80001764:	a021                	j	8000176c <copyin+0x76>
    80001766:	4501                	li	a0,0
}
    80001768:	8082                	ret
      return -1;
    8000176a:	557d                	li	a0,-1
}
    8000176c:	60a6                	ld	ra,72(sp)
    8000176e:	6406                	ld	s0,64(sp)
    80001770:	74e2                	ld	s1,56(sp)
    80001772:	7942                	ld	s2,48(sp)
    80001774:	79a2                	ld	s3,40(sp)
    80001776:	7a02                	ld	s4,32(sp)
    80001778:	6ae2                	ld	s5,24(sp)
    8000177a:	6b42                	ld	s6,16(sp)
    8000177c:	6ba2                	ld	s7,8(sp)
    8000177e:	6c02                	ld	s8,0(sp)
    80001780:	6161                	addi	sp,sp,80
    80001782:	8082                	ret

0000000080001784 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    80001784:	c2dd                	beqz	a3,8000182a <copyinstr+0xa6>
{
    80001786:	715d                	addi	sp,sp,-80
    80001788:	e486                	sd	ra,72(sp)
    8000178a:	e0a2                	sd	s0,64(sp)
    8000178c:	fc26                	sd	s1,56(sp)
    8000178e:	f84a                	sd	s2,48(sp)
    80001790:	f44e                	sd	s3,40(sp)
    80001792:	f052                	sd	s4,32(sp)
    80001794:	ec56                	sd	s5,24(sp)
    80001796:	e85a                	sd	s6,16(sp)
    80001798:	e45e                	sd	s7,8(sp)
    8000179a:	0880                	addi	s0,sp,80
    8000179c:	8a2a                	mv	s4,a0
    8000179e:	8b2e                	mv	s6,a1
    800017a0:	8bb2                	mv	s7,a2
    800017a2:	84b6                	mv	s1,a3
    va0 = PGROUNDDOWN(srcva);
    800017a4:	7afd                	lui	s5,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    800017a6:	6985                	lui	s3,0x1
    800017a8:	a02d                	j	800017d2 <copyinstr+0x4e>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    800017aa:	00078023          	sb	zero,0(a5) # 1000 <_entry-0x7ffff000>
    800017ae:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    800017b0:	37fd                	addiw	a5,a5,-1
    800017b2:	0007851b          	sext.w	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    800017b6:	60a6                	ld	ra,72(sp)
    800017b8:	6406                	ld	s0,64(sp)
    800017ba:	74e2                	ld	s1,56(sp)
    800017bc:	7942                	ld	s2,48(sp)
    800017be:	79a2                	ld	s3,40(sp)
    800017c0:	7a02                	ld	s4,32(sp)
    800017c2:	6ae2                	ld	s5,24(sp)
    800017c4:	6b42                	ld	s6,16(sp)
    800017c6:	6ba2                	ld	s7,8(sp)
    800017c8:	6161                	addi	sp,sp,80
    800017ca:	8082                	ret
    srcva = va0 + PGSIZE;
    800017cc:	01390bb3          	add	s7,s2,s3
  while(got_null == 0 && max > 0){
    800017d0:	c8a9                	beqz	s1,80001822 <copyinstr+0x9e>
    va0 = PGROUNDDOWN(srcva);
    800017d2:	015bf933          	and	s2,s7,s5
    pa0 = walkaddr(pagetable, va0);
    800017d6:	85ca                	mv	a1,s2
    800017d8:	8552                	mv	a0,s4
    800017da:	00000097          	auipc	ra,0x0
    800017de:	880080e7          	jalr	-1920(ra) # 8000105a <walkaddr>
    if(pa0 == 0)
    800017e2:	c131                	beqz	a0,80001826 <copyinstr+0xa2>
    n = PGSIZE - (srcva - va0);
    800017e4:	417906b3          	sub	a3,s2,s7
    800017e8:	96ce                	add	a3,a3,s3
    800017ea:	00d4f363          	bgeu	s1,a3,800017f0 <copyinstr+0x6c>
    800017ee:	86a6                	mv	a3,s1
    char *p = (char *) (pa0 + (srcva - va0));
    800017f0:	955e                	add	a0,a0,s7
    800017f2:	41250533          	sub	a0,a0,s2
    while(n > 0){
    800017f6:	daf9                	beqz	a3,800017cc <copyinstr+0x48>
    800017f8:	87da                	mv	a5,s6
      if(*p == '\0'){
    800017fa:	41650633          	sub	a2,a0,s6
    800017fe:	fff48593          	addi	a1,s1,-1
    80001802:	95da                	add	a1,a1,s6
    while(n > 0){
    80001804:	96da                	add	a3,a3,s6
      if(*p == '\0'){
    80001806:	00f60733          	add	a4,a2,a5
    8000180a:	00074703          	lbu	a4,0(a4) # fffffffffffff000 <end+0xffffffff7ffdcea0>
    8000180e:	df51                	beqz	a4,800017aa <copyinstr+0x26>
        *dst = *p;
    80001810:	00e78023          	sb	a4,0(a5)
      --max;
    80001814:	40f584b3          	sub	s1,a1,a5
      dst++;
    80001818:	0785                	addi	a5,a5,1
    while(n > 0){
    8000181a:	fed796e3          	bne	a5,a3,80001806 <copyinstr+0x82>
      dst++;
    8000181e:	8b3e                	mv	s6,a5
    80001820:	b775                	j	800017cc <copyinstr+0x48>
    80001822:	4781                	li	a5,0
    80001824:	b771                	j	800017b0 <copyinstr+0x2c>
      return -1;
    80001826:	557d                	li	a0,-1
    80001828:	b779                	j	800017b6 <copyinstr+0x32>
  int got_null = 0;
    8000182a:	4781                	li	a5,0
  if(got_null){
    8000182c:	37fd                	addiw	a5,a5,-1
    8000182e:	0007851b          	sext.w	a0,a5
}
    80001832:	8082                	ret

0000000080001834 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80001834:	7139                	addi	sp,sp,-64
    80001836:	fc06                	sd	ra,56(sp)
    80001838:	f822                	sd	s0,48(sp)
    8000183a:	f426                	sd	s1,40(sp)
    8000183c:	f04a                	sd	s2,32(sp)
    8000183e:	ec4e                	sd	s3,24(sp)
    80001840:	e852                	sd	s4,16(sp)
    80001842:	e456                	sd	s5,8(sp)
    80001844:	e05a                	sd	s6,0(sp)
    80001846:	0080                	addi	s0,sp,64
    80001848:	89aa                	mv	s3,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    8000184a:	0000f497          	auipc	s1,0xf
    8000184e:	73648493          	addi	s1,s1,1846 # 80010f80 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    80001852:	8b26                	mv	s6,s1
    80001854:	00006a97          	auipc	s5,0x6
    80001858:	7aca8a93          	addi	s5,s5,1964 # 80008000 <etext>
    8000185c:	04000937          	lui	s2,0x4000
    80001860:	197d                	addi	s2,s2,-1 # 3ffffff <_entry-0x7c000001>
    80001862:	0932                	slli	s2,s2,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80001864:	00015a17          	auipc	s4,0x15
    80001868:	51ca0a13          	addi	s4,s4,1308 # 80016d80 <tickslock>
    char *pa = kalloc();
    8000186c:	fffff097          	auipc	ra,0xfffff
    80001870:	278080e7          	jalr	632(ra) # 80000ae4 <kalloc>
    80001874:	862a                	mv	a2,a0
    if(pa == 0)
    80001876:	c131                	beqz	a0,800018ba <proc_mapstacks+0x86>
    uint64 va = KSTACK((int) (p - proc));
    80001878:	416485b3          	sub	a1,s1,s6
    8000187c:	858d                	srai	a1,a1,0x3
    8000187e:	000ab783          	ld	a5,0(s5)
    80001882:	02f585b3          	mul	a1,a1,a5
    80001886:	2585                	addiw	a1,a1,1
    80001888:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    8000188c:	4719                	li	a4,6
    8000188e:	6685                	lui	a3,0x1
    80001890:	40b905b3          	sub	a1,s2,a1
    80001894:	854e                	mv	a0,s3
    80001896:	00000097          	auipc	ra,0x0
    8000189a:	8a6080e7          	jalr	-1882(ra) # 8000113c <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000189e:	17848493          	addi	s1,s1,376
    800018a2:	fd4495e3          	bne	s1,s4,8000186c <proc_mapstacks+0x38>
  }
}
    800018a6:	70e2                	ld	ra,56(sp)
    800018a8:	7442                	ld	s0,48(sp)
    800018aa:	74a2                	ld	s1,40(sp)
    800018ac:	7902                	ld	s2,32(sp)
    800018ae:	69e2                	ld	s3,24(sp)
    800018b0:	6a42                	ld	s4,16(sp)
    800018b2:	6aa2                	ld	s5,8(sp)
    800018b4:	6b02                	ld	s6,0(sp)
    800018b6:	6121                	addi	sp,sp,64
    800018b8:	8082                	ret
      panic("kalloc");
    800018ba:	00007517          	auipc	a0,0x7
    800018be:	91e50513          	addi	a0,a0,-1762 # 800081d8 <digits+0x198>
    800018c2:	fffff097          	auipc	ra,0xfffff
    800018c6:	c7c080e7          	jalr	-900(ra) # 8000053e <panic>

00000000800018ca <procinit>:

// initialize the proc table.
void
procinit(void)
{
    800018ca:	7139                	addi	sp,sp,-64
    800018cc:	fc06                	sd	ra,56(sp)
    800018ce:	f822                	sd	s0,48(sp)
    800018d0:	f426                	sd	s1,40(sp)
    800018d2:	f04a                	sd	s2,32(sp)
    800018d4:	ec4e                	sd	s3,24(sp)
    800018d6:	e852                	sd	s4,16(sp)
    800018d8:	e456                	sd	s5,8(sp)
    800018da:	e05a                	sd	s6,0(sp)
    800018dc:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    800018de:	00007597          	auipc	a1,0x7
    800018e2:	90258593          	addi	a1,a1,-1790 # 800081e0 <digits+0x1a0>
    800018e6:	0000f517          	auipc	a0,0xf
    800018ea:	26a50513          	addi	a0,a0,618 # 80010b50 <pid_lock>
    800018ee:	fffff097          	auipc	ra,0xfffff
    800018f2:	256080e7          	jalr	598(ra) # 80000b44 <initlock>
  initlock(&wait_lock, "wait_lock");
    800018f6:	00007597          	auipc	a1,0x7
    800018fa:	8f258593          	addi	a1,a1,-1806 # 800081e8 <digits+0x1a8>
    800018fe:	0000f517          	auipc	a0,0xf
    80001902:	26a50513          	addi	a0,a0,618 # 80010b68 <wait_lock>
    80001906:	fffff097          	auipc	ra,0xfffff
    8000190a:	23e080e7          	jalr	574(ra) # 80000b44 <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000190e:	0000f497          	auipc	s1,0xf
    80001912:	67248493          	addi	s1,s1,1650 # 80010f80 <proc>
      initlock(&p->lock, "proc");
    80001916:	00007b17          	auipc	s6,0x7
    8000191a:	8e2b0b13          	addi	s6,s6,-1822 # 800081f8 <digits+0x1b8>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    8000191e:	8aa6                	mv	s5,s1
    80001920:	00006a17          	auipc	s4,0x6
    80001924:	6e0a0a13          	addi	s4,s4,1760 # 80008000 <etext>
    80001928:	04000937          	lui	s2,0x4000
    8000192c:	197d                	addi	s2,s2,-1 # 3ffffff <_entry-0x7c000001>
    8000192e:	0932                	slli	s2,s2,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80001930:	00015997          	auipc	s3,0x15
    80001934:	45098993          	addi	s3,s3,1104 # 80016d80 <tickslock>
      initlock(&p->lock, "proc");
    80001938:	85da                	mv	a1,s6
    8000193a:	8526                	mv	a0,s1
    8000193c:	fffff097          	auipc	ra,0xfffff
    80001940:	208080e7          	jalr	520(ra) # 80000b44 <initlock>
      p->state = UNUSED;
    80001944:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80001948:	415487b3          	sub	a5,s1,s5
    8000194c:	878d                	srai	a5,a5,0x3
    8000194e:	000a3703          	ld	a4,0(s4)
    80001952:	02e787b3          	mul	a5,a5,a4
    80001956:	2785                	addiw	a5,a5,1
    80001958:	00d7979b          	slliw	a5,a5,0xd
    8000195c:	40f907b3          	sub	a5,s2,a5
    80001960:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80001962:	17848493          	addi	s1,s1,376
    80001966:	fd3499e3          	bne	s1,s3,80001938 <procinit+0x6e>
  }
}
    8000196a:	70e2                	ld	ra,56(sp)
    8000196c:	7442                	ld	s0,48(sp)
    8000196e:	74a2                	ld	s1,40(sp)
    80001970:	7902                	ld	s2,32(sp)
    80001972:	69e2                	ld	s3,24(sp)
    80001974:	6a42                	ld	s4,16(sp)
    80001976:	6aa2                	ld	s5,8(sp)
    80001978:	6b02                	ld	s6,0(sp)
    8000197a:	6121                	addi	sp,sp,64
    8000197c:	8082                	ret

000000008000197e <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    8000197e:	1141                	addi	sp,sp,-16
    80001980:	e422                	sd	s0,8(sp)
    80001982:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80001984:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80001986:	2501                	sext.w	a0,a0
    80001988:	6422                	ld	s0,8(sp)
    8000198a:	0141                	addi	sp,sp,16
    8000198c:	8082                	ret

000000008000198e <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    8000198e:	1141                	addi	sp,sp,-16
    80001990:	e422                	sd	s0,8(sp)
    80001992:	0800                	addi	s0,sp,16
    80001994:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80001996:	2781                	sext.w	a5,a5
    80001998:	079e                	slli	a5,a5,0x7
  return c;
}
    8000199a:	0000f517          	auipc	a0,0xf
    8000199e:	1e650513          	addi	a0,a0,486 # 80010b80 <cpus>
    800019a2:	953e                	add	a0,a0,a5
    800019a4:	6422                	ld	s0,8(sp)
    800019a6:	0141                	addi	sp,sp,16
    800019a8:	8082                	ret

00000000800019aa <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    800019aa:	1101                	addi	sp,sp,-32
    800019ac:	ec06                	sd	ra,24(sp)
    800019ae:	e822                	sd	s0,16(sp)
    800019b0:	e426                	sd	s1,8(sp)
    800019b2:	1000                	addi	s0,sp,32
  push_off();
    800019b4:	fffff097          	auipc	ra,0xfffff
    800019b8:	1d4080e7          	jalr	468(ra) # 80000b88 <push_off>
    800019bc:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    800019be:	2781                	sext.w	a5,a5
    800019c0:	079e                	slli	a5,a5,0x7
    800019c2:	0000f717          	auipc	a4,0xf
    800019c6:	18e70713          	addi	a4,a4,398 # 80010b50 <pid_lock>
    800019ca:	97ba                	add	a5,a5,a4
    800019cc:	7b84                	ld	s1,48(a5)
  pop_off();
    800019ce:	fffff097          	auipc	ra,0xfffff
    800019d2:	25a080e7          	jalr	602(ra) # 80000c28 <pop_off>
  return p;
}
    800019d6:	8526                	mv	a0,s1
    800019d8:	60e2                	ld	ra,24(sp)
    800019da:	6442                	ld	s0,16(sp)
    800019dc:	64a2                	ld	s1,8(sp)
    800019de:	6105                	addi	sp,sp,32
    800019e0:	8082                	ret

00000000800019e2 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    800019e2:	1141                	addi	sp,sp,-16
    800019e4:	e406                	sd	ra,8(sp)
    800019e6:	e022                	sd	s0,0(sp)
    800019e8:	0800                	addi	s0,sp,16
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);
    800019ea:	00000097          	auipc	ra,0x0
    800019ee:	fc0080e7          	jalr	-64(ra) # 800019aa <myproc>
    800019f2:	fffff097          	auipc	ra,0xfffff
    800019f6:	296080e7          	jalr	662(ra) # 80000c88 <release>

  if (first) {
    800019fa:	00007797          	auipc	a5,0x7
    800019fe:	e467a783          	lw	a5,-442(a5) # 80008840 <first.1>
    80001a02:	eb89                	bnez	a5,80001a14 <forkret+0x32>
    // be run from main().
    first = 0;
    fsinit(ROOTDEV);
  }

  usertrapret();
    80001a04:	00001097          	auipc	ra,0x1
    80001a08:	d74080e7          	jalr	-652(ra) # 80002778 <usertrapret>
}
    80001a0c:	60a2                	ld	ra,8(sp)
    80001a0e:	6402                	ld	s0,0(sp)
    80001a10:	0141                	addi	sp,sp,16
    80001a12:	8082                	ret
    first = 0;
    80001a14:	00007797          	auipc	a5,0x7
    80001a18:	e207a623          	sw	zero,-468(a5) # 80008840 <first.1>
    fsinit(ROOTDEV);
    80001a1c:	4505                	li	a0,1
    80001a1e:	00002097          	auipc	ra,0x2
    80001a22:	aa6080e7          	jalr	-1370(ra) # 800034c4 <fsinit>
    80001a26:	bff9                	j	80001a04 <forkret+0x22>

0000000080001a28 <allocpid>:
{
    80001a28:	1101                	addi	sp,sp,-32
    80001a2a:	ec06                	sd	ra,24(sp)
    80001a2c:	e822                	sd	s0,16(sp)
    80001a2e:	e426                	sd	s1,8(sp)
    80001a30:	e04a                	sd	s2,0(sp)
    80001a32:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001a34:	0000f917          	auipc	s2,0xf
    80001a38:	11c90913          	addi	s2,s2,284 # 80010b50 <pid_lock>
    80001a3c:	854a                	mv	a0,s2
    80001a3e:	fffff097          	auipc	ra,0xfffff
    80001a42:	196080e7          	jalr	406(ra) # 80000bd4 <acquire>
  pid = nextpid;
    80001a46:	00007797          	auipc	a5,0x7
    80001a4a:	dfe78793          	addi	a5,a5,-514 # 80008844 <nextpid>
    80001a4e:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80001a50:	0014871b          	addiw	a4,s1,1
    80001a54:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001a56:	854a                	mv	a0,s2
    80001a58:	fffff097          	auipc	ra,0xfffff
    80001a5c:	230080e7          	jalr	560(ra) # 80000c88 <release>
}
    80001a60:	8526                	mv	a0,s1
    80001a62:	60e2                	ld	ra,24(sp)
    80001a64:	6442                	ld	s0,16(sp)
    80001a66:	64a2                	ld	s1,8(sp)
    80001a68:	6902                	ld	s2,0(sp)
    80001a6a:	6105                	addi	sp,sp,32
    80001a6c:	8082                	ret

0000000080001a6e <proc_pagetable>:
{
    80001a6e:	1101                	addi	sp,sp,-32
    80001a70:	ec06                	sd	ra,24(sp)
    80001a72:	e822                	sd	s0,16(sp)
    80001a74:	e426                	sd	s1,8(sp)
    80001a76:	e04a                	sd	s2,0(sp)
    80001a78:	1000                	addi	s0,sp,32
    80001a7a:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001a7c:	00000097          	auipc	ra,0x0
    80001a80:	8aa080e7          	jalr	-1878(ra) # 80001326 <uvmcreate>
    80001a84:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001a86:	c121                	beqz	a0,80001ac6 <proc_pagetable+0x58>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80001a88:	4729                	li	a4,10
    80001a8a:	00005697          	auipc	a3,0x5
    80001a8e:	57668693          	addi	a3,a3,1398 # 80007000 <_trampoline>
    80001a92:	6605                	lui	a2,0x1
    80001a94:	040005b7          	lui	a1,0x4000
    80001a98:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a9a:	05b2                	slli	a1,a1,0xc
    80001a9c:	fffff097          	auipc	ra,0xfffff
    80001aa0:	600080e7          	jalr	1536(ra) # 8000109c <mappages>
    80001aa4:	02054863          	bltz	a0,80001ad4 <proc_pagetable+0x66>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80001aa8:	4719                	li	a4,6
    80001aaa:	05893683          	ld	a3,88(s2)
    80001aae:	6605                	lui	a2,0x1
    80001ab0:	020005b7          	lui	a1,0x2000
    80001ab4:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001ab6:	05b6                	slli	a1,a1,0xd
    80001ab8:	8526                	mv	a0,s1
    80001aba:	fffff097          	auipc	ra,0xfffff
    80001abe:	5e2080e7          	jalr	1506(ra) # 8000109c <mappages>
    80001ac2:	02054163          	bltz	a0,80001ae4 <proc_pagetable+0x76>
}
    80001ac6:	8526                	mv	a0,s1
    80001ac8:	60e2                	ld	ra,24(sp)
    80001aca:	6442                	ld	s0,16(sp)
    80001acc:	64a2                	ld	s1,8(sp)
    80001ace:	6902                	ld	s2,0(sp)
    80001ad0:	6105                	addi	sp,sp,32
    80001ad2:	8082                	ret
    uvmfree(pagetable, 0);
    80001ad4:	4581                	li	a1,0
    80001ad6:	8526                	mv	a0,s1
    80001ad8:	00000097          	auipc	ra,0x0
    80001adc:	a54080e7          	jalr	-1452(ra) # 8000152c <uvmfree>
    return 0;
    80001ae0:	4481                	li	s1,0
    80001ae2:	b7d5                	j	80001ac6 <proc_pagetable+0x58>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001ae4:	4681                	li	a3,0
    80001ae6:	4605                	li	a2,1
    80001ae8:	040005b7          	lui	a1,0x4000
    80001aec:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001aee:	05b2                	slli	a1,a1,0xc
    80001af0:	8526                	mv	a0,s1
    80001af2:	fffff097          	auipc	ra,0xfffff
    80001af6:	770080e7          	jalr	1904(ra) # 80001262 <uvmunmap>
    uvmfree(pagetable, 0);
    80001afa:	4581                	li	a1,0
    80001afc:	8526                	mv	a0,s1
    80001afe:	00000097          	auipc	ra,0x0
    80001b02:	a2e080e7          	jalr	-1490(ra) # 8000152c <uvmfree>
    return 0;
    80001b06:	4481                	li	s1,0
    80001b08:	bf7d                	j	80001ac6 <proc_pagetable+0x58>

0000000080001b0a <proc_freepagetable>:
{
    80001b0a:	1101                	addi	sp,sp,-32
    80001b0c:	ec06                	sd	ra,24(sp)
    80001b0e:	e822                	sd	s0,16(sp)
    80001b10:	e426                	sd	s1,8(sp)
    80001b12:	e04a                	sd	s2,0(sp)
    80001b14:	1000                	addi	s0,sp,32
    80001b16:	84aa                	mv	s1,a0
    80001b18:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001b1a:	4681                	li	a3,0
    80001b1c:	4605                	li	a2,1
    80001b1e:	040005b7          	lui	a1,0x4000
    80001b22:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001b24:	05b2                	slli	a1,a1,0xc
    80001b26:	fffff097          	auipc	ra,0xfffff
    80001b2a:	73c080e7          	jalr	1852(ra) # 80001262 <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001b2e:	4681                	li	a3,0
    80001b30:	4605                	li	a2,1
    80001b32:	020005b7          	lui	a1,0x2000
    80001b36:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001b38:	05b6                	slli	a1,a1,0xd
    80001b3a:	8526                	mv	a0,s1
    80001b3c:	fffff097          	auipc	ra,0xfffff
    80001b40:	726080e7          	jalr	1830(ra) # 80001262 <uvmunmap>
  uvmfree(pagetable, sz);
    80001b44:	85ca                	mv	a1,s2
    80001b46:	8526                	mv	a0,s1
    80001b48:	00000097          	auipc	ra,0x0
    80001b4c:	9e4080e7          	jalr	-1564(ra) # 8000152c <uvmfree>
}
    80001b50:	60e2                	ld	ra,24(sp)
    80001b52:	6442                	ld	s0,16(sp)
    80001b54:	64a2                	ld	s1,8(sp)
    80001b56:	6902                	ld	s2,0(sp)
    80001b58:	6105                	addi	sp,sp,32
    80001b5a:	8082                	ret

0000000080001b5c <freeproc>:
{
    80001b5c:	1101                	addi	sp,sp,-32
    80001b5e:	ec06                	sd	ra,24(sp)
    80001b60:	e822                	sd	s0,16(sp)
    80001b62:	e426                	sd	s1,8(sp)
    80001b64:	1000                	addi	s0,sp,32
    80001b66:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001b68:	6d28                	ld	a0,88(a0)
    80001b6a:	c509                	beqz	a0,80001b74 <freeproc+0x18>
    kfree((void*)p->trapframe);
    80001b6c:	fffff097          	auipc	ra,0xfffff
    80001b70:	e7a080e7          	jalr	-390(ra) # 800009e6 <kfree>
  p->trapframe = 0;
    80001b74:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80001b78:	68a8                	ld	a0,80(s1)
    80001b7a:	c511                	beqz	a0,80001b86 <freeproc+0x2a>
    proc_freepagetable(p->pagetable, p->sz);
    80001b7c:	64ac                	ld	a1,72(s1)
    80001b7e:	00000097          	auipc	ra,0x0
    80001b82:	f8c080e7          	jalr	-116(ra) # 80001b0a <proc_freepagetable>
  p->pagetable = 0;
    80001b86:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001b8a:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001b8e:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001b92:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001b96:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001b9a:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001b9e:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001ba2:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001ba6:	0004ac23          	sw	zero,24(s1)
}
    80001baa:	60e2                	ld	ra,24(sp)
    80001bac:	6442                	ld	s0,16(sp)
    80001bae:	64a2                	ld	s1,8(sp)
    80001bb0:	6105                	addi	sp,sp,32
    80001bb2:	8082                	ret

0000000080001bb4 <allocproc>:
{
    80001bb4:	1101                	addi	sp,sp,-32
    80001bb6:	ec06                	sd	ra,24(sp)
    80001bb8:	e822                	sd	s0,16(sp)
    80001bba:	e426                	sd	s1,8(sp)
    80001bbc:	e04a                	sd	s2,0(sp)
    80001bbe:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001bc0:	0000f497          	auipc	s1,0xf
    80001bc4:	3c048493          	addi	s1,s1,960 # 80010f80 <proc>
    80001bc8:	00015917          	auipc	s2,0x15
    80001bcc:	1b890913          	addi	s2,s2,440 # 80016d80 <tickslock>
    acquire(&p->lock);
    80001bd0:	8526                	mv	a0,s1
    80001bd2:	fffff097          	auipc	ra,0xfffff
    80001bd6:	002080e7          	jalr	2(ra) # 80000bd4 <acquire>
    if(p->state == UNUSED) {
    80001bda:	4c9c                	lw	a5,24(s1)
    80001bdc:	cf81                	beqz	a5,80001bf4 <allocproc+0x40>
      release(&p->lock);
    80001bde:	8526                	mv	a0,s1
    80001be0:	fffff097          	auipc	ra,0xfffff
    80001be4:	0a8080e7          	jalr	168(ra) # 80000c88 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001be8:	17848493          	addi	s1,s1,376
    80001bec:	ff2492e3          	bne	s1,s2,80001bd0 <allocproc+0x1c>
  return 0;
    80001bf0:	4481                	li	s1,0
    80001bf2:	a085                	j	80001c52 <allocproc+0x9e>
  p->pid = allocpid();
    80001bf4:	00000097          	auipc	ra,0x0
    80001bf8:	e34080e7          	jalr	-460(ra) # 80001a28 <allocpid>
    80001bfc:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001bfe:	4785                	li	a5,1
    80001c00:	cc9c                	sw	a5,24(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001c02:	fffff097          	auipc	ra,0xfffff
    80001c06:	ee2080e7          	jalr	-286(ra) # 80000ae4 <kalloc>
    80001c0a:	892a                	mv	s2,a0
    80001c0c:	eca8                	sd	a0,88(s1)
    80001c0e:	c929                	beqz	a0,80001c60 <allocproc+0xac>
  p->pagetable = proc_pagetable(p);
    80001c10:	8526                	mv	a0,s1
    80001c12:	00000097          	auipc	ra,0x0
    80001c16:	e5c080e7          	jalr	-420(ra) # 80001a6e <proc_pagetable>
    80001c1a:	892a                	mv	s2,a0
    80001c1c:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80001c1e:	cd29                	beqz	a0,80001c78 <allocproc+0xc4>
  memset(&p->context, 0, sizeof(p->context));
    80001c20:	07000613          	li	a2,112
    80001c24:	4581                	li	a1,0
    80001c26:	06048513          	addi	a0,s1,96
    80001c2a:	fffff097          	auipc	ra,0xfffff
    80001c2e:	0a6080e7          	jalr	166(ra) # 80000cd0 <memset>
  p->context.ra = (uint64)forkret;
    80001c32:	00000797          	auipc	a5,0x0
    80001c36:	db078793          	addi	a5,a5,-592 # 800019e2 <forkret>
    80001c3a:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001c3c:	60bc                	ld	a5,64(s1)
    80001c3e:	6705                	lui	a4,0x1
    80001c40:	97ba                	add	a5,a5,a4
    80001c42:	f4bc                	sd	a5,104(s1)
  p->queue_level = NPRIO-1; // Max priority
    80001c44:	4789                	li	a5,2
    80001c46:	16f4a623          	sw	a5,364(s1)
  p->times_chosen = 0;
    80001c4a:	1604a423          	sw	zero,360(s1)
  p->total_ticks = 0;
    80001c4e:	1604a823          	sw	zero,368(s1)
}
    80001c52:	8526                	mv	a0,s1
    80001c54:	60e2                	ld	ra,24(sp)
    80001c56:	6442                	ld	s0,16(sp)
    80001c58:	64a2                	ld	s1,8(sp)
    80001c5a:	6902                	ld	s2,0(sp)
    80001c5c:	6105                	addi	sp,sp,32
    80001c5e:	8082                	ret
    freeproc(p);
    80001c60:	8526                	mv	a0,s1
    80001c62:	00000097          	auipc	ra,0x0
    80001c66:	efa080e7          	jalr	-262(ra) # 80001b5c <freeproc>
    release(&p->lock);
    80001c6a:	8526                	mv	a0,s1
    80001c6c:	fffff097          	auipc	ra,0xfffff
    80001c70:	01c080e7          	jalr	28(ra) # 80000c88 <release>
    return 0;
    80001c74:	84ca                	mv	s1,s2
    80001c76:	bff1                	j	80001c52 <allocproc+0x9e>
    freeproc(p);
    80001c78:	8526                	mv	a0,s1
    80001c7a:	00000097          	auipc	ra,0x0
    80001c7e:	ee2080e7          	jalr	-286(ra) # 80001b5c <freeproc>
    release(&p->lock);
    80001c82:	8526                	mv	a0,s1
    80001c84:	fffff097          	auipc	ra,0xfffff
    80001c88:	004080e7          	jalr	4(ra) # 80000c88 <release>
    return 0;
    80001c8c:	84ca                	mv	s1,s2
    80001c8e:	b7d1                	j	80001c52 <allocproc+0x9e>

0000000080001c90 <userinit>:
{
    80001c90:	1101                	addi	sp,sp,-32
    80001c92:	ec06                	sd	ra,24(sp)
    80001c94:	e822                	sd	s0,16(sp)
    80001c96:	e426                	sd	s1,8(sp)
    80001c98:	1000                	addi	s0,sp,32
  p = allocproc();
    80001c9a:	00000097          	auipc	ra,0x0
    80001c9e:	f1a080e7          	jalr	-230(ra) # 80001bb4 <allocproc>
    80001ca2:	84aa                	mv	s1,a0
  initproc = p;
    80001ca4:	00007797          	auipc	a5,0x7
    80001ca8:	c2a7ba23          	sd	a0,-972(a5) # 800088d8 <initproc>
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
    80001cac:	03400613          	li	a2,52
    80001cb0:	00007597          	auipc	a1,0x7
    80001cb4:	ba058593          	addi	a1,a1,-1120 # 80008850 <initcode>
    80001cb8:	6928                	ld	a0,80(a0)
    80001cba:	fffff097          	auipc	ra,0xfffff
    80001cbe:	69a080e7          	jalr	1690(ra) # 80001354 <uvmfirst>
  p->sz = PGSIZE;
    80001cc2:	6785                	lui	a5,0x1
    80001cc4:	e4bc                	sd	a5,72(s1)
  p->trapframe->epc = 0;      // user program counter
    80001cc6:	6cb8                	ld	a4,88(s1)
    80001cc8:	00073c23          	sd	zero,24(a4) # 1018 <_entry-0x7fffefe8>
  p->trapframe->sp = PGSIZE;  // user stack pointer
    80001ccc:	6cb8                	ld	a4,88(s1)
    80001cce:	fb1c                	sd	a5,48(a4)
  safestrcpy(p->name, "initcode", sizeof(p->name));
    80001cd0:	4641                	li	a2,16
    80001cd2:	00006597          	auipc	a1,0x6
    80001cd6:	52e58593          	addi	a1,a1,1326 # 80008200 <digits+0x1c0>
    80001cda:	15848513          	addi	a0,s1,344
    80001cde:	fffff097          	auipc	ra,0xfffff
    80001ce2:	13c080e7          	jalr	316(ra) # 80000e1a <safestrcpy>
  p->cwd = namei("/");
    80001ce6:	00006517          	auipc	a0,0x6
    80001cea:	52a50513          	addi	a0,a0,1322 # 80008210 <digits+0x1d0>
    80001cee:	00002097          	auipc	ra,0x2
    80001cf2:	200080e7          	jalr	512(ra) # 80003eee <namei>
    80001cf6:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001cfa:	478d                	li	a5,3
    80001cfc:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001cfe:	8526                	mv	a0,s1
    80001d00:	fffff097          	auipc	ra,0xfffff
    80001d04:	f88080e7          	jalr	-120(ra) # 80000c88 <release>
}
    80001d08:	60e2                	ld	ra,24(sp)
    80001d0a:	6442                	ld	s0,16(sp)
    80001d0c:	64a2                	ld	s1,8(sp)
    80001d0e:	6105                	addi	sp,sp,32
    80001d10:	8082                	ret

0000000080001d12 <growproc>:
{
    80001d12:	1101                	addi	sp,sp,-32
    80001d14:	ec06                	sd	ra,24(sp)
    80001d16:	e822                	sd	s0,16(sp)
    80001d18:	e426                	sd	s1,8(sp)
    80001d1a:	e04a                	sd	s2,0(sp)
    80001d1c:	1000                	addi	s0,sp,32
    80001d1e:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001d20:	00000097          	auipc	ra,0x0
    80001d24:	c8a080e7          	jalr	-886(ra) # 800019aa <myproc>
    80001d28:	84aa                	mv	s1,a0
  sz = p->sz;
    80001d2a:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001d2c:	01204c63          	bgtz	s2,80001d44 <growproc+0x32>
  } else if(n < 0){
    80001d30:	02094663          	bltz	s2,80001d5c <growproc+0x4a>
  p->sz = sz;
    80001d34:	e4ac                	sd	a1,72(s1)
  return 0;
    80001d36:	4501                	li	a0,0
}
    80001d38:	60e2                	ld	ra,24(sp)
    80001d3a:	6442                	ld	s0,16(sp)
    80001d3c:	64a2                	ld	s1,8(sp)
    80001d3e:	6902                	ld	s2,0(sp)
    80001d40:	6105                	addi	sp,sp,32
    80001d42:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001d44:	4691                	li	a3,4
    80001d46:	00b90633          	add	a2,s2,a1
    80001d4a:	6928                	ld	a0,80(a0)
    80001d4c:	fffff097          	auipc	ra,0xfffff
    80001d50:	6c2080e7          	jalr	1730(ra) # 8000140e <uvmalloc>
    80001d54:	85aa                	mv	a1,a0
    80001d56:	fd79                	bnez	a0,80001d34 <growproc+0x22>
      return -1;
    80001d58:	557d                	li	a0,-1
    80001d5a:	bff9                	j	80001d38 <growproc+0x26>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001d5c:	00b90633          	add	a2,s2,a1
    80001d60:	6928                	ld	a0,80(a0)
    80001d62:	fffff097          	auipc	ra,0xfffff
    80001d66:	664080e7          	jalr	1636(ra) # 800013c6 <uvmdealloc>
    80001d6a:	85aa                	mv	a1,a0
    80001d6c:	b7e1                	j	80001d34 <growproc+0x22>

0000000080001d6e <fork>:
{
    80001d6e:	7139                	addi	sp,sp,-64
    80001d70:	fc06                	sd	ra,56(sp)
    80001d72:	f822                	sd	s0,48(sp)
    80001d74:	f426                	sd	s1,40(sp)
    80001d76:	f04a                	sd	s2,32(sp)
    80001d78:	ec4e                	sd	s3,24(sp)
    80001d7a:	e852                	sd	s4,16(sp)
    80001d7c:	e456                	sd	s5,8(sp)
    80001d7e:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001d80:	00000097          	auipc	ra,0x0
    80001d84:	c2a080e7          	jalr	-982(ra) # 800019aa <myproc>
    80001d88:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001d8a:	00000097          	auipc	ra,0x0
    80001d8e:	e2a080e7          	jalr	-470(ra) # 80001bb4 <allocproc>
    80001d92:	10050c63          	beqz	a0,80001eaa <fork+0x13c>
    80001d96:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001d98:	048ab603          	ld	a2,72(s5)
    80001d9c:	692c                	ld	a1,80(a0)
    80001d9e:	050ab503          	ld	a0,80(s5)
    80001da2:	fffff097          	auipc	ra,0xfffff
    80001da6:	7c4080e7          	jalr	1988(ra) # 80001566 <uvmcopy>
    80001daa:	04054863          	bltz	a0,80001dfa <fork+0x8c>
  np->sz = p->sz;
    80001dae:	048ab783          	ld	a5,72(s5)
    80001db2:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001db6:	058ab683          	ld	a3,88(s5)
    80001dba:	87b6                	mv	a5,a3
    80001dbc:	058a3703          	ld	a4,88(s4)
    80001dc0:	12068693          	addi	a3,a3,288
    80001dc4:	0007b803          	ld	a6,0(a5) # 1000 <_entry-0x7ffff000>
    80001dc8:	6788                	ld	a0,8(a5)
    80001dca:	6b8c                	ld	a1,16(a5)
    80001dcc:	6f90                	ld	a2,24(a5)
    80001dce:	01073023          	sd	a6,0(a4)
    80001dd2:	e708                	sd	a0,8(a4)
    80001dd4:	eb0c                	sd	a1,16(a4)
    80001dd6:	ef10                	sd	a2,24(a4)
    80001dd8:	02078793          	addi	a5,a5,32
    80001ddc:	02070713          	addi	a4,a4,32
    80001de0:	fed792e3          	bne	a5,a3,80001dc4 <fork+0x56>
  np->trapframe->a0 = 0;
    80001de4:	058a3783          	ld	a5,88(s4)
    80001de8:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001dec:	0d0a8493          	addi	s1,s5,208
    80001df0:	0d0a0913          	addi	s2,s4,208
    80001df4:	150a8993          	addi	s3,s5,336
    80001df8:	a00d                	j	80001e1a <fork+0xac>
    freeproc(np);
    80001dfa:	8552                	mv	a0,s4
    80001dfc:	00000097          	auipc	ra,0x0
    80001e00:	d60080e7          	jalr	-672(ra) # 80001b5c <freeproc>
    release(&np->lock);
    80001e04:	8552                	mv	a0,s4
    80001e06:	fffff097          	auipc	ra,0xfffff
    80001e0a:	e82080e7          	jalr	-382(ra) # 80000c88 <release>
    return -1;
    80001e0e:	597d                	li	s2,-1
    80001e10:	a059                	j	80001e96 <fork+0x128>
  for(i = 0; i < NOFILE; i++)
    80001e12:	04a1                	addi	s1,s1,8
    80001e14:	0921                	addi	s2,s2,8
    80001e16:	01348b63          	beq	s1,s3,80001e2c <fork+0xbe>
    if(p->ofile[i])
    80001e1a:	6088                	ld	a0,0(s1)
    80001e1c:	d97d                	beqz	a0,80001e12 <fork+0xa4>
      np->ofile[i] = filedup(p->ofile[i]);
    80001e1e:	00002097          	auipc	ra,0x2
    80001e22:	766080e7          	jalr	1894(ra) # 80004584 <filedup>
    80001e26:	00a93023          	sd	a0,0(s2)
    80001e2a:	b7e5                	j	80001e12 <fork+0xa4>
  np->cwd = idup(p->cwd);
    80001e2c:	150ab503          	ld	a0,336(s5)
    80001e30:	00002097          	auipc	ra,0x2
    80001e34:	8d4080e7          	jalr	-1836(ra) # 80003704 <idup>
    80001e38:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001e3c:	4641                	li	a2,16
    80001e3e:	158a8593          	addi	a1,s5,344
    80001e42:	158a0513          	addi	a0,s4,344
    80001e46:	fffff097          	auipc	ra,0xfffff
    80001e4a:	fd4080e7          	jalr	-44(ra) # 80000e1a <safestrcpy>
  pid = np->pid;
    80001e4e:	030a2903          	lw	s2,48(s4)
  release(&np->lock);
    80001e52:	8552                	mv	a0,s4
    80001e54:	fffff097          	auipc	ra,0xfffff
    80001e58:	e34080e7          	jalr	-460(ra) # 80000c88 <release>
  acquire(&wait_lock);
    80001e5c:	0000f497          	auipc	s1,0xf
    80001e60:	d0c48493          	addi	s1,s1,-756 # 80010b68 <wait_lock>
    80001e64:	8526                	mv	a0,s1
    80001e66:	fffff097          	auipc	ra,0xfffff
    80001e6a:	d6e080e7          	jalr	-658(ra) # 80000bd4 <acquire>
  np->parent = p;
    80001e6e:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001e72:	8526                	mv	a0,s1
    80001e74:	fffff097          	auipc	ra,0xfffff
    80001e78:	e14080e7          	jalr	-492(ra) # 80000c88 <release>
  acquire(&np->lock);
    80001e7c:	8552                	mv	a0,s4
    80001e7e:	fffff097          	auipc	ra,0xfffff
    80001e82:	d56080e7          	jalr	-682(ra) # 80000bd4 <acquire>
  np->state = RUNNABLE;
    80001e86:	478d                	li	a5,3
    80001e88:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001e8c:	8552                	mv	a0,s4
    80001e8e:	fffff097          	auipc	ra,0xfffff
    80001e92:	dfa080e7          	jalr	-518(ra) # 80000c88 <release>
}
    80001e96:	854a                	mv	a0,s2
    80001e98:	70e2                	ld	ra,56(sp)
    80001e9a:	7442                	ld	s0,48(sp)
    80001e9c:	74a2                	ld	s1,40(sp)
    80001e9e:	7902                	ld	s2,32(sp)
    80001ea0:	69e2                	ld	s3,24(sp)
    80001ea2:	6a42                	ld	s4,16(sp)
    80001ea4:	6aa2                	ld	s5,8(sp)
    80001ea6:	6121                	addi	sp,sp,64
    80001ea8:	8082                	ret
    return -1;
    80001eaa:	597d                	li	s2,-1
    80001eac:	b7ed                	j	80001e96 <fork+0x128>

0000000080001eae <scheduler>:
{
    80001eae:	7119                	addi	sp,sp,-128
    80001eb0:	fc86                	sd	ra,120(sp)
    80001eb2:	f8a2                	sd	s0,112(sp)
    80001eb4:	f4a6                	sd	s1,104(sp)
    80001eb6:	f0ca                	sd	s2,96(sp)
    80001eb8:	ecce                	sd	s3,88(sp)
    80001eba:	e8d2                	sd	s4,80(sp)
    80001ebc:	e4d6                	sd	s5,72(sp)
    80001ebe:	e0da                	sd	s6,64(sp)
    80001ec0:	fc5e                	sd	s7,56(sp)
    80001ec2:	f862                	sd	s8,48(sp)
    80001ec4:	f466                	sd	s9,40(sp)
    80001ec6:	f06a                	sd	s10,32(sp)
    80001ec8:	ec6e                	sd	s11,24(sp)
    80001eca:	0100                	addi	s0,sp,128
    80001ecc:	8792                	mv	a5,tp
  int id = r_tp();
    80001ece:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001ed0:	00779693          	slli	a3,a5,0x7
    80001ed4:	0000f717          	auipc	a4,0xf
    80001ed8:	c7c70713          	addi	a4,a4,-900 # 80010b50 <pid_lock>
    80001edc:	9736                	add	a4,a4,a3
    80001ede:	02073823          	sd	zero,48(a4)
      swtch(&c->context, &selected_proc->context);
    80001ee2:	0000f717          	auipc	a4,0xf
    80001ee6:	ca670713          	addi	a4,a4,-858 # 80010b88 <cpus+0x8>
    80001eea:	9736                	add	a4,a4,a3
    80001eec:	f8e43423          	sd	a4,-120(s0)
  struct proc *selected_proc = 0;
    80001ef0:	4b01                	li	s6,0
    min_times_selected = 99999;
    80001ef2:	6ce1                	lui	s9,0x18
    80001ef4:	69fc8c93          	addi	s9,s9,1695 # 1869f <_entry-0x7ffe7961>
        found_runnable = 1;
    80001ef8:	4c05                	li	s8,1
    for(p = proc; p < &proc[NPROC]; p++) {
    80001efa:	00015997          	auipc	s3,0x15
    80001efe:	e8698993          	addi	s3,s3,-378 # 80016d80 <tickslock>
      c->proc = selected_proc;
    80001f02:	0000fd17          	auipc	s10,0xf
    80001f06:	c4ed0d13          	addi	s10,s10,-946 # 80010b50 <pid_lock>
    80001f0a:	9d36                	add	s10,s10,a3
      start_ticks = ticks;
    80001f0c:	00007d97          	auipc	s11,0x7
    80001f10:	9d4d8d93          	addi	s11,s11,-1580 # 800088e0 <ticks>
    80001f14:	a891                	j	80001f68 <scheduler+0xba>
      else if(p->state == RUNNABLE && p->queue_level == max_prio_found &&
    80001f16:	03478d63          	beq	a5,s4,80001f50 <scheduler+0xa2>
      release(&p->lock);
    80001f1a:	8526                	mv	a0,s1
    80001f1c:	fffff097          	auipc	ra,0xfffff
    80001f20:	d6c080e7          	jalr	-660(ra) # 80000c88 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001f24:	17848493          	addi	s1,s1,376
    80001f28:	03348e63          	beq	s1,s3,80001f64 <scheduler+0xb6>
      acquire(&p->lock);
    80001f2c:	8526                	mv	a0,s1
    80001f2e:	fffff097          	auipc	ra,0xfffff
    80001f32:	ca6080e7          	jalr	-858(ra) # 80000bd4 <acquire>
      if(p->state == RUNNABLE && p->queue_level > max_prio_found) {
    80001f36:	4c9c                	lw	a5,24(s1)
    80001f38:	ff2791e3          	bne	a5,s2,80001f1a <scheduler+0x6c>
    80001f3c:	16c4a783          	lw	a5,364(s1)
    80001f40:	fcfa5be3          	bge	s4,a5,80001f16 <scheduler+0x68>
        min_times_selected = p->times_chosen;
    80001f44:	1684aa83          	lw	s5,360(s1)
    80001f48:	8b26                	mv	s6,s1
        max_prio_found = p->queue_level;
    80001f4a:	8a3e                	mv	s4,a5
        found_runnable = 1;
    80001f4c:	8be2                	mv	s7,s8
        min_times_selected = p->times_chosen;
    80001f4e:	b7f1                	j	80001f1a <scheduler+0x6c>
      p->times_chosen < min_times_selected){
    80001f50:	1684a783          	lw	a5,360(s1)
      else if(p->state == RUNNABLE && p->queue_level == max_prio_found &&
    80001f54:	000a871b          	sext.w	a4,s5
    80001f58:	fce7f1e3          	bgeu	a5,a4,80001f1a <scheduler+0x6c>
        min_times_selected = p->times_chosen;
    80001f5c:	00078a9b          	sext.w	s5,a5
    80001f60:	8b26                	mv	s6,s1
    80001f62:	bf65                	j	80001f1a <scheduler+0x6c>
    if(found_runnable == 1) {
    80001f64:	038b8163          	beq	s7,s8,80001f86 <scheduler+0xd8>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001f68:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001f6c:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001f70:	10079073          	csrw	sstatus,a5
    found_runnable = 0;
    80001f74:	4b81                	li	s7,0
    min_times_selected = 99999;
    80001f76:	8ae6                	mv	s5,s9
    max_prio_found = -1;
    80001f78:	5a7d                	li	s4,-1
    for(p = proc; p < &proc[NPROC]; p++) {
    80001f7a:	0000f497          	auipc	s1,0xf
    80001f7e:	00648493          	addi	s1,s1,6 # 80010f80 <proc>
      if(p->state == RUNNABLE && p->queue_level > max_prio_found) {
    80001f82:	490d                	li	s2,3
    80001f84:	b765                	j	80001f2c <scheduler+0x7e>
      acquire(&selected_proc->lock);
    80001f86:	895a                	mv	s2,s6
    80001f88:	855a                	mv	a0,s6
    80001f8a:	fffff097          	auipc	ra,0xfffff
    80001f8e:	c4a080e7          	jalr	-950(ra) # 80000bd4 <acquire>
      selected_proc->state = RUNNING;
    80001f92:	4791                	li	a5,4
    80001f94:	00fb2c23          	sw	a5,24(s6)
      c->proc = selected_proc;
    80001f98:	036d3823          	sd	s6,48(s10)
      acquire(&tickslock);
    80001f9c:	00015517          	auipc	a0,0x15
    80001fa0:	de450513          	addi	a0,a0,-540 # 80016d80 <tickslock>
    80001fa4:	fffff097          	auipc	ra,0xfffff
    80001fa8:	c30080e7          	jalr	-976(ra) # 80000bd4 <acquire>
      start_ticks = ticks;
    80001fac:	000da483          	lw	s1,0(s11)
      release(&tickslock);
    80001fb0:	00015517          	auipc	a0,0x15
    80001fb4:	dd050513          	addi	a0,a0,-560 # 80016d80 <tickslock>
    80001fb8:	fffff097          	auipc	ra,0xfffff
    80001fbc:	cd0080e7          	jalr	-816(ra) # 80000c88 <release>
      selected_proc->times_chosen++;
    80001fc0:	168b2783          	lw	a5,360(s6)
    80001fc4:	2785                	addiw	a5,a5,1
    80001fc6:	16fb2423          	sw	a5,360(s6)
      swtch(&c->context, &selected_proc->context);
    80001fca:	060b0593          	addi	a1,s6,96
    80001fce:	f8843503          	ld	a0,-120(s0)
    80001fd2:	00000097          	auipc	ra,0x0
    80001fd6:	6fc080e7          	jalr	1788(ra) # 800026ce <swtch>
      acquire(&tickslock);
    80001fda:	00015517          	auipc	a0,0x15
    80001fde:	da650513          	addi	a0,a0,-602 # 80016d80 <tickslock>
    80001fe2:	fffff097          	auipc	ra,0xfffff
    80001fe6:	bf2080e7          	jalr	-1038(ra) # 80000bd4 <acquire>
      run_ticks = ticks - start_ticks;
    80001fea:	000da783          	lw	a5,0(s11)
    80001fee:	409784bb          	subw	s1,a5,s1
      release(&tickslock);
    80001ff2:	00015517          	auipc	a0,0x15
    80001ff6:	d8e50513          	addi	a0,a0,-626 # 80016d80 <tickslock>
    80001ffa:	fffff097          	auipc	ra,0xfffff
    80001ffe:	c8e080e7          	jalr	-882(ra) # 80000c88 <release>
      selected_proc->total_ticks += run_ticks;
    80002002:	170b2783          	lw	a5,368(s6)
    80002006:	9fa5                	addw	a5,a5,s1
    80002008:	0007871b          	sext.w	a4,a5
    8000200c:	16fb2823          	sw	a5,368(s6)
      if(selected_proc->total_ticks >= 100000) {
    80002010:	00ecfb63          	bgeu	s9,a4,80002026 <scheduler+0x178>
        if(selected_proc->queue_level > 0) {
    80002014:	16cb2783          	lw	a5,364(s6)
    80002018:	00f05563          	blez	a5,80002022 <scheduler+0x174>
          selected_proc->queue_level--;
    8000201c:	37fd                	addiw	a5,a5,-1
    8000201e:	16fb2623          	sw	a5,364(s6)
        selected_proc->total_ticks = 0;
    80002022:	160b2823          	sw	zero,368(s6)
      c->proc = 0;
    80002026:	020d3823          	sd	zero,48(s10)
      release(&selected_proc->lock);
    8000202a:	854a                	mv	a0,s2
    8000202c:	fffff097          	auipc	ra,0xfffff
    80002030:	c5c080e7          	jalr	-932(ra) # 80000c88 <release>
    80002034:	bf15                	j	80001f68 <scheduler+0xba>

0000000080002036 <sched>:
{
    80002036:	7179                	addi	sp,sp,-48
    80002038:	f406                	sd	ra,40(sp)
    8000203a:	f022                	sd	s0,32(sp)
    8000203c:	ec26                	sd	s1,24(sp)
    8000203e:	e84a                	sd	s2,16(sp)
    80002040:	e44e                	sd	s3,8(sp)
    80002042:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80002044:	00000097          	auipc	ra,0x0
    80002048:	966080e7          	jalr	-1690(ra) # 800019aa <myproc>
    8000204c:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    8000204e:	fffff097          	auipc	ra,0xfffff
    80002052:	b0c080e7          	jalr	-1268(ra) # 80000b5a <holding>
    80002056:	c93d                	beqz	a0,800020cc <sched+0x96>
  asm volatile("mv %0, tp" : "=r" (x) );
    80002058:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    8000205a:	2781                	sext.w	a5,a5
    8000205c:	079e                	slli	a5,a5,0x7
    8000205e:	0000f717          	auipc	a4,0xf
    80002062:	af270713          	addi	a4,a4,-1294 # 80010b50 <pid_lock>
    80002066:	97ba                	add	a5,a5,a4
    80002068:	0a87a703          	lw	a4,168(a5)
    8000206c:	4785                	li	a5,1
    8000206e:	06f71763          	bne	a4,a5,800020dc <sched+0xa6>
  if(p->state == RUNNING)
    80002072:	4c98                	lw	a4,24(s1)
    80002074:	4791                	li	a5,4
    80002076:	06f70b63          	beq	a4,a5,800020ec <sched+0xb6>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000207a:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000207e:	8b89                	andi	a5,a5,2
  if(intr_get())
    80002080:	efb5                	bnez	a5,800020fc <sched+0xc6>
  asm volatile("mv %0, tp" : "=r" (x) );
    80002082:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80002084:	0000f917          	auipc	s2,0xf
    80002088:	acc90913          	addi	s2,s2,-1332 # 80010b50 <pid_lock>
    8000208c:	2781                	sext.w	a5,a5
    8000208e:	079e                	slli	a5,a5,0x7
    80002090:	97ca                	add	a5,a5,s2
    80002092:	0ac7a983          	lw	s3,172(a5)
    80002096:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80002098:	2781                	sext.w	a5,a5
    8000209a:	079e                	slli	a5,a5,0x7
    8000209c:	0000f597          	auipc	a1,0xf
    800020a0:	aec58593          	addi	a1,a1,-1300 # 80010b88 <cpus+0x8>
    800020a4:	95be                	add	a1,a1,a5
    800020a6:	06048513          	addi	a0,s1,96
    800020aa:	00000097          	auipc	ra,0x0
    800020ae:	624080e7          	jalr	1572(ra) # 800026ce <swtch>
    800020b2:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    800020b4:	2781                	sext.w	a5,a5
    800020b6:	079e                	slli	a5,a5,0x7
    800020b8:	993e                	add	s2,s2,a5
    800020ba:	0b392623          	sw	s3,172(s2)
}
    800020be:	70a2                	ld	ra,40(sp)
    800020c0:	7402                	ld	s0,32(sp)
    800020c2:	64e2                	ld	s1,24(sp)
    800020c4:	6942                	ld	s2,16(sp)
    800020c6:	69a2                	ld	s3,8(sp)
    800020c8:	6145                	addi	sp,sp,48
    800020ca:	8082                	ret
    panic("sched p->lock");
    800020cc:	00006517          	auipc	a0,0x6
    800020d0:	14c50513          	addi	a0,a0,332 # 80008218 <digits+0x1d8>
    800020d4:	ffffe097          	auipc	ra,0xffffe
    800020d8:	46a080e7          	jalr	1130(ra) # 8000053e <panic>
    panic("sched locks");
    800020dc:	00006517          	auipc	a0,0x6
    800020e0:	14c50513          	addi	a0,a0,332 # 80008228 <digits+0x1e8>
    800020e4:	ffffe097          	auipc	ra,0xffffe
    800020e8:	45a080e7          	jalr	1114(ra) # 8000053e <panic>
    panic("sched running");
    800020ec:	00006517          	auipc	a0,0x6
    800020f0:	14c50513          	addi	a0,a0,332 # 80008238 <digits+0x1f8>
    800020f4:	ffffe097          	auipc	ra,0xffffe
    800020f8:	44a080e7          	jalr	1098(ra) # 8000053e <panic>
    panic("sched interruptible");
    800020fc:	00006517          	auipc	a0,0x6
    80002100:	14c50513          	addi	a0,a0,332 # 80008248 <digits+0x208>
    80002104:	ffffe097          	auipc	ra,0xffffe
    80002108:	43a080e7          	jalr	1082(ra) # 8000053e <panic>

000000008000210c <yield>:
{
    8000210c:	1101                	addi	sp,sp,-32
    8000210e:	ec06                	sd	ra,24(sp)
    80002110:	e822                	sd	s0,16(sp)
    80002112:	e426                	sd	s1,8(sp)
    80002114:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80002116:	00000097          	auipc	ra,0x0
    8000211a:	894080e7          	jalr	-1900(ra) # 800019aa <myproc>
    8000211e:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80002120:	fffff097          	auipc	ra,0xfffff
    80002124:	ab4080e7          	jalr	-1356(ra) # 80000bd4 <acquire>
  p->state = RUNNABLE;
    80002128:	478d                	li	a5,3
    8000212a:	cc9c                	sw	a5,24(s1)
    if(p->queue_level > 0) {
    8000212c:	16c4a783          	lw	a5,364(s1)
    80002130:	00f05563          	blez	a5,8000213a <yield+0x2e>
    p->queue_level--; // Decrement priority
    80002134:	37fd                	addiw	a5,a5,-1
    80002136:	16f4a623          	sw	a5,364(s1)
  sched();
    8000213a:	00000097          	auipc	ra,0x0
    8000213e:	efc080e7          	jalr	-260(ra) # 80002036 <sched>
  release(&p->lock);
    80002142:	8526                	mv	a0,s1
    80002144:	fffff097          	auipc	ra,0xfffff
    80002148:	b44080e7          	jalr	-1212(ra) # 80000c88 <release>
}
    8000214c:	60e2                	ld	ra,24(sp)
    8000214e:	6442                	ld	s0,16(sp)
    80002150:	64a2                	ld	s1,8(sp)
    80002152:	6105                	addi	sp,sp,32
    80002154:	8082                	ret

0000000080002156 <sleep>:

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80002156:	7179                	addi	sp,sp,-48
    80002158:	f406                	sd	ra,40(sp)
    8000215a:	f022                	sd	s0,32(sp)
    8000215c:	ec26                	sd	s1,24(sp)
    8000215e:	e84a                	sd	s2,16(sp)
    80002160:	e44e                	sd	s3,8(sp)
    80002162:	1800                	addi	s0,sp,48
    80002164:	89aa                	mv	s3,a0
    80002166:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002168:	00000097          	auipc	ra,0x0
    8000216c:	842080e7          	jalr	-1982(ra) # 800019aa <myproc>
    80002170:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80002172:	fffff097          	auipc	ra,0xfffff
    80002176:	a62080e7          	jalr	-1438(ra) # 80000bd4 <acquire>
  release(lk);
    8000217a:	854a                	mv	a0,s2
    8000217c:	fffff097          	auipc	ra,0xfffff
    80002180:	b0c080e7          	jalr	-1268(ra) # 80000c88 <release>

  // Go to sleep.
  p->chan = chan;
    80002184:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    80002188:	4789                	li	a5,2
    8000218a:	cc9c                	sw	a5,24(s1)
  if(p->queue_level < 2) {
    8000218c:	16c4a783          	lw	a5,364(s1)
    80002190:	4705                	li	a4,1
    80002192:	02f75963          	bge	a4,a5,800021c4 <sleep+0x6e>
    p->queue_level++; // Increment priority
  }

  sched();
    80002196:	00000097          	auipc	ra,0x0
    8000219a:	ea0080e7          	jalr	-352(ra) # 80002036 <sched>

  // Tidy up.
  p->chan = 0;
    8000219e:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    800021a2:	8526                	mv	a0,s1
    800021a4:	fffff097          	auipc	ra,0xfffff
    800021a8:	ae4080e7          	jalr	-1308(ra) # 80000c88 <release>
  acquire(lk);
    800021ac:	854a                	mv	a0,s2
    800021ae:	fffff097          	auipc	ra,0xfffff
    800021b2:	a26080e7          	jalr	-1498(ra) # 80000bd4 <acquire>
}
    800021b6:	70a2                	ld	ra,40(sp)
    800021b8:	7402                	ld	s0,32(sp)
    800021ba:	64e2                	ld	s1,24(sp)
    800021bc:	6942                	ld	s2,16(sp)
    800021be:	69a2                	ld	s3,8(sp)
    800021c0:	6145                	addi	sp,sp,48
    800021c2:	8082                	ret
    p->queue_level++; // Increment priority
    800021c4:	2785                	addiw	a5,a5,1
    800021c6:	16f4a623          	sw	a5,364(s1)
    800021ca:	b7f1                	j	80002196 <sleep+0x40>

00000000800021cc <wakeup>:

// Wake up all processes sleeping on chan.
// Must be called without any p->lock.
void
wakeup(void *chan)
{
    800021cc:	7139                	addi	sp,sp,-64
    800021ce:	fc06                	sd	ra,56(sp)
    800021d0:	f822                	sd	s0,48(sp)
    800021d2:	f426                	sd	s1,40(sp)
    800021d4:	f04a                	sd	s2,32(sp)
    800021d6:	ec4e                	sd	s3,24(sp)
    800021d8:	e852                	sd	s4,16(sp)
    800021da:	e456                	sd	s5,8(sp)
    800021dc:	0080                	addi	s0,sp,64
    800021de:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    800021e0:	0000f497          	auipc	s1,0xf
    800021e4:	da048493          	addi	s1,s1,-608 # 80010f80 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    800021e8:	4989                	li	s3,2
        p->state = RUNNABLE;
    800021ea:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    800021ec:	00015917          	auipc	s2,0x15
    800021f0:	b9490913          	addi	s2,s2,-1132 # 80016d80 <tickslock>
    800021f4:	a811                	j	80002208 <wakeup+0x3c>
      }
      release(&p->lock);
    800021f6:	8526                	mv	a0,s1
    800021f8:	fffff097          	auipc	ra,0xfffff
    800021fc:	a90080e7          	jalr	-1392(ra) # 80000c88 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80002200:	17848493          	addi	s1,s1,376
    80002204:	03248663          	beq	s1,s2,80002230 <wakeup+0x64>
    if(p != myproc()){
    80002208:	fffff097          	auipc	ra,0xfffff
    8000220c:	7a2080e7          	jalr	1954(ra) # 800019aa <myproc>
    80002210:	fea488e3          	beq	s1,a0,80002200 <wakeup+0x34>
      acquire(&p->lock);
    80002214:	8526                	mv	a0,s1
    80002216:	fffff097          	auipc	ra,0xfffff
    8000221a:	9be080e7          	jalr	-1602(ra) # 80000bd4 <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    8000221e:	4c9c                	lw	a5,24(s1)
    80002220:	fd379be3          	bne	a5,s3,800021f6 <wakeup+0x2a>
    80002224:	709c                	ld	a5,32(s1)
    80002226:	fd4798e3          	bne	a5,s4,800021f6 <wakeup+0x2a>
        p->state = RUNNABLE;
    8000222a:	0154ac23          	sw	s5,24(s1)
    8000222e:	b7e1                	j	800021f6 <wakeup+0x2a>
    }
  }
}
    80002230:	70e2                	ld	ra,56(sp)
    80002232:	7442                	ld	s0,48(sp)
    80002234:	74a2                	ld	s1,40(sp)
    80002236:	7902                	ld	s2,32(sp)
    80002238:	69e2                	ld	s3,24(sp)
    8000223a:	6a42                	ld	s4,16(sp)
    8000223c:	6aa2                	ld	s5,8(sp)
    8000223e:	6121                	addi	sp,sp,64
    80002240:	8082                	ret

0000000080002242 <reparent>:
{
    80002242:	7179                	addi	sp,sp,-48
    80002244:	f406                	sd	ra,40(sp)
    80002246:	f022                	sd	s0,32(sp)
    80002248:	ec26                	sd	s1,24(sp)
    8000224a:	e84a                	sd	s2,16(sp)
    8000224c:	e44e                	sd	s3,8(sp)
    8000224e:	e052                	sd	s4,0(sp)
    80002250:	1800                	addi	s0,sp,48
    80002252:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80002254:	0000f497          	auipc	s1,0xf
    80002258:	d2c48493          	addi	s1,s1,-724 # 80010f80 <proc>
      pp->parent = initproc;
    8000225c:	00006a17          	auipc	s4,0x6
    80002260:	67ca0a13          	addi	s4,s4,1660 # 800088d8 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80002264:	00015997          	auipc	s3,0x15
    80002268:	b1c98993          	addi	s3,s3,-1252 # 80016d80 <tickslock>
    8000226c:	a029                	j	80002276 <reparent+0x34>
    8000226e:	17848493          	addi	s1,s1,376
    80002272:	01348d63          	beq	s1,s3,8000228c <reparent+0x4a>
    if(pp->parent == p){
    80002276:	7c9c                	ld	a5,56(s1)
    80002278:	ff279be3          	bne	a5,s2,8000226e <reparent+0x2c>
      pp->parent = initproc;
    8000227c:	000a3503          	ld	a0,0(s4)
    80002280:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80002282:	00000097          	auipc	ra,0x0
    80002286:	f4a080e7          	jalr	-182(ra) # 800021cc <wakeup>
    8000228a:	b7d5                	j	8000226e <reparent+0x2c>
}
    8000228c:	70a2                	ld	ra,40(sp)
    8000228e:	7402                	ld	s0,32(sp)
    80002290:	64e2                	ld	s1,24(sp)
    80002292:	6942                	ld	s2,16(sp)
    80002294:	69a2                	ld	s3,8(sp)
    80002296:	6a02                	ld	s4,0(sp)
    80002298:	6145                	addi	sp,sp,48
    8000229a:	8082                	ret

000000008000229c <exit>:
{
    8000229c:	7179                	addi	sp,sp,-48
    8000229e:	f406                	sd	ra,40(sp)
    800022a0:	f022                	sd	s0,32(sp)
    800022a2:	ec26                	sd	s1,24(sp)
    800022a4:	e84a                	sd	s2,16(sp)
    800022a6:	e44e                	sd	s3,8(sp)
    800022a8:	e052                	sd	s4,0(sp)
    800022aa:	1800                	addi	s0,sp,48
    800022ac:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    800022ae:	fffff097          	auipc	ra,0xfffff
    800022b2:	6fc080e7          	jalr	1788(ra) # 800019aa <myproc>
    800022b6:	89aa                	mv	s3,a0
  if(p == initproc)
    800022b8:	00006797          	auipc	a5,0x6
    800022bc:	6207b783          	ld	a5,1568(a5) # 800088d8 <initproc>
    800022c0:	0d050493          	addi	s1,a0,208
    800022c4:	15050913          	addi	s2,a0,336
    800022c8:	02a79363          	bne	a5,a0,800022ee <exit+0x52>
    panic("init exiting");
    800022cc:	00006517          	auipc	a0,0x6
    800022d0:	f9450513          	addi	a0,a0,-108 # 80008260 <digits+0x220>
    800022d4:	ffffe097          	auipc	ra,0xffffe
    800022d8:	26a080e7          	jalr	618(ra) # 8000053e <panic>
      fileclose(f);
    800022dc:	00002097          	auipc	ra,0x2
    800022e0:	2fa080e7          	jalr	762(ra) # 800045d6 <fileclose>
      p->ofile[fd] = 0;
    800022e4:	0004b023          	sd	zero,0(s1)
  for(int fd = 0; fd < NOFILE; fd++){
    800022e8:	04a1                	addi	s1,s1,8
    800022ea:	01248563          	beq	s1,s2,800022f4 <exit+0x58>
    if(p->ofile[fd]){
    800022ee:	6088                	ld	a0,0(s1)
    800022f0:	f575                	bnez	a0,800022dc <exit+0x40>
    800022f2:	bfdd                	j	800022e8 <exit+0x4c>
  begin_op();
    800022f4:	00002097          	auipc	ra,0x2
    800022f8:	e1a080e7          	jalr	-486(ra) # 8000410e <begin_op>
  iput(p->cwd);
    800022fc:	1509b503          	ld	a0,336(s3)
    80002300:	00001097          	auipc	ra,0x1
    80002304:	5fc080e7          	jalr	1532(ra) # 800038fc <iput>
  end_op();
    80002308:	00002097          	auipc	ra,0x2
    8000230c:	e84080e7          	jalr	-380(ra) # 8000418c <end_op>
  p->cwd = 0;
    80002310:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    80002314:	0000f497          	auipc	s1,0xf
    80002318:	85448493          	addi	s1,s1,-1964 # 80010b68 <wait_lock>
    8000231c:	8526                	mv	a0,s1
    8000231e:	fffff097          	auipc	ra,0xfffff
    80002322:	8b6080e7          	jalr	-1866(ra) # 80000bd4 <acquire>
  reparent(p);
    80002326:	854e                	mv	a0,s3
    80002328:	00000097          	auipc	ra,0x0
    8000232c:	f1a080e7          	jalr	-230(ra) # 80002242 <reparent>
  wakeup(p->parent);
    80002330:	0389b503          	ld	a0,56(s3)
    80002334:	00000097          	auipc	ra,0x0
    80002338:	e98080e7          	jalr	-360(ra) # 800021cc <wakeup>
  acquire(&p->lock);
    8000233c:	854e                	mv	a0,s3
    8000233e:	fffff097          	auipc	ra,0xfffff
    80002342:	896080e7          	jalr	-1898(ra) # 80000bd4 <acquire>
  p->xstate = status;
    80002346:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    8000234a:	4795                	li	a5,5
    8000234c:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    80002350:	8526                	mv	a0,s1
    80002352:	fffff097          	auipc	ra,0xfffff
    80002356:	936080e7          	jalr	-1738(ra) # 80000c88 <release>
  sched();
    8000235a:	00000097          	auipc	ra,0x0
    8000235e:	cdc080e7          	jalr	-804(ra) # 80002036 <sched>
  panic("zombie exit");
    80002362:	00006517          	auipc	a0,0x6
    80002366:	f0e50513          	addi	a0,a0,-242 # 80008270 <digits+0x230>
    8000236a:	ffffe097          	auipc	ra,0xffffe
    8000236e:	1d4080e7          	jalr	468(ra) # 8000053e <panic>

0000000080002372 <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    80002372:	7179                	addi	sp,sp,-48
    80002374:	f406                	sd	ra,40(sp)
    80002376:	f022                	sd	s0,32(sp)
    80002378:	ec26                	sd	s1,24(sp)
    8000237a:	e84a                	sd	s2,16(sp)
    8000237c:	e44e                	sd	s3,8(sp)
    8000237e:	1800                	addi	s0,sp,48
    80002380:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    80002382:	0000f497          	auipc	s1,0xf
    80002386:	bfe48493          	addi	s1,s1,-1026 # 80010f80 <proc>
    8000238a:	00015997          	auipc	s3,0x15
    8000238e:	9f698993          	addi	s3,s3,-1546 # 80016d80 <tickslock>
    acquire(&p->lock);
    80002392:	8526                	mv	a0,s1
    80002394:	fffff097          	auipc	ra,0xfffff
    80002398:	840080e7          	jalr	-1984(ra) # 80000bd4 <acquire>
    if(p->pid == pid){
    8000239c:	589c                	lw	a5,48(s1)
    8000239e:	01278d63          	beq	a5,s2,800023b8 <kill+0x46>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    800023a2:	8526                	mv	a0,s1
    800023a4:	fffff097          	auipc	ra,0xfffff
    800023a8:	8e4080e7          	jalr	-1820(ra) # 80000c88 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    800023ac:	17848493          	addi	s1,s1,376
    800023b0:	ff3491e3          	bne	s1,s3,80002392 <kill+0x20>
  }
  return -1;
    800023b4:	557d                	li	a0,-1
    800023b6:	a829                	j	800023d0 <kill+0x5e>
      p->killed = 1;
    800023b8:	4785                	li	a5,1
    800023ba:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    800023bc:	4c98                	lw	a4,24(s1)
    800023be:	4789                	li	a5,2
    800023c0:	00f70f63          	beq	a4,a5,800023de <kill+0x6c>
      release(&p->lock);
    800023c4:	8526                	mv	a0,s1
    800023c6:	fffff097          	auipc	ra,0xfffff
    800023ca:	8c2080e7          	jalr	-1854(ra) # 80000c88 <release>
      return 0;
    800023ce:	4501                	li	a0,0
}
    800023d0:	70a2                	ld	ra,40(sp)
    800023d2:	7402                	ld	s0,32(sp)
    800023d4:	64e2                	ld	s1,24(sp)
    800023d6:	6942                	ld	s2,16(sp)
    800023d8:	69a2                	ld	s3,8(sp)
    800023da:	6145                	addi	sp,sp,48
    800023dc:	8082                	ret
        p->state = RUNNABLE;
    800023de:	478d                	li	a5,3
    800023e0:	cc9c                	sw	a5,24(s1)
    800023e2:	b7cd                	j	800023c4 <kill+0x52>

00000000800023e4 <setkilled>:

void
setkilled(struct proc *p)
{
    800023e4:	1101                	addi	sp,sp,-32
    800023e6:	ec06                	sd	ra,24(sp)
    800023e8:	e822                	sd	s0,16(sp)
    800023ea:	e426                	sd	s1,8(sp)
    800023ec:	1000                	addi	s0,sp,32
    800023ee:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800023f0:	ffffe097          	auipc	ra,0xffffe
    800023f4:	7e4080e7          	jalr	2020(ra) # 80000bd4 <acquire>
  p->killed = 1;
    800023f8:	4785                	li	a5,1
    800023fa:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    800023fc:	8526                	mv	a0,s1
    800023fe:	fffff097          	auipc	ra,0xfffff
    80002402:	88a080e7          	jalr	-1910(ra) # 80000c88 <release>
}
    80002406:	60e2                	ld	ra,24(sp)
    80002408:	6442                	ld	s0,16(sp)
    8000240a:	64a2                	ld	s1,8(sp)
    8000240c:	6105                	addi	sp,sp,32
    8000240e:	8082                	ret

0000000080002410 <killed>:

int
killed(struct proc *p)
{
    80002410:	1101                	addi	sp,sp,-32
    80002412:	ec06                	sd	ra,24(sp)
    80002414:	e822                	sd	s0,16(sp)
    80002416:	e426                	sd	s1,8(sp)
    80002418:	e04a                	sd	s2,0(sp)
    8000241a:	1000                	addi	s0,sp,32
    8000241c:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    8000241e:	ffffe097          	auipc	ra,0xffffe
    80002422:	7b6080e7          	jalr	1974(ra) # 80000bd4 <acquire>
  k = p->killed;
    80002426:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    8000242a:	8526                	mv	a0,s1
    8000242c:	fffff097          	auipc	ra,0xfffff
    80002430:	85c080e7          	jalr	-1956(ra) # 80000c88 <release>
  return k;
}
    80002434:	854a                	mv	a0,s2
    80002436:	60e2                	ld	ra,24(sp)
    80002438:	6442                	ld	s0,16(sp)
    8000243a:	64a2                	ld	s1,8(sp)
    8000243c:	6902                	ld	s2,0(sp)
    8000243e:	6105                	addi	sp,sp,32
    80002440:	8082                	ret

0000000080002442 <wait>:
{
    80002442:	715d                	addi	sp,sp,-80
    80002444:	e486                	sd	ra,72(sp)
    80002446:	e0a2                	sd	s0,64(sp)
    80002448:	fc26                	sd	s1,56(sp)
    8000244a:	f84a                	sd	s2,48(sp)
    8000244c:	f44e                	sd	s3,40(sp)
    8000244e:	f052                	sd	s4,32(sp)
    80002450:	ec56                	sd	s5,24(sp)
    80002452:	e85a                	sd	s6,16(sp)
    80002454:	e45e                	sd	s7,8(sp)
    80002456:	e062                	sd	s8,0(sp)
    80002458:	0880                	addi	s0,sp,80
    8000245a:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    8000245c:	fffff097          	auipc	ra,0xfffff
    80002460:	54e080e7          	jalr	1358(ra) # 800019aa <myproc>
    80002464:	892a                	mv	s2,a0
  acquire(&wait_lock);
    80002466:	0000e517          	auipc	a0,0xe
    8000246a:	70250513          	addi	a0,a0,1794 # 80010b68 <wait_lock>
    8000246e:	ffffe097          	auipc	ra,0xffffe
    80002472:	766080e7          	jalr	1894(ra) # 80000bd4 <acquire>
    havekids = 0;
    80002476:	4b81                	li	s7,0
        if(pp->state == ZOMBIE){
    80002478:	4a15                	li	s4,5
        havekids = 1;
    8000247a:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000247c:	00015997          	auipc	s3,0x15
    80002480:	90498993          	addi	s3,s3,-1788 # 80016d80 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002484:	0000ec17          	auipc	s8,0xe
    80002488:	6e4c0c13          	addi	s8,s8,1764 # 80010b68 <wait_lock>
    havekids = 0;
    8000248c:	875e                	mv	a4,s7
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000248e:	0000f497          	auipc	s1,0xf
    80002492:	af248493          	addi	s1,s1,-1294 # 80010f80 <proc>
    80002496:	a0bd                	j	80002504 <wait+0xc2>
          pid = pp->pid;
    80002498:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    8000249c:	000b0e63          	beqz	s6,800024b8 <wait+0x76>
    800024a0:	4691                	li	a3,4
    800024a2:	02c48613          	addi	a2,s1,44
    800024a6:	85da                	mv	a1,s6
    800024a8:	05093503          	ld	a0,80(s2)
    800024ac:	fffff097          	auipc	ra,0xfffff
    800024b0:	1be080e7          	jalr	446(ra) # 8000166a <copyout>
    800024b4:	02054563          	bltz	a0,800024de <wait+0x9c>
          freeproc(pp);
    800024b8:	8526                	mv	a0,s1
    800024ba:	fffff097          	auipc	ra,0xfffff
    800024be:	6a2080e7          	jalr	1698(ra) # 80001b5c <freeproc>
          release(&pp->lock);
    800024c2:	8526                	mv	a0,s1
    800024c4:	ffffe097          	auipc	ra,0xffffe
    800024c8:	7c4080e7          	jalr	1988(ra) # 80000c88 <release>
          release(&wait_lock);
    800024cc:	0000e517          	auipc	a0,0xe
    800024d0:	69c50513          	addi	a0,a0,1692 # 80010b68 <wait_lock>
    800024d4:	ffffe097          	auipc	ra,0xffffe
    800024d8:	7b4080e7          	jalr	1972(ra) # 80000c88 <release>
          return pid;
    800024dc:	a0b5                	j	80002548 <wait+0x106>
            release(&pp->lock);
    800024de:	8526                	mv	a0,s1
    800024e0:	ffffe097          	auipc	ra,0xffffe
    800024e4:	7a8080e7          	jalr	1960(ra) # 80000c88 <release>
            release(&wait_lock);
    800024e8:	0000e517          	auipc	a0,0xe
    800024ec:	68050513          	addi	a0,a0,1664 # 80010b68 <wait_lock>
    800024f0:	ffffe097          	auipc	ra,0xffffe
    800024f4:	798080e7          	jalr	1944(ra) # 80000c88 <release>
            return -1;
    800024f8:	59fd                	li	s3,-1
    800024fa:	a0b9                	j	80002548 <wait+0x106>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800024fc:	17848493          	addi	s1,s1,376
    80002500:	03348463          	beq	s1,s3,80002528 <wait+0xe6>
      if(pp->parent == p){
    80002504:	7c9c                	ld	a5,56(s1)
    80002506:	ff279be3          	bne	a5,s2,800024fc <wait+0xba>
        acquire(&pp->lock);
    8000250a:	8526                	mv	a0,s1
    8000250c:	ffffe097          	auipc	ra,0xffffe
    80002510:	6c8080e7          	jalr	1736(ra) # 80000bd4 <acquire>
        if(pp->state == ZOMBIE){
    80002514:	4c9c                	lw	a5,24(s1)
    80002516:	f94781e3          	beq	a5,s4,80002498 <wait+0x56>
        release(&pp->lock);
    8000251a:	8526                	mv	a0,s1
    8000251c:	ffffe097          	auipc	ra,0xffffe
    80002520:	76c080e7          	jalr	1900(ra) # 80000c88 <release>
        havekids = 1;
    80002524:	8756                	mv	a4,s5
    80002526:	bfd9                	j	800024fc <wait+0xba>
    if(!havekids || killed(p)){
    80002528:	c719                	beqz	a4,80002536 <wait+0xf4>
    8000252a:	854a                	mv	a0,s2
    8000252c:	00000097          	auipc	ra,0x0
    80002530:	ee4080e7          	jalr	-284(ra) # 80002410 <killed>
    80002534:	c51d                	beqz	a0,80002562 <wait+0x120>
      release(&wait_lock);
    80002536:	0000e517          	auipc	a0,0xe
    8000253a:	63250513          	addi	a0,a0,1586 # 80010b68 <wait_lock>
    8000253e:	ffffe097          	auipc	ra,0xffffe
    80002542:	74a080e7          	jalr	1866(ra) # 80000c88 <release>
      return -1;
    80002546:	59fd                	li	s3,-1
}
    80002548:	854e                	mv	a0,s3
    8000254a:	60a6                	ld	ra,72(sp)
    8000254c:	6406                	ld	s0,64(sp)
    8000254e:	74e2                	ld	s1,56(sp)
    80002550:	7942                	ld	s2,48(sp)
    80002552:	79a2                	ld	s3,40(sp)
    80002554:	7a02                	ld	s4,32(sp)
    80002556:	6ae2                	ld	s5,24(sp)
    80002558:	6b42                	ld	s6,16(sp)
    8000255a:	6ba2                	ld	s7,8(sp)
    8000255c:	6c02                	ld	s8,0(sp)
    8000255e:	6161                	addi	sp,sp,80
    80002560:	8082                	ret
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002562:	85e2                	mv	a1,s8
    80002564:	854a                	mv	a0,s2
    80002566:	00000097          	auipc	ra,0x0
    8000256a:	bf0080e7          	jalr	-1040(ra) # 80002156 <sleep>
    havekids = 0;
    8000256e:	bf39                	j	8000248c <wait+0x4a>

0000000080002570 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    80002570:	7179                	addi	sp,sp,-48
    80002572:	f406                	sd	ra,40(sp)
    80002574:	f022                	sd	s0,32(sp)
    80002576:	ec26                	sd	s1,24(sp)
    80002578:	e84a                	sd	s2,16(sp)
    8000257a:	e44e                	sd	s3,8(sp)
    8000257c:	e052                	sd	s4,0(sp)
    8000257e:	1800                	addi	s0,sp,48
    80002580:	84aa                	mv	s1,a0
    80002582:	892e                	mv	s2,a1
    80002584:	89b2                	mv	s3,a2
    80002586:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    80002588:	fffff097          	auipc	ra,0xfffff
    8000258c:	422080e7          	jalr	1058(ra) # 800019aa <myproc>
  if(user_dst){
    80002590:	c08d                	beqz	s1,800025b2 <either_copyout+0x42>
    return copyout(p->pagetable, dst, src, len);
    80002592:	86d2                	mv	a3,s4
    80002594:	864e                	mv	a2,s3
    80002596:	85ca                	mv	a1,s2
    80002598:	6928                	ld	a0,80(a0)
    8000259a:	fffff097          	auipc	ra,0xfffff
    8000259e:	0d0080e7          	jalr	208(ra) # 8000166a <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    800025a2:	70a2                	ld	ra,40(sp)
    800025a4:	7402                	ld	s0,32(sp)
    800025a6:	64e2                	ld	s1,24(sp)
    800025a8:	6942                	ld	s2,16(sp)
    800025aa:	69a2                	ld	s3,8(sp)
    800025ac:	6a02                	ld	s4,0(sp)
    800025ae:	6145                	addi	sp,sp,48
    800025b0:	8082                	ret
    memmove((char *)dst, src, len);
    800025b2:	000a061b          	sext.w	a2,s4
    800025b6:	85ce                	mv	a1,s3
    800025b8:	854a                	mv	a0,s2
    800025ba:	ffffe097          	auipc	ra,0xffffe
    800025be:	772080e7          	jalr	1906(ra) # 80000d2c <memmove>
    return 0;
    800025c2:	8526                	mv	a0,s1
    800025c4:	bff9                	j	800025a2 <either_copyout+0x32>

00000000800025c6 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    800025c6:	7179                	addi	sp,sp,-48
    800025c8:	f406                	sd	ra,40(sp)
    800025ca:	f022                	sd	s0,32(sp)
    800025cc:	ec26                	sd	s1,24(sp)
    800025ce:	e84a                	sd	s2,16(sp)
    800025d0:	e44e                	sd	s3,8(sp)
    800025d2:	e052                	sd	s4,0(sp)
    800025d4:	1800                	addi	s0,sp,48
    800025d6:	892a                	mv	s2,a0
    800025d8:	84ae                	mv	s1,a1
    800025da:	89b2                	mv	s3,a2
    800025dc:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    800025de:	fffff097          	auipc	ra,0xfffff
    800025e2:	3cc080e7          	jalr	972(ra) # 800019aa <myproc>
  if(user_src){
    800025e6:	c08d                	beqz	s1,80002608 <either_copyin+0x42>
    return copyin(p->pagetable, dst, src, len);
    800025e8:	86d2                	mv	a3,s4
    800025ea:	864e                	mv	a2,s3
    800025ec:	85ca                	mv	a1,s2
    800025ee:	6928                	ld	a0,80(a0)
    800025f0:	fffff097          	auipc	ra,0xfffff
    800025f4:	106080e7          	jalr	262(ra) # 800016f6 <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    800025f8:	70a2                	ld	ra,40(sp)
    800025fa:	7402                	ld	s0,32(sp)
    800025fc:	64e2                	ld	s1,24(sp)
    800025fe:	6942                	ld	s2,16(sp)
    80002600:	69a2                	ld	s3,8(sp)
    80002602:	6a02                	ld	s4,0(sp)
    80002604:	6145                	addi	sp,sp,48
    80002606:	8082                	ret
    memmove(dst, (char*)src, len);
    80002608:	000a061b          	sext.w	a2,s4
    8000260c:	85ce                	mv	a1,s3
    8000260e:	854a                	mv	a0,s2
    80002610:	ffffe097          	auipc	ra,0xffffe
    80002614:	71c080e7          	jalr	1820(ra) # 80000d2c <memmove>
    return 0;
    80002618:	8526                	mv	a0,s1
    8000261a:	bff9                	j	800025f8 <either_copyin+0x32>

000000008000261c <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    8000261c:	715d                	addi	sp,sp,-80
    8000261e:	e486                	sd	ra,72(sp)
    80002620:	e0a2                	sd	s0,64(sp)
    80002622:	fc26                	sd	s1,56(sp)
    80002624:	f84a                	sd	s2,48(sp)
    80002626:	f44e                	sd	s3,40(sp)
    80002628:	f052                	sd	s4,32(sp)
    8000262a:	ec56                	sd	s5,24(sp)
    8000262c:	e85a                	sd	s6,16(sp)
    8000262e:	e45e                	sd	s7,8(sp)
    80002630:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    80002632:	00006517          	auipc	a0,0x6
    80002636:	a9650513          	addi	a0,a0,-1386 # 800080c8 <digits+0x88>
    8000263a:	ffffe097          	auipc	ra,0xffffe
    8000263e:	f4e080e7          	jalr	-178(ra) # 80000588 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002642:	0000f497          	auipc	s1,0xf
    80002646:	a9648493          	addi	s1,s1,-1386 # 800110d8 <proc+0x158>
    8000264a:	00015917          	auipc	s2,0x15
    8000264e:	88e90913          	addi	s2,s2,-1906 # 80016ed8 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002652:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    80002654:	00006997          	auipc	s3,0x6
    80002658:	c2c98993          	addi	s3,s3,-980 # 80008280 <digits+0x240>
    printf("%d %s %s %d", p->pid, state, p->name, p->times_chosen);
    8000265c:	00006a97          	auipc	s5,0x6
    80002660:	c2ca8a93          	addi	s5,s5,-980 # 80008288 <digits+0x248>
    printf("\n");
    80002664:	00006a17          	auipc	s4,0x6
    80002668:	a64a0a13          	addi	s4,s4,-1436 # 800080c8 <digits+0x88>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000266c:	00006b97          	auipc	s7,0x6
    80002670:	c5cb8b93          	addi	s7,s7,-932 # 800082c8 <states.0>
    80002674:	a015                	j	80002698 <procdump+0x7c>
    printf("%d %s %s %d", p->pid, state, p->name, p->times_chosen);
    80002676:	4a98                	lw	a4,16(a3)
    80002678:	ed86a583          	lw	a1,-296(a3)
    8000267c:	8556                	mv	a0,s5
    8000267e:	ffffe097          	auipc	ra,0xffffe
    80002682:	f0a080e7          	jalr	-246(ra) # 80000588 <printf>
    printf("\n");
    80002686:	8552                	mv	a0,s4
    80002688:	ffffe097          	auipc	ra,0xffffe
    8000268c:	f00080e7          	jalr	-256(ra) # 80000588 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002690:	17848493          	addi	s1,s1,376
    80002694:	03248263          	beq	s1,s2,800026b8 <procdump+0x9c>
    if(p->state == UNUSED)
    80002698:	86a6                	mv	a3,s1
    8000269a:	ec04a783          	lw	a5,-320(s1)
    8000269e:	dbed                	beqz	a5,80002690 <procdump+0x74>
      state = "???";
    800026a0:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800026a2:	fcfb6ae3          	bltu	s6,a5,80002676 <procdump+0x5a>
    800026a6:	02079713          	slli	a4,a5,0x20
    800026aa:	01d75793          	srli	a5,a4,0x1d
    800026ae:	97de                	add	a5,a5,s7
    800026b0:	6390                	ld	a2,0(a5)
    800026b2:	f271                	bnez	a2,80002676 <procdump+0x5a>
      state = "???";
    800026b4:	864e                	mv	a2,s3
    800026b6:	b7c1                	j	80002676 <procdump+0x5a>
  }
}
    800026b8:	60a6                	ld	ra,72(sp)
    800026ba:	6406                	ld	s0,64(sp)
    800026bc:	74e2                	ld	s1,56(sp)
    800026be:	7942                	ld	s2,48(sp)
    800026c0:	79a2                	ld	s3,40(sp)
    800026c2:	7a02                	ld	s4,32(sp)
    800026c4:	6ae2                	ld	s5,24(sp)
    800026c6:	6b42                	ld	s6,16(sp)
    800026c8:	6ba2                	ld	s7,8(sp)
    800026ca:	6161                	addi	sp,sp,80
    800026cc:	8082                	ret

00000000800026ce <swtch>:
    800026ce:	00153023          	sd	ra,0(a0)
    800026d2:	00253423          	sd	sp,8(a0)
    800026d6:	e900                	sd	s0,16(a0)
    800026d8:	ed04                	sd	s1,24(a0)
    800026da:	03253023          	sd	s2,32(a0)
    800026de:	03353423          	sd	s3,40(a0)
    800026e2:	03453823          	sd	s4,48(a0)
    800026e6:	03553c23          	sd	s5,56(a0)
    800026ea:	05653023          	sd	s6,64(a0)
    800026ee:	05753423          	sd	s7,72(a0)
    800026f2:	05853823          	sd	s8,80(a0)
    800026f6:	05953c23          	sd	s9,88(a0)
    800026fa:	07a53023          	sd	s10,96(a0)
    800026fe:	07b53423          	sd	s11,104(a0)
    80002702:	0005b083          	ld	ra,0(a1)
    80002706:	0085b103          	ld	sp,8(a1)
    8000270a:	6980                	ld	s0,16(a1)
    8000270c:	6d84                	ld	s1,24(a1)
    8000270e:	0205b903          	ld	s2,32(a1)
    80002712:	0285b983          	ld	s3,40(a1)
    80002716:	0305ba03          	ld	s4,48(a1)
    8000271a:	0385ba83          	ld	s5,56(a1)
    8000271e:	0405bb03          	ld	s6,64(a1)
    80002722:	0485bb83          	ld	s7,72(a1)
    80002726:	0505bc03          	ld	s8,80(a1)
    8000272a:	0585bc83          	ld	s9,88(a1)
    8000272e:	0605bd03          	ld	s10,96(a1)
    80002732:	0685bd83          	ld	s11,104(a1)
    80002736:	8082                	ret

0000000080002738 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    80002738:	1141                	addi	sp,sp,-16
    8000273a:	e406                	sd	ra,8(sp)
    8000273c:	e022                	sd	s0,0(sp)
    8000273e:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80002740:	00006597          	auipc	a1,0x6
    80002744:	bb858593          	addi	a1,a1,-1096 # 800082f8 <states.0+0x30>
    80002748:	00014517          	auipc	a0,0x14
    8000274c:	63850513          	addi	a0,a0,1592 # 80016d80 <tickslock>
    80002750:	ffffe097          	auipc	ra,0xffffe
    80002754:	3f4080e7          	jalr	1012(ra) # 80000b44 <initlock>
}
    80002758:	60a2                	ld	ra,8(sp)
    8000275a:	6402                	ld	s0,0(sp)
    8000275c:	0141                	addi	sp,sp,16
    8000275e:	8082                	ret

0000000080002760 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80002760:	1141                	addi	sp,sp,-16
    80002762:	e422                	sd	s0,8(sp)
    80002764:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002766:	00003797          	auipc	a5,0x3
    8000276a:	4ca78793          	addi	a5,a5,1226 # 80005c30 <kernelvec>
    8000276e:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80002772:	6422                	ld	s0,8(sp)
    80002774:	0141                	addi	sp,sp,16
    80002776:	8082                	ret

0000000080002778 <usertrapret>:
//
// return to user space
//
void
usertrapret(void)
{
    80002778:	1141                	addi	sp,sp,-16
    8000277a:	e406                	sd	ra,8(sp)
    8000277c:	e022                	sd	s0,0(sp)
    8000277e:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80002780:	fffff097          	auipc	ra,0xfffff
    80002784:	22a080e7          	jalr	554(ra) # 800019aa <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002788:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    8000278c:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000278e:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80002792:	00005697          	auipc	a3,0x5
    80002796:	86e68693          	addi	a3,a3,-1938 # 80007000 <_trampoline>
    8000279a:	00005717          	auipc	a4,0x5
    8000279e:	86670713          	addi	a4,a4,-1946 # 80007000 <_trampoline>
    800027a2:	8f15                	sub	a4,a4,a3
    800027a4:	040007b7          	lui	a5,0x4000
    800027a8:	17fd                	addi	a5,a5,-1 # 3ffffff <_entry-0x7c000001>
    800027aa:	07b2                	slli	a5,a5,0xc
    800027ac:	973e                	add	a4,a4,a5
  asm volatile("csrw stvec, %0" : : "r" (x));
    800027ae:	10571073          	csrw	stvec,a4
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    800027b2:	6d38                	ld	a4,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    800027b4:	18002673          	csrr	a2,satp
    800027b8:	e310                	sd	a2,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    800027ba:	6d30                	ld	a2,88(a0)
    800027bc:	6138                	ld	a4,64(a0)
    800027be:	6585                	lui	a1,0x1
    800027c0:	972e                	add	a4,a4,a1
    800027c2:	e618                	sd	a4,8(a2)
  p->trapframe->kernel_trap = (uint64)usertrap;
    800027c4:	6d38                	ld	a4,88(a0)
    800027c6:	00000617          	auipc	a2,0x0
    800027ca:	13060613          	addi	a2,a2,304 # 800028f6 <usertrap>
    800027ce:	eb10                	sd	a2,16(a4)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    800027d0:	6d38                	ld	a4,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    800027d2:	8612                	mv	a2,tp
    800027d4:	f310                	sd	a2,32(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800027d6:	10002773          	csrr	a4,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    800027da:	eff77713          	andi	a4,a4,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    800027de:	02076713          	ori	a4,a4,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800027e2:	10071073          	csrw	sstatus,a4
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    800027e6:	6d38                	ld	a4,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    800027e8:	6f18                	ld	a4,24(a4)
    800027ea:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    800027ee:	6928                	ld	a0,80(a0)
    800027f0:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which 
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    800027f2:	00005717          	auipc	a4,0x5
    800027f6:	8aa70713          	addi	a4,a4,-1878 # 8000709c <userret>
    800027fa:	8f15                	sub	a4,a4,a3
    800027fc:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    800027fe:	577d                	li	a4,-1
    80002800:	177e                	slli	a4,a4,0x3f
    80002802:	8d59                	or	a0,a0,a4
    80002804:	9782                	jalr	a5
}
    80002806:	60a2                	ld	ra,8(sp)
    80002808:	6402                	ld	s0,0(sp)
    8000280a:	0141                	addi	sp,sp,16
    8000280c:	8082                	ret

000000008000280e <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    8000280e:	1101                	addi	sp,sp,-32
    80002810:	ec06                	sd	ra,24(sp)
    80002812:	e822                	sd	s0,16(sp)
    80002814:	e426                	sd	s1,8(sp)
    80002816:	1000                	addi	s0,sp,32
  acquire(&tickslock);
    80002818:	00014497          	auipc	s1,0x14
    8000281c:	56848493          	addi	s1,s1,1384 # 80016d80 <tickslock>
    80002820:	8526                	mv	a0,s1
    80002822:	ffffe097          	auipc	ra,0xffffe
    80002826:	3b2080e7          	jalr	946(ra) # 80000bd4 <acquire>
  ticks++;
    8000282a:	00006517          	auipc	a0,0x6
    8000282e:	0b650513          	addi	a0,a0,182 # 800088e0 <ticks>
    80002832:	411c                	lw	a5,0(a0)
    80002834:	2785                	addiw	a5,a5,1
    80002836:	c11c                	sw	a5,0(a0)
  wakeup(&ticks);
    80002838:	00000097          	auipc	ra,0x0
    8000283c:	994080e7          	jalr	-1644(ra) # 800021cc <wakeup>
  release(&tickslock);
    80002840:	8526                	mv	a0,s1
    80002842:	ffffe097          	auipc	ra,0xffffe
    80002846:	446080e7          	jalr	1094(ra) # 80000c88 <release>
}
    8000284a:	60e2                	ld	ra,24(sp)
    8000284c:	6442                	ld	s0,16(sp)
    8000284e:	64a2                	ld	s1,8(sp)
    80002850:	6105                	addi	sp,sp,32
    80002852:	8082                	ret

0000000080002854 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80002854:	1101                	addi	sp,sp,-32
    80002856:	ec06                	sd	ra,24(sp)
    80002858:	e822                	sd	s0,16(sp)
    8000285a:	e426                	sd	s1,8(sp)
    8000285c:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000285e:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if((scause & 0x8000000000000000L) &&
    80002862:	00074d63          	bltz	a4,8000287c <devintr+0x28>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000001L){
    80002866:	57fd                	li	a5,-1
    80002868:	17fe                	slli	a5,a5,0x3f
    8000286a:	0785                	addi	a5,a5,1
    // the SSIP bit in sip.
    w_sip(r_sip() & ~2);

    return 2;
  } else {
    return 0;
    8000286c:	4501                	li	a0,0
  } else if(scause == 0x8000000000000001L){
    8000286e:	06f70363          	beq	a4,a5,800028d4 <devintr+0x80>
  }
}
    80002872:	60e2                	ld	ra,24(sp)
    80002874:	6442                	ld	s0,16(sp)
    80002876:	64a2                	ld	s1,8(sp)
    80002878:	6105                	addi	sp,sp,32
    8000287a:	8082                	ret
     (scause & 0xff) == 9){
    8000287c:	0ff77793          	zext.b	a5,a4
  if((scause & 0x8000000000000000L) &&
    80002880:	46a5                	li	a3,9
    80002882:	fed792e3          	bne	a5,a3,80002866 <devintr+0x12>
    int irq = plic_claim();
    80002886:	00003097          	auipc	ra,0x3
    8000288a:	4b2080e7          	jalr	1202(ra) # 80005d38 <plic_claim>
    8000288e:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80002890:	47a9                	li	a5,10
    80002892:	02f50763          	beq	a0,a5,800028c0 <devintr+0x6c>
    } else if(irq == VIRTIO0_IRQ){
    80002896:	4785                	li	a5,1
    80002898:	02f50963          	beq	a0,a5,800028ca <devintr+0x76>
    return 1;
    8000289c:	4505                	li	a0,1
    } else if(irq){
    8000289e:	d8f1                	beqz	s1,80002872 <devintr+0x1e>
      printf("unexpected interrupt irq=%d\n", irq);
    800028a0:	85a6                	mv	a1,s1
    800028a2:	00006517          	auipc	a0,0x6
    800028a6:	a5e50513          	addi	a0,a0,-1442 # 80008300 <states.0+0x38>
    800028aa:	ffffe097          	auipc	ra,0xffffe
    800028ae:	cde080e7          	jalr	-802(ra) # 80000588 <printf>
      plic_complete(irq);
    800028b2:	8526                	mv	a0,s1
    800028b4:	00003097          	auipc	ra,0x3
    800028b8:	4a8080e7          	jalr	1192(ra) # 80005d5c <plic_complete>
    return 1;
    800028bc:	4505                	li	a0,1
    800028be:	bf55                	j	80002872 <devintr+0x1e>
      uartintr();
    800028c0:	ffffe097          	auipc	ra,0xffffe
    800028c4:	0d6080e7          	jalr	214(ra) # 80000996 <uartintr>
    800028c8:	b7ed                	j	800028b2 <devintr+0x5e>
      virtio_disk_intr();
    800028ca:	00004097          	auipc	ra,0x4
    800028ce:	95a080e7          	jalr	-1702(ra) # 80006224 <virtio_disk_intr>
    800028d2:	b7c5                	j	800028b2 <devintr+0x5e>
    if(cpuid() == 0){
    800028d4:	fffff097          	auipc	ra,0xfffff
    800028d8:	0aa080e7          	jalr	170(ra) # 8000197e <cpuid>
    800028dc:	c901                	beqz	a0,800028ec <devintr+0x98>
  asm volatile("csrr %0, sip" : "=r" (x) );
    800028de:	144027f3          	csrr	a5,sip
    w_sip(r_sip() & ~2);
    800028e2:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sip, %0" : : "r" (x));
    800028e4:	14479073          	csrw	sip,a5
    return 2;
    800028e8:	4509                	li	a0,2
    800028ea:	b761                	j	80002872 <devintr+0x1e>
      clockintr();
    800028ec:	00000097          	auipc	ra,0x0
    800028f0:	f22080e7          	jalr	-222(ra) # 8000280e <clockintr>
    800028f4:	b7ed                	j	800028de <devintr+0x8a>

00000000800028f6 <usertrap>:
{
    800028f6:	1101                	addi	sp,sp,-32
    800028f8:	ec06                	sd	ra,24(sp)
    800028fa:	e822                	sd	s0,16(sp)
    800028fc:	e426                	sd	s1,8(sp)
    800028fe:	e04a                	sd	s2,0(sp)
    80002900:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002902:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    80002906:	1007f793          	andi	a5,a5,256
    8000290a:	e3b1                	bnez	a5,8000294e <usertrap+0x58>
  asm volatile("csrw stvec, %0" : : "r" (x));
    8000290c:	00003797          	auipc	a5,0x3
    80002910:	32478793          	addi	a5,a5,804 # 80005c30 <kernelvec>
    80002914:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    80002918:	fffff097          	auipc	ra,0xfffff
    8000291c:	092080e7          	jalr	146(ra) # 800019aa <myproc>
    80002920:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80002922:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002924:	14102773          	csrr	a4,sepc
    80002928:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000292a:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    8000292e:	47a1                	li	a5,8
    80002930:	02f70763          	beq	a4,a5,8000295e <usertrap+0x68>
  } else if((which_dev = devintr()) != 0){
    80002934:	00000097          	auipc	ra,0x0
    80002938:	f20080e7          	jalr	-224(ra) # 80002854 <devintr>
    8000293c:	892a                	mv	s2,a0
    8000293e:	c151                	beqz	a0,800029c2 <usertrap+0xcc>
  if(killed(p))
    80002940:	8526                	mv	a0,s1
    80002942:	00000097          	auipc	ra,0x0
    80002946:	ace080e7          	jalr	-1330(ra) # 80002410 <killed>
    8000294a:	c929                	beqz	a0,8000299c <usertrap+0xa6>
    8000294c:	a099                	j	80002992 <usertrap+0x9c>
    panic("usertrap: not from user mode");
    8000294e:	00006517          	auipc	a0,0x6
    80002952:	9d250513          	addi	a0,a0,-1582 # 80008320 <states.0+0x58>
    80002956:	ffffe097          	auipc	ra,0xffffe
    8000295a:	be8080e7          	jalr	-1048(ra) # 8000053e <panic>
    if(killed(p))
    8000295e:	00000097          	auipc	ra,0x0
    80002962:	ab2080e7          	jalr	-1358(ra) # 80002410 <killed>
    80002966:	e921                	bnez	a0,800029b6 <usertrap+0xc0>
    p->trapframe->epc += 4;
    80002968:	6cb8                	ld	a4,88(s1)
    8000296a:	6f1c                	ld	a5,24(a4)
    8000296c:	0791                	addi	a5,a5,4
    8000296e:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002970:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80002974:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002978:	10079073          	csrw	sstatus,a5
    syscall();
    8000297c:	00000097          	auipc	ra,0x0
    80002980:	2d4080e7          	jalr	724(ra) # 80002c50 <syscall>
  if(killed(p))
    80002984:	8526                	mv	a0,s1
    80002986:	00000097          	auipc	ra,0x0
    8000298a:	a8a080e7          	jalr	-1398(ra) # 80002410 <killed>
    8000298e:	c911                	beqz	a0,800029a2 <usertrap+0xac>
    80002990:	4901                	li	s2,0
    exit(-1);
    80002992:	557d                	li	a0,-1
    80002994:	00000097          	auipc	ra,0x0
    80002998:	908080e7          	jalr	-1784(ra) # 8000229c <exit>
  if(which_dev == 2)
    8000299c:	4789                	li	a5,2
    8000299e:	04f90f63          	beq	s2,a5,800029fc <usertrap+0x106>
  usertrapret();
    800029a2:	00000097          	auipc	ra,0x0
    800029a6:	dd6080e7          	jalr	-554(ra) # 80002778 <usertrapret>
}
    800029aa:	60e2                	ld	ra,24(sp)
    800029ac:	6442                	ld	s0,16(sp)
    800029ae:	64a2                	ld	s1,8(sp)
    800029b0:	6902                	ld	s2,0(sp)
    800029b2:	6105                	addi	sp,sp,32
    800029b4:	8082                	ret
      exit(-1);
    800029b6:	557d                	li	a0,-1
    800029b8:	00000097          	auipc	ra,0x0
    800029bc:	8e4080e7          	jalr	-1820(ra) # 8000229c <exit>
    800029c0:	b765                	j	80002968 <usertrap+0x72>
  asm volatile("csrr %0, scause" : "=r" (x) );
    800029c2:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause %p pid=%d\n", r_scause(), p->pid);
    800029c6:	5890                	lw	a2,48(s1)
    800029c8:	00006517          	auipc	a0,0x6
    800029cc:	97850513          	addi	a0,a0,-1672 # 80008340 <states.0+0x78>
    800029d0:	ffffe097          	auipc	ra,0xffffe
    800029d4:	bb8080e7          	jalr	-1096(ra) # 80000588 <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800029d8:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    800029dc:	14302673          	csrr	a2,stval
    printf("            sepc=%p stval=%p\n", r_sepc(), r_stval());
    800029e0:	00006517          	auipc	a0,0x6
    800029e4:	99050513          	addi	a0,a0,-1648 # 80008370 <states.0+0xa8>
    800029e8:	ffffe097          	auipc	ra,0xffffe
    800029ec:	ba0080e7          	jalr	-1120(ra) # 80000588 <printf>
    setkilled(p);
    800029f0:	8526                	mv	a0,s1
    800029f2:	00000097          	auipc	ra,0x0
    800029f6:	9f2080e7          	jalr	-1550(ra) # 800023e4 <setkilled>
    800029fa:	b769                	j	80002984 <usertrap+0x8e>
    yield();
    800029fc:	fffff097          	auipc	ra,0xfffff
    80002a00:	710080e7          	jalr	1808(ra) # 8000210c <yield>
    80002a04:	bf79                	j	800029a2 <usertrap+0xac>

0000000080002a06 <kerneltrap>:
{
    80002a06:	7179                	addi	sp,sp,-48
    80002a08:	f406                	sd	ra,40(sp)
    80002a0a:	f022                	sd	s0,32(sp)
    80002a0c:	ec26                	sd	s1,24(sp)
    80002a0e:	e84a                	sd	s2,16(sp)
    80002a10:	e44e                	sd	s3,8(sp)
    80002a12:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002a14:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002a18:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002a1c:	142029f3          	csrr	s3,scause
  if((sstatus & SSTATUS_SPP) == 0)
    80002a20:	1004f793          	andi	a5,s1,256
    80002a24:	cb85                	beqz	a5,80002a54 <kerneltrap+0x4e>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002a26:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80002a2a:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    80002a2c:	ef85                	bnez	a5,80002a64 <kerneltrap+0x5e>
  if((which_dev = devintr()) == 0){
    80002a2e:	00000097          	auipc	ra,0x0
    80002a32:	e26080e7          	jalr	-474(ra) # 80002854 <devintr>
    80002a36:	cd1d                	beqz	a0,80002a74 <kerneltrap+0x6e>
  if(which_dev == 2 && myproc() != 0 && myproc()->state == RUNNING)
    80002a38:	4789                	li	a5,2
    80002a3a:	06f50a63          	beq	a0,a5,80002aae <kerneltrap+0xa8>
  asm volatile("csrw sepc, %0" : : "r" (x));
    80002a3e:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002a42:	10049073          	csrw	sstatus,s1
}
    80002a46:	70a2                	ld	ra,40(sp)
    80002a48:	7402                	ld	s0,32(sp)
    80002a4a:	64e2                	ld	s1,24(sp)
    80002a4c:	6942                	ld	s2,16(sp)
    80002a4e:	69a2                	ld	s3,8(sp)
    80002a50:	6145                	addi	sp,sp,48
    80002a52:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80002a54:	00006517          	auipc	a0,0x6
    80002a58:	93c50513          	addi	a0,a0,-1732 # 80008390 <states.0+0xc8>
    80002a5c:	ffffe097          	auipc	ra,0xffffe
    80002a60:	ae2080e7          	jalr	-1310(ra) # 8000053e <panic>
    panic("kerneltrap: interrupts enabled");
    80002a64:	00006517          	auipc	a0,0x6
    80002a68:	95450513          	addi	a0,a0,-1708 # 800083b8 <states.0+0xf0>
    80002a6c:	ffffe097          	auipc	ra,0xffffe
    80002a70:	ad2080e7          	jalr	-1326(ra) # 8000053e <panic>
    printf("scause %p\n", scause);
    80002a74:	85ce                	mv	a1,s3
    80002a76:	00006517          	auipc	a0,0x6
    80002a7a:	96250513          	addi	a0,a0,-1694 # 800083d8 <states.0+0x110>
    80002a7e:	ffffe097          	auipc	ra,0xffffe
    80002a82:	b0a080e7          	jalr	-1270(ra) # 80000588 <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002a86:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002a8a:	14302673          	csrr	a2,stval
    printf("sepc=%p stval=%p\n", r_sepc(), r_stval());
    80002a8e:	00006517          	auipc	a0,0x6
    80002a92:	95a50513          	addi	a0,a0,-1702 # 800083e8 <states.0+0x120>
    80002a96:	ffffe097          	auipc	ra,0xffffe
    80002a9a:	af2080e7          	jalr	-1294(ra) # 80000588 <printf>
    panic("kerneltrap");
    80002a9e:	00006517          	auipc	a0,0x6
    80002aa2:	96250513          	addi	a0,a0,-1694 # 80008400 <states.0+0x138>
    80002aa6:	ffffe097          	auipc	ra,0xffffe
    80002aaa:	a98080e7          	jalr	-1384(ra) # 8000053e <panic>
  if(which_dev == 2 && myproc() != 0 && myproc()->state == RUNNING)
    80002aae:	fffff097          	auipc	ra,0xfffff
    80002ab2:	efc080e7          	jalr	-260(ra) # 800019aa <myproc>
    80002ab6:	d541                	beqz	a0,80002a3e <kerneltrap+0x38>
    80002ab8:	fffff097          	auipc	ra,0xfffff
    80002abc:	ef2080e7          	jalr	-270(ra) # 800019aa <myproc>
    80002ac0:	4d18                	lw	a4,24(a0)
    80002ac2:	4791                	li	a5,4
    80002ac4:	f6f71de3          	bne	a4,a5,80002a3e <kerneltrap+0x38>
    yield();
    80002ac8:	fffff097          	auipc	ra,0xfffff
    80002acc:	644080e7          	jalr	1604(ra) # 8000210c <yield>
    80002ad0:	b7bd                	j	80002a3e <kerneltrap+0x38>

0000000080002ad2 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80002ad2:	1101                	addi	sp,sp,-32
    80002ad4:	ec06                	sd	ra,24(sp)
    80002ad6:	e822                	sd	s0,16(sp)
    80002ad8:	e426                	sd	s1,8(sp)
    80002ada:	1000                	addi	s0,sp,32
    80002adc:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002ade:	fffff097          	auipc	ra,0xfffff
    80002ae2:	ecc080e7          	jalr	-308(ra) # 800019aa <myproc>
  switch (n) {
    80002ae6:	4795                	li	a5,5
    80002ae8:	0497e163          	bltu	a5,s1,80002b2a <argraw+0x58>
    80002aec:	048a                	slli	s1,s1,0x2
    80002aee:	00006717          	auipc	a4,0x6
    80002af2:	94a70713          	addi	a4,a4,-1718 # 80008438 <states.0+0x170>
    80002af6:	94ba                	add	s1,s1,a4
    80002af8:	409c                	lw	a5,0(s1)
    80002afa:	97ba                	add	a5,a5,a4
    80002afc:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80002afe:	6d3c                	ld	a5,88(a0)
    80002b00:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002b02:	60e2                	ld	ra,24(sp)
    80002b04:	6442                	ld	s0,16(sp)
    80002b06:	64a2                	ld	s1,8(sp)
    80002b08:	6105                	addi	sp,sp,32
    80002b0a:	8082                	ret
    return p->trapframe->a1;
    80002b0c:	6d3c                	ld	a5,88(a0)
    80002b0e:	7fa8                	ld	a0,120(a5)
    80002b10:	bfcd                	j	80002b02 <argraw+0x30>
    return p->trapframe->a2;
    80002b12:	6d3c                	ld	a5,88(a0)
    80002b14:	63c8                	ld	a0,128(a5)
    80002b16:	b7f5                	j	80002b02 <argraw+0x30>
    return p->trapframe->a3;
    80002b18:	6d3c                	ld	a5,88(a0)
    80002b1a:	67c8                	ld	a0,136(a5)
    80002b1c:	b7dd                	j	80002b02 <argraw+0x30>
    return p->trapframe->a4;
    80002b1e:	6d3c                	ld	a5,88(a0)
    80002b20:	6bc8                	ld	a0,144(a5)
    80002b22:	b7c5                	j	80002b02 <argraw+0x30>
    return p->trapframe->a5;
    80002b24:	6d3c                	ld	a5,88(a0)
    80002b26:	6fc8                	ld	a0,152(a5)
    80002b28:	bfe9                	j	80002b02 <argraw+0x30>
  panic("argraw");
    80002b2a:	00006517          	auipc	a0,0x6
    80002b2e:	8e650513          	addi	a0,a0,-1818 # 80008410 <states.0+0x148>
    80002b32:	ffffe097          	auipc	ra,0xffffe
    80002b36:	a0c080e7          	jalr	-1524(ra) # 8000053e <panic>

0000000080002b3a <fetchaddr>:
{
    80002b3a:	1101                	addi	sp,sp,-32
    80002b3c:	ec06                	sd	ra,24(sp)
    80002b3e:	e822                	sd	s0,16(sp)
    80002b40:	e426                	sd	s1,8(sp)
    80002b42:	e04a                	sd	s2,0(sp)
    80002b44:	1000                	addi	s0,sp,32
    80002b46:	84aa                	mv	s1,a0
    80002b48:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002b4a:	fffff097          	auipc	ra,0xfffff
    80002b4e:	e60080e7          	jalr	-416(ra) # 800019aa <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80002b52:	653c                	ld	a5,72(a0)
    80002b54:	02f4f863          	bgeu	s1,a5,80002b84 <fetchaddr+0x4a>
    80002b58:	00848713          	addi	a4,s1,8
    80002b5c:	02e7e663          	bltu	a5,a4,80002b88 <fetchaddr+0x4e>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80002b60:	46a1                	li	a3,8
    80002b62:	8626                	mv	a2,s1
    80002b64:	85ca                	mv	a1,s2
    80002b66:	6928                	ld	a0,80(a0)
    80002b68:	fffff097          	auipc	ra,0xfffff
    80002b6c:	b8e080e7          	jalr	-1138(ra) # 800016f6 <copyin>
    80002b70:	00a03533          	snez	a0,a0
    80002b74:	40a00533          	neg	a0,a0
}
    80002b78:	60e2                	ld	ra,24(sp)
    80002b7a:	6442                	ld	s0,16(sp)
    80002b7c:	64a2                	ld	s1,8(sp)
    80002b7e:	6902                	ld	s2,0(sp)
    80002b80:	6105                	addi	sp,sp,32
    80002b82:	8082                	ret
    return -1;
    80002b84:	557d                	li	a0,-1
    80002b86:	bfcd                	j	80002b78 <fetchaddr+0x3e>
    80002b88:	557d                	li	a0,-1
    80002b8a:	b7fd                	j	80002b78 <fetchaddr+0x3e>

0000000080002b8c <fetchstr>:
{
    80002b8c:	7179                	addi	sp,sp,-48
    80002b8e:	f406                	sd	ra,40(sp)
    80002b90:	f022                	sd	s0,32(sp)
    80002b92:	ec26                	sd	s1,24(sp)
    80002b94:	e84a                	sd	s2,16(sp)
    80002b96:	e44e                	sd	s3,8(sp)
    80002b98:	1800                	addi	s0,sp,48
    80002b9a:	892a                	mv	s2,a0
    80002b9c:	84ae                	mv	s1,a1
    80002b9e:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    80002ba0:	fffff097          	auipc	ra,0xfffff
    80002ba4:	e0a080e7          	jalr	-502(ra) # 800019aa <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80002ba8:	86ce                	mv	a3,s3
    80002baa:	864a                	mv	a2,s2
    80002bac:	85a6                	mv	a1,s1
    80002bae:	6928                	ld	a0,80(a0)
    80002bb0:	fffff097          	auipc	ra,0xfffff
    80002bb4:	bd4080e7          	jalr	-1068(ra) # 80001784 <copyinstr>
    80002bb8:	00054e63          	bltz	a0,80002bd4 <fetchstr+0x48>
  return strlen(buf);
    80002bbc:	8526                	mv	a0,s1
    80002bbe:	ffffe097          	auipc	ra,0xffffe
    80002bc2:	28e080e7          	jalr	654(ra) # 80000e4c <strlen>
}
    80002bc6:	70a2                	ld	ra,40(sp)
    80002bc8:	7402                	ld	s0,32(sp)
    80002bca:	64e2                	ld	s1,24(sp)
    80002bcc:	6942                	ld	s2,16(sp)
    80002bce:	69a2                	ld	s3,8(sp)
    80002bd0:	6145                	addi	sp,sp,48
    80002bd2:	8082                	ret
    return -1;
    80002bd4:	557d                	li	a0,-1
    80002bd6:	bfc5                	j	80002bc6 <fetchstr+0x3a>

0000000080002bd8 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002bd8:	1101                	addi	sp,sp,-32
    80002bda:	ec06                	sd	ra,24(sp)
    80002bdc:	e822                	sd	s0,16(sp)
    80002bde:	e426                	sd	s1,8(sp)
    80002be0:	1000                	addi	s0,sp,32
    80002be2:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002be4:	00000097          	auipc	ra,0x0
    80002be8:	eee080e7          	jalr	-274(ra) # 80002ad2 <argraw>
    80002bec:	c088                	sw	a0,0(s1)
}
    80002bee:	60e2                	ld	ra,24(sp)
    80002bf0:	6442                	ld	s0,16(sp)
    80002bf2:	64a2                	ld	s1,8(sp)
    80002bf4:	6105                	addi	sp,sp,32
    80002bf6:	8082                	ret

0000000080002bf8 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80002bf8:	1101                	addi	sp,sp,-32
    80002bfa:	ec06                	sd	ra,24(sp)
    80002bfc:	e822                	sd	s0,16(sp)
    80002bfe:	e426                	sd	s1,8(sp)
    80002c00:	1000                	addi	s0,sp,32
    80002c02:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002c04:	00000097          	auipc	ra,0x0
    80002c08:	ece080e7          	jalr	-306(ra) # 80002ad2 <argraw>
    80002c0c:	e088                	sd	a0,0(s1)
}
    80002c0e:	60e2                	ld	ra,24(sp)
    80002c10:	6442                	ld	s0,16(sp)
    80002c12:	64a2                	ld	s1,8(sp)
    80002c14:	6105                	addi	sp,sp,32
    80002c16:	8082                	ret

0000000080002c18 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80002c18:	7179                	addi	sp,sp,-48
    80002c1a:	f406                	sd	ra,40(sp)
    80002c1c:	f022                	sd	s0,32(sp)
    80002c1e:	ec26                	sd	s1,24(sp)
    80002c20:	e84a                	sd	s2,16(sp)
    80002c22:	1800                	addi	s0,sp,48
    80002c24:	84ae                	mv	s1,a1
    80002c26:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    80002c28:	fd840593          	addi	a1,s0,-40
    80002c2c:	00000097          	auipc	ra,0x0
    80002c30:	fcc080e7          	jalr	-52(ra) # 80002bf8 <argaddr>
  return fetchstr(addr, buf, max);
    80002c34:	864a                	mv	a2,s2
    80002c36:	85a6                	mv	a1,s1
    80002c38:	fd843503          	ld	a0,-40(s0)
    80002c3c:	00000097          	auipc	ra,0x0
    80002c40:	f50080e7          	jalr	-176(ra) # 80002b8c <fetchstr>
}
    80002c44:	70a2                	ld	ra,40(sp)
    80002c46:	7402                	ld	s0,32(sp)
    80002c48:	64e2                	ld	s1,24(sp)
    80002c4a:	6942                	ld	s2,16(sp)
    80002c4c:	6145                	addi	sp,sp,48
    80002c4e:	8082                	ret

0000000080002c50 <syscall>:
[SYS_close]   sys_close,
};

void
syscall(void)
{
    80002c50:	1101                	addi	sp,sp,-32
    80002c52:	ec06                	sd	ra,24(sp)
    80002c54:	e822                	sd	s0,16(sp)
    80002c56:	e426                	sd	s1,8(sp)
    80002c58:	e04a                	sd	s2,0(sp)
    80002c5a:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002c5c:	fffff097          	auipc	ra,0xfffff
    80002c60:	d4e080e7          	jalr	-690(ra) # 800019aa <myproc>
    80002c64:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002c66:	05853903          	ld	s2,88(a0)
    80002c6a:	0a893783          	ld	a5,168(s2)
    80002c6e:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002c72:	37fd                	addiw	a5,a5,-1
    80002c74:	4751                	li	a4,20
    80002c76:	00f76f63          	bltu	a4,a5,80002c94 <syscall+0x44>
    80002c7a:	00369713          	slli	a4,a3,0x3
    80002c7e:	00005797          	auipc	a5,0x5
    80002c82:	7d278793          	addi	a5,a5,2002 # 80008450 <syscalls>
    80002c86:	97ba                	add	a5,a5,a4
    80002c88:	639c                	ld	a5,0(a5)
    80002c8a:	c789                	beqz	a5,80002c94 <syscall+0x44>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002c8c:	9782                	jalr	a5
    80002c8e:	06a93823          	sd	a0,112(s2)
    80002c92:	a839                	j	80002cb0 <syscall+0x60>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80002c94:	15848613          	addi	a2,s1,344
    80002c98:	588c                	lw	a1,48(s1)
    80002c9a:	00005517          	auipc	a0,0x5
    80002c9e:	77e50513          	addi	a0,a0,1918 # 80008418 <states.0+0x150>
    80002ca2:	ffffe097          	auipc	ra,0xffffe
    80002ca6:	8e6080e7          	jalr	-1818(ra) # 80000588 <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80002caa:	6cbc                	ld	a5,88(s1)
    80002cac:	577d                	li	a4,-1
    80002cae:	fbb8                	sd	a4,112(a5)
  }
}
    80002cb0:	60e2                	ld	ra,24(sp)
    80002cb2:	6442                	ld	s0,16(sp)
    80002cb4:	64a2                	ld	s1,8(sp)
    80002cb6:	6902                	ld	s2,0(sp)
    80002cb8:	6105                	addi	sp,sp,32
    80002cba:	8082                	ret

0000000080002cbc <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    80002cbc:	1101                	addi	sp,sp,-32
    80002cbe:	ec06                	sd	ra,24(sp)
    80002cc0:	e822                	sd	s0,16(sp)
    80002cc2:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002cc4:	fec40593          	addi	a1,s0,-20
    80002cc8:	4501                	li	a0,0
    80002cca:	00000097          	auipc	ra,0x0
    80002cce:	f0e080e7          	jalr	-242(ra) # 80002bd8 <argint>
  exit(n);
    80002cd2:	fec42503          	lw	a0,-20(s0)
    80002cd6:	fffff097          	auipc	ra,0xfffff
    80002cda:	5c6080e7          	jalr	1478(ra) # 8000229c <exit>
  return 0;  // not reached
}
    80002cde:	4501                	li	a0,0
    80002ce0:	60e2                	ld	ra,24(sp)
    80002ce2:	6442                	ld	s0,16(sp)
    80002ce4:	6105                	addi	sp,sp,32
    80002ce6:	8082                	ret

0000000080002ce8 <sys_getpid>:

uint64
sys_getpid(void)
{
    80002ce8:	1141                	addi	sp,sp,-16
    80002cea:	e406                	sd	ra,8(sp)
    80002cec:	e022                	sd	s0,0(sp)
    80002cee:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002cf0:	fffff097          	auipc	ra,0xfffff
    80002cf4:	cba080e7          	jalr	-838(ra) # 800019aa <myproc>
}
    80002cf8:	5908                	lw	a0,48(a0)
    80002cfa:	60a2                	ld	ra,8(sp)
    80002cfc:	6402                	ld	s0,0(sp)
    80002cfe:	0141                	addi	sp,sp,16
    80002d00:	8082                	ret

0000000080002d02 <sys_fork>:

uint64
sys_fork(void)
{
    80002d02:	1141                	addi	sp,sp,-16
    80002d04:	e406                	sd	ra,8(sp)
    80002d06:	e022                	sd	s0,0(sp)
    80002d08:	0800                	addi	s0,sp,16
  return fork();
    80002d0a:	fffff097          	auipc	ra,0xfffff
    80002d0e:	064080e7          	jalr	100(ra) # 80001d6e <fork>
}
    80002d12:	60a2                	ld	ra,8(sp)
    80002d14:	6402                	ld	s0,0(sp)
    80002d16:	0141                	addi	sp,sp,16
    80002d18:	8082                	ret

0000000080002d1a <sys_wait>:

uint64
sys_wait(void)
{
    80002d1a:	1101                	addi	sp,sp,-32
    80002d1c:	ec06                	sd	ra,24(sp)
    80002d1e:	e822                	sd	s0,16(sp)
    80002d20:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002d22:	fe840593          	addi	a1,s0,-24
    80002d26:	4501                	li	a0,0
    80002d28:	00000097          	auipc	ra,0x0
    80002d2c:	ed0080e7          	jalr	-304(ra) # 80002bf8 <argaddr>
  return wait(p);
    80002d30:	fe843503          	ld	a0,-24(s0)
    80002d34:	fffff097          	auipc	ra,0xfffff
    80002d38:	70e080e7          	jalr	1806(ra) # 80002442 <wait>
}
    80002d3c:	60e2                	ld	ra,24(sp)
    80002d3e:	6442                	ld	s0,16(sp)
    80002d40:	6105                	addi	sp,sp,32
    80002d42:	8082                	ret

0000000080002d44 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002d44:	7179                	addi	sp,sp,-48
    80002d46:	f406                	sd	ra,40(sp)
    80002d48:	f022                	sd	s0,32(sp)
    80002d4a:	ec26                	sd	s1,24(sp)
    80002d4c:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    80002d4e:	fdc40593          	addi	a1,s0,-36
    80002d52:	4501                	li	a0,0
    80002d54:	00000097          	auipc	ra,0x0
    80002d58:	e84080e7          	jalr	-380(ra) # 80002bd8 <argint>
  addr = myproc()->sz;
    80002d5c:	fffff097          	auipc	ra,0xfffff
    80002d60:	c4e080e7          	jalr	-946(ra) # 800019aa <myproc>
    80002d64:	6524                	ld	s1,72(a0)
  if(growproc(n) < 0)
    80002d66:	fdc42503          	lw	a0,-36(s0)
    80002d6a:	fffff097          	auipc	ra,0xfffff
    80002d6e:	fa8080e7          	jalr	-88(ra) # 80001d12 <growproc>
    80002d72:	00054863          	bltz	a0,80002d82 <sys_sbrk+0x3e>
    return -1;
  return addr;
}
    80002d76:	8526                	mv	a0,s1
    80002d78:	70a2                	ld	ra,40(sp)
    80002d7a:	7402                	ld	s0,32(sp)
    80002d7c:	64e2                	ld	s1,24(sp)
    80002d7e:	6145                	addi	sp,sp,48
    80002d80:	8082                	ret
    return -1;
    80002d82:	54fd                	li	s1,-1
    80002d84:	bfcd                	j	80002d76 <sys_sbrk+0x32>

0000000080002d86 <sys_sleep>:

uint64
sys_sleep(void)
{
    80002d86:	7139                	addi	sp,sp,-64
    80002d88:	fc06                	sd	ra,56(sp)
    80002d8a:	f822                	sd	s0,48(sp)
    80002d8c:	f426                	sd	s1,40(sp)
    80002d8e:	f04a                	sd	s2,32(sp)
    80002d90:	ec4e                	sd	s3,24(sp)
    80002d92:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002d94:	fcc40593          	addi	a1,s0,-52
    80002d98:	4501                	li	a0,0
    80002d9a:	00000097          	auipc	ra,0x0
    80002d9e:	e3e080e7          	jalr	-450(ra) # 80002bd8 <argint>
  acquire(&tickslock);
    80002da2:	00014517          	auipc	a0,0x14
    80002da6:	fde50513          	addi	a0,a0,-34 # 80016d80 <tickslock>
    80002daa:	ffffe097          	auipc	ra,0xffffe
    80002dae:	e2a080e7          	jalr	-470(ra) # 80000bd4 <acquire>
  ticks0 = ticks;
    80002db2:	00006917          	auipc	s2,0x6
    80002db6:	b2e92903          	lw	s2,-1234(s2) # 800088e0 <ticks>
  while(ticks - ticks0 < n){
    80002dba:	fcc42783          	lw	a5,-52(s0)
    80002dbe:	cf9d                	beqz	a5,80002dfc <sys_sleep+0x76>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80002dc0:	00014997          	auipc	s3,0x14
    80002dc4:	fc098993          	addi	s3,s3,-64 # 80016d80 <tickslock>
    80002dc8:	00006497          	auipc	s1,0x6
    80002dcc:	b1848493          	addi	s1,s1,-1256 # 800088e0 <ticks>
    if(killed(myproc())){
    80002dd0:	fffff097          	auipc	ra,0xfffff
    80002dd4:	bda080e7          	jalr	-1062(ra) # 800019aa <myproc>
    80002dd8:	fffff097          	auipc	ra,0xfffff
    80002ddc:	638080e7          	jalr	1592(ra) # 80002410 <killed>
    80002de0:	ed15                	bnez	a0,80002e1c <sys_sleep+0x96>
    sleep(&ticks, &tickslock);
    80002de2:	85ce                	mv	a1,s3
    80002de4:	8526                	mv	a0,s1
    80002de6:	fffff097          	auipc	ra,0xfffff
    80002dea:	370080e7          	jalr	880(ra) # 80002156 <sleep>
  while(ticks - ticks0 < n){
    80002dee:	409c                	lw	a5,0(s1)
    80002df0:	412787bb          	subw	a5,a5,s2
    80002df4:	fcc42703          	lw	a4,-52(s0)
    80002df8:	fce7ece3          	bltu	a5,a4,80002dd0 <sys_sleep+0x4a>
  }
  release(&tickslock);
    80002dfc:	00014517          	auipc	a0,0x14
    80002e00:	f8450513          	addi	a0,a0,-124 # 80016d80 <tickslock>
    80002e04:	ffffe097          	auipc	ra,0xffffe
    80002e08:	e84080e7          	jalr	-380(ra) # 80000c88 <release>
  return 0;
    80002e0c:	4501                	li	a0,0
}
    80002e0e:	70e2                	ld	ra,56(sp)
    80002e10:	7442                	ld	s0,48(sp)
    80002e12:	74a2                	ld	s1,40(sp)
    80002e14:	7902                	ld	s2,32(sp)
    80002e16:	69e2                	ld	s3,24(sp)
    80002e18:	6121                	addi	sp,sp,64
    80002e1a:	8082                	ret
      release(&tickslock);
    80002e1c:	00014517          	auipc	a0,0x14
    80002e20:	f6450513          	addi	a0,a0,-156 # 80016d80 <tickslock>
    80002e24:	ffffe097          	auipc	ra,0xffffe
    80002e28:	e64080e7          	jalr	-412(ra) # 80000c88 <release>
      return -1;
    80002e2c:	557d                	li	a0,-1
    80002e2e:	b7c5                	j	80002e0e <sys_sleep+0x88>

0000000080002e30 <sys_kill>:

uint64
sys_kill(void)
{
    80002e30:	1101                	addi	sp,sp,-32
    80002e32:	ec06                	sd	ra,24(sp)
    80002e34:	e822                	sd	s0,16(sp)
    80002e36:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002e38:	fec40593          	addi	a1,s0,-20
    80002e3c:	4501                	li	a0,0
    80002e3e:	00000097          	auipc	ra,0x0
    80002e42:	d9a080e7          	jalr	-614(ra) # 80002bd8 <argint>
  return kill(pid);
    80002e46:	fec42503          	lw	a0,-20(s0)
    80002e4a:	fffff097          	auipc	ra,0xfffff
    80002e4e:	528080e7          	jalr	1320(ra) # 80002372 <kill>
}
    80002e52:	60e2                	ld	ra,24(sp)
    80002e54:	6442                	ld	s0,16(sp)
    80002e56:	6105                	addi	sp,sp,32
    80002e58:	8082                	ret

0000000080002e5a <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002e5a:	1101                	addi	sp,sp,-32
    80002e5c:	ec06                	sd	ra,24(sp)
    80002e5e:	e822                	sd	s0,16(sp)
    80002e60:	e426                	sd	s1,8(sp)
    80002e62:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002e64:	00014517          	auipc	a0,0x14
    80002e68:	f1c50513          	addi	a0,a0,-228 # 80016d80 <tickslock>
    80002e6c:	ffffe097          	auipc	ra,0xffffe
    80002e70:	d68080e7          	jalr	-664(ra) # 80000bd4 <acquire>
  xticks = ticks;
    80002e74:	00006497          	auipc	s1,0x6
    80002e78:	a6c4a483          	lw	s1,-1428(s1) # 800088e0 <ticks>
  release(&tickslock);
    80002e7c:	00014517          	auipc	a0,0x14
    80002e80:	f0450513          	addi	a0,a0,-252 # 80016d80 <tickslock>
    80002e84:	ffffe097          	auipc	ra,0xffffe
    80002e88:	e04080e7          	jalr	-508(ra) # 80000c88 <release>
  return xticks;
}
    80002e8c:	02049513          	slli	a0,s1,0x20
    80002e90:	9101                	srli	a0,a0,0x20
    80002e92:	60e2                	ld	ra,24(sp)
    80002e94:	6442                	ld	s0,16(sp)
    80002e96:	64a2                	ld	s1,8(sp)
    80002e98:	6105                	addi	sp,sp,32
    80002e9a:	8082                	ret

0000000080002e9c <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002e9c:	7179                	addi	sp,sp,-48
    80002e9e:	f406                	sd	ra,40(sp)
    80002ea0:	f022                	sd	s0,32(sp)
    80002ea2:	ec26                	sd	s1,24(sp)
    80002ea4:	e84a                	sd	s2,16(sp)
    80002ea6:	e44e                	sd	s3,8(sp)
    80002ea8:	e052                	sd	s4,0(sp)
    80002eaa:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002eac:	00005597          	auipc	a1,0x5
    80002eb0:	65458593          	addi	a1,a1,1620 # 80008500 <syscalls+0xb0>
    80002eb4:	00014517          	auipc	a0,0x14
    80002eb8:	ee450513          	addi	a0,a0,-284 # 80016d98 <bcache>
    80002ebc:	ffffe097          	auipc	ra,0xffffe
    80002ec0:	c88080e7          	jalr	-888(ra) # 80000b44 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002ec4:	0001c797          	auipc	a5,0x1c
    80002ec8:	ed478793          	addi	a5,a5,-300 # 8001ed98 <bcache+0x8000>
    80002ecc:	0001c717          	auipc	a4,0x1c
    80002ed0:	13470713          	addi	a4,a4,308 # 8001f000 <bcache+0x8268>
    80002ed4:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002ed8:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002edc:	00014497          	auipc	s1,0x14
    80002ee0:	ed448493          	addi	s1,s1,-300 # 80016db0 <bcache+0x18>
    b->next = bcache.head.next;
    80002ee4:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002ee6:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002ee8:	00005a17          	auipc	s4,0x5
    80002eec:	620a0a13          	addi	s4,s4,1568 # 80008508 <syscalls+0xb8>
    b->next = bcache.head.next;
    80002ef0:	2b893783          	ld	a5,696(s2)
    80002ef4:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002ef6:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002efa:	85d2                	mv	a1,s4
    80002efc:	01048513          	addi	a0,s1,16
    80002f00:	00001097          	auipc	ra,0x1
    80002f04:	4c8080e7          	jalr	1224(ra) # 800043c8 <initsleeplock>
    bcache.head.next->prev = b;
    80002f08:	2b893783          	ld	a5,696(s2)
    80002f0c:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002f0e:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002f12:	45848493          	addi	s1,s1,1112
    80002f16:	fd349de3          	bne	s1,s3,80002ef0 <binit+0x54>
  }
}
    80002f1a:	70a2                	ld	ra,40(sp)
    80002f1c:	7402                	ld	s0,32(sp)
    80002f1e:	64e2                	ld	s1,24(sp)
    80002f20:	6942                	ld	s2,16(sp)
    80002f22:	69a2                	ld	s3,8(sp)
    80002f24:	6a02                	ld	s4,0(sp)
    80002f26:	6145                	addi	sp,sp,48
    80002f28:	8082                	ret

0000000080002f2a <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002f2a:	7179                	addi	sp,sp,-48
    80002f2c:	f406                	sd	ra,40(sp)
    80002f2e:	f022                	sd	s0,32(sp)
    80002f30:	ec26                	sd	s1,24(sp)
    80002f32:	e84a                	sd	s2,16(sp)
    80002f34:	e44e                	sd	s3,8(sp)
    80002f36:	1800                	addi	s0,sp,48
    80002f38:	892a                	mv	s2,a0
    80002f3a:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002f3c:	00014517          	auipc	a0,0x14
    80002f40:	e5c50513          	addi	a0,a0,-420 # 80016d98 <bcache>
    80002f44:	ffffe097          	auipc	ra,0xffffe
    80002f48:	c90080e7          	jalr	-880(ra) # 80000bd4 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002f4c:	0001c497          	auipc	s1,0x1c
    80002f50:	1044b483          	ld	s1,260(s1) # 8001f050 <bcache+0x82b8>
    80002f54:	0001c797          	auipc	a5,0x1c
    80002f58:	0ac78793          	addi	a5,a5,172 # 8001f000 <bcache+0x8268>
    80002f5c:	02f48f63          	beq	s1,a5,80002f9a <bread+0x70>
    80002f60:	873e                	mv	a4,a5
    80002f62:	a021                	j	80002f6a <bread+0x40>
    80002f64:	68a4                	ld	s1,80(s1)
    80002f66:	02e48a63          	beq	s1,a4,80002f9a <bread+0x70>
    if(b->dev == dev && b->blockno == blockno){
    80002f6a:	449c                	lw	a5,8(s1)
    80002f6c:	ff279ce3          	bne	a5,s2,80002f64 <bread+0x3a>
    80002f70:	44dc                	lw	a5,12(s1)
    80002f72:	ff3799e3          	bne	a5,s3,80002f64 <bread+0x3a>
      b->refcnt++;
    80002f76:	40bc                	lw	a5,64(s1)
    80002f78:	2785                	addiw	a5,a5,1
    80002f7a:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002f7c:	00014517          	auipc	a0,0x14
    80002f80:	e1c50513          	addi	a0,a0,-484 # 80016d98 <bcache>
    80002f84:	ffffe097          	auipc	ra,0xffffe
    80002f88:	d04080e7          	jalr	-764(ra) # 80000c88 <release>
      acquiresleep(&b->lock);
    80002f8c:	01048513          	addi	a0,s1,16
    80002f90:	00001097          	auipc	ra,0x1
    80002f94:	472080e7          	jalr	1138(ra) # 80004402 <acquiresleep>
      return b;
    80002f98:	a8b9                	j	80002ff6 <bread+0xcc>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002f9a:	0001c497          	auipc	s1,0x1c
    80002f9e:	0ae4b483          	ld	s1,174(s1) # 8001f048 <bcache+0x82b0>
    80002fa2:	0001c797          	auipc	a5,0x1c
    80002fa6:	05e78793          	addi	a5,a5,94 # 8001f000 <bcache+0x8268>
    80002faa:	00f48863          	beq	s1,a5,80002fba <bread+0x90>
    80002fae:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80002fb0:	40bc                	lw	a5,64(s1)
    80002fb2:	cf81                	beqz	a5,80002fca <bread+0xa0>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002fb4:	64a4                	ld	s1,72(s1)
    80002fb6:	fee49de3          	bne	s1,a4,80002fb0 <bread+0x86>
  panic("bget: no buffers");
    80002fba:	00005517          	auipc	a0,0x5
    80002fbe:	55650513          	addi	a0,a0,1366 # 80008510 <syscalls+0xc0>
    80002fc2:	ffffd097          	auipc	ra,0xffffd
    80002fc6:	57c080e7          	jalr	1404(ra) # 8000053e <panic>
      b->dev = dev;
    80002fca:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002fce:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002fd2:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002fd6:	4785                	li	a5,1
    80002fd8:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002fda:	00014517          	auipc	a0,0x14
    80002fde:	dbe50513          	addi	a0,a0,-578 # 80016d98 <bcache>
    80002fe2:	ffffe097          	auipc	ra,0xffffe
    80002fe6:	ca6080e7          	jalr	-858(ra) # 80000c88 <release>
      acquiresleep(&b->lock);
    80002fea:	01048513          	addi	a0,s1,16
    80002fee:	00001097          	auipc	ra,0x1
    80002ff2:	414080e7          	jalr	1044(ra) # 80004402 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80002ff6:	409c                	lw	a5,0(s1)
    80002ff8:	cb89                	beqz	a5,8000300a <bread+0xe0>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002ffa:	8526                	mv	a0,s1
    80002ffc:	70a2                	ld	ra,40(sp)
    80002ffe:	7402                	ld	s0,32(sp)
    80003000:	64e2                	ld	s1,24(sp)
    80003002:	6942                	ld	s2,16(sp)
    80003004:	69a2                	ld	s3,8(sp)
    80003006:	6145                	addi	sp,sp,48
    80003008:	8082                	ret
    virtio_disk_rw(b, 0);
    8000300a:	4581                	li	a1,0
    8000300c:	8526                	mv	a0,s1
    8000300e:	00003097          	auipc	ra,0x3
    80003012:	fe4080e7          	jalr	-28(ra) # 80005ff2 <virtio_disk_rw>
    b->valid = 1;
    80003016:	4785                	li	a5,1
    80003018:	c09c                	sw	a5,0(s1)
  return b;
    8000301a:	b7c5                	j	80002ffa <bread+0xd0>

000000008000301c <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    8000301c:	1101                	addi	sp,sp,-32
    8000301e:	ec06                	sd	ra,24(sp)
    80003020:	e822                	sd	s0,16(sp)
    80003022:	e426                	sd	s1,8(sp)
    80003024:	1000                	addi	s0,sp,32
    80003026:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80003028:	0541                	addi	a0,a0,16
    8000302a:	00001097          	auipc	ra,0x1
    8000302e:	472080e7          	jalr	1138(ra) # 8000449c <holdingsleep>
    80003032:	cd01                	beqz	a0,8000304a <bwrite+0x2e>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80003034:	4585                	li	a1,1
    80003036:	8526                	mv	a0,s1
    80003038:	00003097          	auipc	ra,0x3
    8000303c:	fba080e7          	jalr	-70(ra) # 80005ff2 <virtio_disk_rw>
}
    80003040:	60e2                	ld	ra,24(sp)
    80003042:	6442                	ld	s0,16(sp)
    80003044:	64a2                	ld	s1,8(sp)
    80003046:	6105                	addi	sp,sp,32
    80003048:	8082                	ret
    panic("bwrite");
    8000304a:	00005517          	auipc	a0,0x5
    8000304e:	4de50513          	addi	a0,a0,1246 # 80008528 <syscalls+0xd8>
    80003052:	ffffd097          	auipc	ra,0xffffd
    80003056:	4ec080e7          	jalr	1260(ra) # 8000053e <panic>

000000008000305a <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    8000305a:	1101                	addi	sp,sp,-32
    8000305c:	ec06                	sd	ra,24(sp)
    8000305e:	e822                	sd	s0,16(sp)
    80003060:	e426                	sd	s1,8(sp)
    80003062:	e04a                	sd	s2,0(sp)
    80003064:	1000                	addi	s0,sp,32
    80003066:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80003068:	01050913          	addi	s2,a0,16
    8000306c:	854a                	mv	a0,s2
    8000306e:	00001097          	auipc	ra,0x1
    80003072:	42e080e7          	jalr	1070(ra) # 8000449c <holdingsleep>
    80003076:	c92d                	beqz	a0,800030e8 <brelse+0x8e>
    panic("brelse");

  releasesleep(&b->lock);
    80003078:	854a                	mv	a0,s2
    8000307a:	00001097          	auipc	ra,0x1
    8000307e:	3de080e7          	jalr	990(ra) # 80004458 <releasesleep>

  acquire(&bcache.lock);
    80003082:	00014517          	auipc	a0,0x14
    80003086:	d1650513          	addi	a0,a0,-746 # 80016d98 <bcache>
    8000308a:	ffffe097          	auipc	ra,0xffffe
    8000308e:	b4a080e7          	jalr	-1206(ra) # 80000bd4 <acquire>
  b->refcnt--;
    80003092:	40bc                	lw	a5,64(s1)
    80003094:	37fd                	addiw	a5,a5,-1
    80003096:	0007871b          	sext.w	a4,a5
    8000309a:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    8000309c:	eb05                	bnez	a4,800030cc <brelse+0x72>
    // no one is waiting for it.
    b->next->prev = b->prev;
    8000309e:	68bc                	ld	a5,80(s1)
    800030a0:	64b8                	ld	a4,72(s1)
    800030a2:	e7b8                	sd	a4,72(a5)
    b->prev->next = b->next;
    800030a4:	64bc                	ld	a5,72(s1)
    800030a6:	68b8                	ld	a4,80(s1)
    800030a8:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    800030aa:	0001c797          	auipc	a5,0x1c
    800030ae:	cee78793          	addi	a5,a5,-786 # 8001ed98 <bcache+0x8000>
    800030b2:	2b87b703          	ld	a4,696(a5)
    800030b6:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    800030b8:	0001c717          	auipc	a4,0x1c
    800030bc:	f4870713          	addi	a4,a4,-184 # 8001f000 <bcache+0x8268>
    800030c0:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    800030c2:	2b87b703          	ld	a4,696(a5)
    800030c6:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    800030c8:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    800030cc:	00014517          	auipc	a0,0x14
    800030d0:	ccc50513          	addi	a0,a0,-820 # 80016d98 <bcache>
    800030d4:	ffffe097          	auipc	ra,0xffffe
    800030d8:	bb4080e7          	jalr	-1100(ra) # 80000c88 <release>
}
    800030dc:	60e2                	ld	ra,24(sp)
    800030de:	6442                	ld	s0,16(sp)
    800030e0:	64a2                	ld	s1,8(sp)
    800030e2:	6902                	ld	s2,0(sp)
    800030e4:	6105                	addi	sp,sp,32
    800030e6:	8082                	ret
    panic("brelse");
    800030e8:	00005517          	auipc	a0,0x5
    800030ec:	44850513          	addi	a0,a0,1096 # 80008530 <syscalls+0xe0>
    800030f0:	ffffd097          	auipc	ra,0xffffd
    800030f4:	44e080e7          	jalr	1102(ra) # 8000053e <panic>

00000000800030f8 <bpin>:

void
bpin(struct buf *b) {
    800030f8:	1101                	addi	sp,sp,-32
    800030fa:	ec06                	sd	ra,24(sp)
    800030fc:	e822                	sd	s0,16(sp)
    800030fe:	e426                	sd	s1,8(sp)
    80003100:	1000                	addi	s0,sp,32
    80003102:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80003104:	00014517          	auipc	a0,0x14
    80003108:	c9450513          	addi	a0,a0,-876 # 80016d98 <bcache>
    8000310c:	ffffe097          	auipc	ra,0xffffe
    80003110:	ac8080e7          	jalr	-1336(ra) # 80000bd4 <acquire>
  b->refcnt++;
    80003114:	40bc                	lw	a5,64(s1)
    80003116:	2785                	addiw	a5,a5,1
    80003118:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    8000311a:	00014517          	auipc	a0,0x14
    8000311e:	c7e50513          	addi	a0,a0,-898 # 80016d98 <bcache>
    80003122:	ffffe097          	auipc	ra,0xffffe
    80003126:	b66080e7          	jalr	-1178(ra) # 80000c88 <release>
}
    8000312a:	60e2                	ld	ra,24(sp)
    8000312c:	6442                	ld	s0,16(sp)
    8000312e:	64a2                	ld	s1,8(sp)
    80003130:	6105                	addi	sp,sp,32
    80003132:	8082                	ret

0000000080003134 <bunpin>:

void
bunpin(struct buf *b) {
    80003134:	1101                	addi	sp,sp,-32
    80003136:	ec06                	sd	ra,24(sp)
    80003138:	e822                	sd	s0,16(sp)
    8000313a:	e426                	sd	s1,8(sp)
    8000313c:	1000                	addi	s0,sp,32
    8000313e:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80003140:	00014517          	auipc	a0,0x14
    80003144:	c5850513          	addi	a0,a0,-936 # 80016d98 <bcache>
    80003148:	ffffe097          	auipc	ra,0xffffe
    8000314c:	a8c080e7          	jalr	-1396(ra) # 80000bd4 <acquire>
  b->refcnt--;
    80003150:	40bc                	lw	a5,64(s1)
    80003152:	37fd                	addiw	a5,a5,-1
    80003154:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80003156:	00014517          	auipc	a0,0x14
    8000315a:	c4250513          	addi	a0,a0,-958 # 80016d98 <bcache>
    8000315e:	ffffe097          	auipc	ra,0xffffe
    80003162:	b2a080e7          	jalr	-1238(ra) # 80000c88 <release>
}
    80003166:	60e2                	ld	ra,24(sp)
    80003168:	6442                	ld	s0,16(sp)
    8000316a:	64a2                	ld	s1,8(sp)
    8000316c:	6105                	addi	sp,sp,32
    8000316e:	8082                	ret

0000000080003170 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80003170:	1101                	addi	sp,sp,-32
    80003172:	ec06                	sd	ra,24(sp)
    80003174:	e822                	sd	s0,16(sp)
    80003176:	e426                	sd	s1,8(sp)
    80003178:	e04a                	sd	s2,0(sp)
    8000317a:	1000                	addi	s0,sp,32
    8000317c:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    8000317e:	00d5d59b          	srliw	a1,a1,0xd
    80003182:	0001c797          	auipc	a5,0x1c
    80003186:	2f27a783          	lw	a5,754(a5) # 8001f474 <sb+0x1c>
    8000318a:	9dbd                	addw	a1,a1,a5
    8000318c:	00000097          	auipc	ra,0x0
    80003190:	d9e080e7          	jalr	-610(ra) # 80002f2a <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80003194:	0074f713          	andi	a4,s1,7
    80003198:	4785                	li	a5,1
    8000319a:	00e797bb          	sllw	a5,a5,a4
  if((bp->data[bi/8] & m) == 0)
    8000319e:	14ce                	slli	s1,s1,0x33
    800031a0:	90d9                	srli	s1,s1,0x36
    800031a2:	00950733          	add	a4,a0,s1
    800031a6:	05874703          	lbu	a4,88(a4)
    800031aa:	00e7f6b3          	and	a3,a5,a4
    800031ae:	c69d                	beqz	a3,800031dc <bfree+0x6c>
    800031b0:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    800031b2:	94aa                	add	s1,s1,a0
    800031b4:	fff7c793          	not	a5,a5
    800031b8:	8f7d                	and	a4,a4,a5
    800031ba:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    800031be:	00001097          	auipc	ra,0x1
    800031c2:	126080e7          	jalr	294(ra) # 800042e4 <log_write>
  brelse(bp);
    800031c6:	854a                	mv	a0,s2
    800031c8:	00000097          	auipc	ra,0x0
    800031cc:	e92080e7          	jalr	-366(ra) # 8000305a <brelse>
}
    800031d0:	60e2                	ld	ra,24(sp)
    800031d2:	6442                	ld	s0,16(sp)
    800031d4:	64a2                	ld	s1,8(sp)
    800031d6:	6902                	ld	s2,0(sp)
    800031d8:	6105                	addi	sp,sp,32
    800031da:	8082                	ret
    panic("freeing free block");
    800031dc:	00005517          	auipc	a0,0x5
    800031e0:	35c50513          	addi	a0,a0,860 # 80008538 <syscalls+0xe8>
    800031e4:	ffffd097          	auipc	ra,0xffffd
    800031e8:	35a080e7          	jalr	858(ra) # 8000053e <panic>

00000000800031ec <balloc>:
{
    800031ec:	711d                	addi	sp,sp,-96
    800031ee:	ec86                	sd	ra,88(sp)
    800031f0:	e8a2                	sd	s0,80(sp)
    800031f2:	e4a6                	sd	s1,72(sp)
    800031f4:	e0ca                	sd	s2,64(sp)
    800031f6:	fc4e                	sd	s3,56(sp)
    800031f8:	f852                	sd	s4,48(sp)
    800031fa:	f456                	sd	s5,40(sp)
    800031fc:	f05a                	sd	s6,32(sp)
    800031fe:	ec5e                	sd	s7,24(sp)
    80003200:	e862                	sd	s8,16(sp)
    80003202:	e466                	sd	s9,8(sp)
    80003204:	1080                	addi	s0,sp,96
  for(b = 0; b < sb.size; b += BPB){
    80003206:	0001c797          	auipc	a5,0x1c
    8000320a:	2567a783          	lw	a5,598(a5) # 8001f45c <sb+0x4>
    8000320e:	cff5                	beqz	a5,8000330a <balloc+0x11e>
    80003210:	8baa                	mv	s7,a0
    80003212:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80003214:	0001cb17          	auipc	s6,0x1c
    80003218:	244b0b13          	addi	s6,s6,580 # 8001f458 <sb>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    8000321c:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    8000321e:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003220:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80003222:	6c89                	lui	s9,0x2
    80003224:	a061                	j	800032ac <balloc+0xc0>
        bp->data[bi/8] |= m;  // Mark block in use.
    80003226:	97ca                	add	a5,a5,s2
    80003228:	8e55                	or	a2,a2,a3
    8000322a:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    8000322e:	854a                	mv	a0,s2
    80003230:	00001097          	auipc	ra,0x1
    80003234:	0b4080e7          	jalr	180(ra) # 800042e4 <log_write>
        brelse(bp);
    80003238:	854a                	mv	a0,s2
    8000323a:	00000097          	auipc	ra,0x0
    8000323e:	e20080e7          	jalr	-480(ra) # 8000305a <brelse>
  bp = bread(dev, bno);
    80003242:	85a6                	mv	a1,s1
    80003244:	855e                	mv	a0,s7
    80003246:	00000097          	auipc	ra,0x0
    8000324a:	ce4080e7          	jalr	-796(ra) # 80002f2a <bread>
    8000324e:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80003250:	40000613          	li	a2,1024
    80003254:	4581                	li	a1,0
    80003256:	05850513          	addi	a0,a0,88
    8000325a:	ffffe097          	auipc	ra,0xffffe
    8000325e:	a76080e7          	jalr	-1418(ra) # 80000cd0 <memset>
  log_write(bp);
    80003262:	854a                	mv	a0,s2
    80003264:	00001097          	auipc	ra,0x1
    80003268:	080080e7          	jalr	128(ra) # 800042e4 <log_write>
  brelse(bp);
    8000326c:	854a                	mv	a0,s2
    8000326e:	00000097          	auipc	ra,0x0
    80003272:	dec080e7          	jalr	-532(ra) # 8000305a <brelse>
}
    80003276:	8526                	mv	a0,s1
    80003278:	60e6                	ld	ra,88(sp)
    8000327a:	6446                	ld	s0,80(sp)
    8000327c:	64a6                	ld	s1,72(sp)
    8000327e:	6906                	ld	s2,64(sp)
    80003280:	79e2                	ld	s3,56(sp)
    80003282:	7a42                	ld	s4,48(sp)
    80003284:	7aa2                	ld	s5,40(sp)
    80003286:	7b02                	ld	s6,32(sp)
    80003288:	6be2                	ld	s7,24(sp)
    8000328a:	6c42                	ld	s8,16(sp)
    8000328c:	6ca2                	ld	s9,8(sp)
    8000328e:	6125                	addi	sp,sp,96
    80003290:	8082                	ret
    brelse(bp);
    80003292:	854a                	mv	a0,s2
    80003294:	00000097          	auipc	ra,0x0
    80003298:	dc6080e7          	jalr	-570(ra) # 8000305a <brelse>
  for(b = 0; b < sb.size; b += BPB){
    8000329c:	015c87bb          	addw	a5,s9,s5
    800032a0:	00078a9b          	sext.w	s5,a5
    800032a4:	004b2703          	lw	a4,4(s6)
    800032a8:	06eaf163          	bgeu	s5,a4,8000330a <balloc+0x11e>
    bp = bread(dev, BBLOCK(b, sb));
    800032ac:	41fad79b          	sraiw	a5,s5,0x1f
    800032b0:	0137d79b          	srliw	a5,a5,0x13
    800032b4:	015787bb          	addw	a5,a5,s5
    800032b8:	40d7d79b          	sraiw	a5,a5,0xd
    800032bc:	01cb2583          	lw	a1,28(s6)
    800032c0:	9dbd                	addw	a1,a1,a5
    800032c2:	855e                	mv	a0,s7
    800032c4:	00000097          	auipc	ra,0x0
    800032c8:	c66080e7          	jalr	-922(ra) # 80002f2a <bread>
    800032cc:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800032ce:	004b2503          	lw	a0,4(s6)
    800032d2:	000a849b          	sext.w	s1,s5
    800032d6:	8762                	mv	a4,s8
    800032d8:	faa4fde3          	bgeu	s1,a0,80003292 <balloc+0xa6>
      m = 1 << (bi % 8);
    800032dc:	00777693          	andi	a3,a4,7
    800032e0:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    800032e4:	41f7579b          	sraiw	a5,a4,0x1f
    800032e8:	01d7d79b          	srliw	a5,a5,0x1d
    800032ec:	9fb9                	addw	a5,a5,a4
    800032ee:	4037d79b          	sraiw	a5,a5,0x3
    800032f2:	00f90633          	add	a2,s2,a5
    800032f6:	05864603          	lbu	a2,88(a2)
    800032fa:	00c6f5b3          	and	a1,a3,a2
    800032fe:	d585                	beqz	a1,80003226 <balloc+0x3a>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003300:	2705                	addiw	a4,a4,1
    80003302:	2485                	addiw	s1,s1,1
    80003304:	fd471ae3          	bne	a4,s4,800032d8 <balloc+0xec>
    80003308:	b769                	j	80003292 <balloc+0xa6>
  printf("balloc: out of blocks\n");
    8000330a:	00005517          	auipc	a0,0x5
    8000330e:	24650513          	addi	a0,a0,582 # 80008550 <syscalls+0x100>
    80003312:	ffffd097          	auipc	ra,0xffffd
    80003316:	276080e7          	jalr	630(ra) # 80000588 <printf>
  return 0;
    8000331a:	4481                	li	s1,0
    8000331c:	bfa9                	j	80003276 <balloc+0x8a>

000000008000331e <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    8000331e:	7179                	addi	sp,sp,-48
    80003320:	f406                	sd	ra,40(sp)
    80003322:	f022                	sd	s0,32(sp)
    80003324:	ec26                	sd	s1,24(sp)
    80003326:	e84a                	sd	s2,16(sp)
    80003328:	e44e                	sd	s3,8(sp)
    8000332a:	e052                	sd	s4,0(sp)
    8000332c:	1800                	addi	s0,sp,48
    8000332e:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    80003330:	47ad                	li	a5,11
    80003332:	02b7e863          	bltu	a5,a1,80003362 <bmap+0x44>
    if((addr = ip->addrs[bn]) == 0){
    80003336:	02059793          	slli	a5,a1,0x20
    8000333a:	01e7d593          	srli	a1,a5,0x1e
    8000333e:	00b504b3          	add	s1,a0,a1
    80003342:	0504a903          	lw	s2,80(s1)
    80003346:	06091e63          	bnez	s2,800033c2 <bmap+0xa4>
      addr = balloc(ip->dev);
    8000334a:	4108                	lw	a0,0(a0)
    8000334c:	00000097          	auipc	ra,0x0
    80003350:	ea0080e7          	jalr	-352(ra) # 800031ec <balloc>
    80003354:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    80003358:	06090563          	beqz	s2,800033c2 <bmap+0xa4>
        return 0;
      ip->addrs[bn] = addr;
    8000335c:	0524a823          	sw	s2,80(s1)
    80003360:	a08d                	j	800033c2 <bmap+0xa4>
    }
    return addr;
  }
  bn -= NDIRECT;
    80003362:	ff45849b          	addiw	s1,a1,-12
    80003366:	0004871b          	sext.w	a4,s1

  if(bn < NINDIRECT){
    8000336a:	0ff00793          	li	a5,255
    8000336e:	08e7e563          	bltu	a5,a4,800033f8 <bmap+0xda>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    80003372:	08052903          	lw	s2,128(a0)
    80003376:	00091d63          	bnez	s2,80003390 <bmap+0x72>
      addr = balloc(ip->dev);
    8000337a:	4108                	lw	a0,0(a0)
    8000337c:	00000097          	auipc	ra,0x0
    80003380:	e70080e7          	jalr	-400(ra) # 800031ec <balloc>
    80003384:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    80003388:	02090d63          	beqz	s2,800033c2 <bmap+0xa4>
        return 0;
      ip->addrs[NDIRECT] = addr;
    8000338c:	0929a023          	sw	s2,128(s3)
    }
    bp = bread(ip->dev, addr);
    80003390:	85ca                	mv	a1,s2
    80003392:	0009a503          	lw	a0,0(s3)
    80003396:	00000097          	auipc	ra,0x0
    8000339a:	b94080e7          	jalr	-1132(ra) # 80002f2a <bread>
    8000339e:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    800033a0:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    800033a4:	02049713          	slli	a4,s1,0x20
    800033a8:	01e75593          	srli	a1,a4,0x1e
    800033ac:	00b784b3          	add	s1,a5,a1
    800033b0:	0004a903          	lw	s2,0(s1)
    800033b4:	02090063          	beqz	s2,800033d4 <bmap+0xb6>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    800033b8:	8552                	mv	a0,s4
    800033ba:	00000097          	auipc	ra,0x0
    800033be:	ca0080e7          	jalr	-864(ra) # 8000305a <brelse>
    return addr;
  }

  panic("bmap: out of range");
}
    800033c2:	854a                	mv	a0,s2
    800033c4:	70a2                	ld	ra,40(sp)
    800033c6:	7402                	ld	s0,32(sp)
    800033c8:	64e2                	ld	s1,24(sp)
    800033ca:	6942                	ld	s2,16(sp)
    800033cc:	69a2                	ld	s3,8(sp)
    800033ce:	6a02                	ld	s4,0(sp)
    800033d0:	6145                	addi	sp,sp,48
    800033d2:	8082                	ret
      addr = balloc(ip->dev);
    800033d4:	0009a503          	lw	a0,0(s3)
    800033d8:	00000097          	auipc	ra,0x0
    800033dc:	e14080e7          	jalr	-492(ra) # 800031ec <balloc>
    800033e0:	0005091b          	sext.w	s2,a0
      if(addr){
    800033e4:	fc090ae3          	beqz	s2,800033b8 <bmap+0x9a>
        a[bn] = addr;
    800033e8:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    800033ec:	8552                	mv	a0,s4
    800033ee:	00001097          	auipc	ra,0x1
    800033f2:	ef6080e7          	jalr	-266(ra) # 800042e4 <log_write>
    800033f6:	b7c9                	j	800033b8 <bmap+0x9a>
  panic("bmap: out of range");
    800033f8:	00005517          	auipc	a0,0x5
    800033fc:	17050513          	addi	a0,a0,368 # 80008568 <syscalls+0x118>
    80003400:	ffffd097          	auipc	ra,0xffffd
    80003404:	13e080e7          	jalr	318(ra) # 8000053e <panic>

0000000080003408 <iget>:
{
    80003408:	7179                	addi	sp,sp,-48
    8000340a:	f406                	sd	ra,40(sp)
    8000340c:	f022                	sd	s0,32(sp)
    8000340e:	ec26                	sd	s1,24(sp)
    80003410:	e84a                	sd	s2,16(sp)
    80003412:	e44e                	sd	s3,8(sp)
    80003414:	e052                	sd	s4,0(sp)
    80003416:	1800                	addi	s0,sp,48
    80003418:	89aa                	mv	s3,a0
    8000341a:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    8000341c:	0001c517          	auipc	a0,0x1c
    80003420:	05c50513          	addi	a0,a0,92 # 8001f478 <itable>
    80003424:	ffffd097          	auipc	ra,0xffffd
    80003428:	7b0080e7          	jalr	1968(ra) # 80000bd4 <acquire>
  empty = 0;
    8000342c:	4901                	li	s2,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    8000342e:	0001c497          	auipc	s1,0x1c
    80003432:	06248493          	addi	s1,s1,98 # 8001f490 <itable+0x18>
    80003436:	0001e697          	auipc	a3,0x1e
    8000343a:	aea68693          	addi	a3,a3,-1302 # 80020f20 <log>
    8000343e:	a039                	j	8000344c <iget+0x44>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80003440:	02090b63          	beqz	s2,80003476 <iget+0x6e>
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80003444:	08848493          	addi	s1,s1,136
    80003448:	02d48a63          	beq	s1,a3,8000347c <iget+0x74>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    8000344c:	449c                	lw	a5,8(s1)
    8000344e:	fef059e3          	blez	a5,80003440 <iget+0x38>
    80003452:	4098                	lw	a4,0(s1)
    80003454:	ff3716e3          	bne	a4,s3,80003440 <iget+0x38>
    80003458:	40d8                	lw	a4,4(s1)
    8000345a:	ff4713e3          	bne	a4,s4,80003440 <iget+0x38>
      ip->ref++;
    8000345e:	2785                	addiw	a5,a5,1
    80003460:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80003462:	0001c517          	auipc	a0,0x1c
    80003466:	01650513          	addi	a0,a0,22 # 8001f478 <itable>
    8000346a:	ffffe097          	auipc	ra,0xffffe
    8000346e:	81e080e7          	jalr	-2018(ra) # 80000c88 <release>
      return ip;
    80003472:	8926                	mv	s2,s1
    80003474:	a03d                	j	800034a2 <iget+0x9a>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80003476:	f7f9                	bnez	a5,80003444 <iget+0x3c>
    80003478:	8926                	mv	s2,s1
    8000347a:	b7e9                	j	80003444 <iget+0x3c>
  if(empty == 0)
    8000347c:	02090c63          	beqz	s2,800034b4 <iget+0xac>
  ip->dev = dev;
    80003480:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    80003484:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    80003488:	4785                	li	a5,1
    8000348a:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    8000348e:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    80003492:	0001c517          	auipc	a0,0x1c
    80003496:	fe650513          	addi	a0,a0,-26 # 8001f478 <itable>
    8000349a:	ffffd097          	auipc	ra,0xffffd
    8000349e:	7ee080e7          	jalr	2030(ra) # 80000c88 <release>
}
    800034a2:	854a                	mv	a0,s2
    800034a4:	70a2                	ld	ra,40(sp)
    800034a6:	7402                	ld	s0,32(sp)
    800034a8:	64e2                	ld	s1,24(sp)
    800034aa:	6942                	ld	s2,16(sp)
    800034ac:	69a2                	ld	s3,8(sp)
    800034ae:	6a02                	ld	s4,0(sp)
    800034b0:	6145                	addi	sp,sp,48
    800034b2:	8082                	ret
    panic("iget: no inodes");
    800034b4:	00005517          	auipc	a0,0x5
    800034b8:	0cc50513          	addi	a0,a0,204 # 80008580 <syscalls+0x130>
    800034bc:	ffffd097          	auipc	ra,0xffffd
    800034c0:	082080e7          	jalr	130(ra) # 8000053e <panic>

00000000800034c4 <fsinit>:
fsinit(int dev) {
    800034c4:	7179                	addi	sp,sp,-48
    800034c6:	f406                	sd	ra,40(sp)
    800034c8:	f022                	sd	s0,32(sp)
    800034ca:	ec26                	sd	s1,24(sp)
    800034cc:	e84a                	sd	s2,16(sp)
    800034ce:	e44e                	sd	s3,8(sp)
    800034d0:	1800                	addi	s0,sp,48
    800034d2:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    800034d4:	4585                	li	a1,1
    800034d6:	00000097          	auipc	ra,0x0
    800034da:	a54080e7          	jalr	-1452(ra) # 80002f2a <bread>
    800034de:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    800034e0:	0001c997          	auipc	s3,0x1c
    800034e4:	f7898993          	addi	s3,s3,-136 # 8001f458 <sb>
    800034e8:	02000613          	li	a2,32
    800034ec:	05850593          	addi	a1,a0,88
    800034f0:	854e                	mv	a0,s3
    800034f2:	ffffe097          	auipc	ra,0xffffe
    800034f6:	83a080e7          	jalr	-1990(ra) # 80000d2c <memmove>
  brelse(bp);
    800034fa:	8526                	mv	a0,s1
    800034fc:	00000097          	auipc	ra,0x0
    80003500:	b5e080e7          	jalr	-1186(ra) # 8000305a <brelse>
  if(sb.magic != FSMAGIC)
    80003504:	0009a703          	lw	a4,0(s3)
    80003508:	102037b7          	lui	a5,0x10203
    8000350c:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80003510:	02f71263          	bne	a4,a5,80003534 <fsinit+0x70>
  initlog(dev, &sb);
    80003514:	0001c597          	auipc	a1,0x1c
    80003518:	f4458593          	addi	a1,a1,-188 # 8001f458 <sb>
    8000351c:	854a                	mv	a0,s2
    8000351e:	00001097          	auipc	ra,0x1
    80003522:	b4a080e7          	jalr	-1206(ra) # 80004068 <initlog>
}
    80003526:	70a2                	ld	ra,40(sp)
    80003528:	7402                	ld	s0,32(sp)
    8000352a:	64e2                	ld	s1,24(sp)
    8000352c:	6942                	ld	s2,16(sp)
    8000352e:	69a2                	ld	s3,8(sp)
    80003530:	6145                	addi	sp,sp,48
    80003532:	8082                	ret
    panic("invalid file system");
    80003534:	00005517          	auipc	a0,0x5
    80003538:	05c50513          	addi	a0,a0,92 # 80008590 <syscalls+0x140>
    8000353c:	ffffd097          	auipc	ra,0xffffd
    80003540:	002080e7          	jalr	2(ra) # 8000053e <panic>

0000000080003544 <iinit>:
{
    80003544:	7179                	addi	sp,sp,-48
    80003546:	f406                	sd	ra,40(sp)
    80003548:	f022                	sd	s0,32(sp)
    8000354a:	ec26                	sd	s1,24(sp)
    8000354c:	e84a                	sd	s2,16(sp)
    8000354e:	e44e                	sd	s3,8(sp)
    80003550:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    80003552:	00005597          	auipc	a1,0x5
    80003556:	05658593          	addi	a1,a1,86 # 800085a8 <syscalls+0x158>
    8000355a:	0001c517          	auipc	a0,0x1c
    8000355e:	f1e50513          	addi	a0,a0,-226 # 8001f478 <itable>
    80003562:	ffffd097          	auipc	ra,0xffffd
    80003566:	5e2080e7          	jalr	1506(ra) # 80000b44 <initlock>
  for(i = 0; i < NINODE; i++) {
    8000356a:	0001c497          	auipc	s1,0x1c
    8000356e:	f3648493          	addi	s1,s1,-202 # 8001f4a0 <itable+0x28>
    80003572:	0001e997          	auipc	s3,0x1e
    80003576:	9be98993          	addi	s3,s3,-1602 # 80020f30 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    8000357a:	00005917          	auipc	s2,0x5
    8000357e:	03690913          	addi	s2,s2,54 # 800085b0 <syscalls+0x160>
    80003582:	85ca                	mv	a1,s2
    80003584:	8526                	mv	a0,s1
    80003586:	00001097          	auipc	ra,0x1
    8000358a:	e42080e7          	jalr	-446(ra) # 800043c8 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    8000358e:	08848493          	addi	s1,s1,136
    80003592:	ff3498e3          	bne	s1,s3,80003582 <iinit+0x3e>
}
    80003596:	70a2                	ld	ra,40(sp)
    80003598:	7402                	ld	s0,32(sp)
    8000359a:	64e2                	ld	s1,24(sp)
    8000359c:	6942                	ld	s2,16(sp)
    8000359e:	69a2                	ld	s3,8(sp)
    800035a0:	6145                	addi	sp,sp,48
    800035a2:	8082                	ret

00000000800035a4 <ialloc>:
{
    800035a4:	715d                	addi	sp,sp,-80
    800035a6:	e486                	sd	ra,72(sp)
    800035a8:	e0a2                	sd	s0,64(sp)
    800035aa:	fc26                	sd	s1,56(sp)
    800035ac:	f84a                	sd	s2,48(sp)
    800035ae:	f44e                	sd	s3,40(sp)
    800035b0:	f052                	sd	s4,32(sp)
    800035b2:	ec56                	sd	s5,24(sp)
    800035b4:	e85a                	sd	s6,16(sp)
    800035b6:	e45e                	sd	s7,8(sp)
    800035b8:	0880                	addi	s0,sp,80
  for(inum = 1; inum < sb.ninodes; inum++){
    800035ba:	0001c717          	auipc	a4,0x1c
    800035be:	eaa72703          	lw	a4,-342(a4) # 8001f464 <sb+0xc>
    800035c2:	4785                	li	a5,1
    800035c4:	04e7fa63          	bgeu	a5,a4,80003618 <ialloc+0x74>
    800035c8:	8aaa                	mv	s5,a0
    800035ca:	8bae                	mv	s7,a1
    800035cc:	4485                	li	s1,1
    bp = bread(dev, IBLOCK(inum, sb));
    800035ce:	0001ca17          	auipc	s4,0x1c
    800035d2:	e8aa0a13          	addi	s4,s4,-374 # 8001f458 <sb>
    800035d6:	00048b1b          	sext.w	s6,s1
    800035da:	0044d593          	srli	a1,s1,0x4
    800035de:	018a2783          	lw	a5,24(s4)
    800035e2:	9dbd                	addw	a1,a1,a5
    800035e4:	8556                	mv	a0,s5
    800035e6:	00000097          	auipc	ra,0x0
    800035ea:	944080e7          	jalr	-1724(ra) # 80002f2a <bread>
    800035ee:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    800035f0:	05850993          	addi	s3,a0,88
    800035f4:	00f4f793          	andi	a5,s1,15
    800035f8:	079a                	slli	a5,a5,0x6
    800035fa:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    800035fc:	00099783          	lh	a5,0(s3)
    80003600:	c3a1                	beqz	a5,80003640 <ialloc+0x9c>
    brelse(bp);
    80003602:	00000097          	auipc	ra,0x0
    80003606:	a58080e7          	jalr	-1448(ra) # 8000305a <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    8000360a:	0485                	addi	s1,s1,1
    8000360c:	00ca2703          	lw	a4,12(s4)
    80003610:	0004879b          	sext.w	a5,s1
    80003614:	fce7e1e3          	bltu	a5,a4,800035d6 <ialloc+0x32>
  printf("ialloc: no inodes\n");
    80003618:	00005517          	auipc	a0,0x5
    8000361c:	fa050513          	addi	a0,a0,-96 # 800085b8 <syscalls+0x168>
    80003620:	ffffd097          	auipc	ra,0xffffd
    80003624:	f68080e7          	jalr	-152(ra) # 80000588 <printf>
  return 0;
    80003628:	4501                	li	a0,0
}
    8000362a:	60a6                	ld	ra,72(sp)
    8000362c:	6406                	ld	s0,64(sp)
    8000362e:	74e2                	ld	s1,56(sp)
    80003630:	7942                	ld	s2,48(sp)
    80003632:	79a2                	ld	s3,40(sp)
    80003634:	7a02                	ld	s4,32(sp)
    80003636:	6ae2                	ld	s5,24(sp)
    80003638:	6b42                	ld	s6,16(sp)
    8000363a:	6ba2                	ld	s7,8(sp)
    8000363c:	6161                	addi	sp,sp,80
    8000363e:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80003640:	04000613          	li	a2,64
    80003644:	4581                	li	a1,0
    80003646:	854e                	mv	a0,s3
    80003648:	ffffd097          	auipc	ra,0xffffd
    8000364c:	688080e7          	jalr	1672(ra) # 80000cd0 <memset>
      dip->type = type;
    80003650:	01799023          	sh	s7,0(s3)
      log_write(bp);   // mark it allocated on the disk
    80003654:	854a                	mv	a0,s2
    80003656:	00001097          	auipc	ra,0x1
    8000365a:	c8e080e7          	jalr	-882(ra) # 800042e4 <log_write>
      brelse(bp);
    8000365e:	854a                	mv	a0,s2
    80003660:	00000097          	auipc	ra,0x0
    80003664:	9fa080e7          	jalr	-1542(ra) # 8000305a <brelse>
      return iget(dev, inum);
    80003668:	85da                	mv	a1,s6
    8000366a:	8556                	mv	a0,s5
    8000366c:	00000097          	auipc	ra,0x0
    80003670:	d9c080e7          	jalr	-612(ra) # 80003408 <iget>
    80003674:	bf5d                	j	8000362a <ialloc+0x86>

0000000080003676 <iupdate>:
{
    80003676:	1101                	addi	sp,sp,-32
    80003678:	ec06                	sd	ra,24(sp)
    8000367a:	e822                	sd	s0,16(sp)
    8000367c:	e426                	sd	s1,8(sp)
    8000367e:	e04a                	sd	s2,0(sp)
    80003680:	1000                	addi	s0,sp,32
    80003682:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003684:	415c                	lw	a5,4(a0)
    80003686:	0047d79b          	srliw	a5,a5,0x4
    8000368a:	0001c597          	auipc	a1,0x1c
    8000368e:	de65a583          	lw	a1,-538(a1) # 8001f470 <sb+0x18>
    80003692:	9dbd                	addw	a1,a1,a5
    80003694:	4108                	lw	a0,0(a0)
    80003696:	00000097          	auipc	ra,0x0
    8000369a:	894080e7          	jalr	-1900(ra) # 80002f2a <bread>
    8000369e:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    800036a0:	05850793          	addi	a5,a0,88
    800036a4:	40d8                	lw	a4,4(s1)
    800036a6:	8b3d                	andi	a4,a4,15
    800036a8:	071a                	slli	a4,a4,0x6
    800036aa:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    800036ac:	04449703          	lh	a4,68(s1)
    800036b0:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    800036b4:	04649703          	lh	a4,70(s1)
    800036b8:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    800036bc:	04849703          	lh	a4,72(s1)
    800036c0:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    800036c4:	04a49703          	lh	a4,74(s1)
    800036c8:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    800036cc:	44f8                	lw	a4,76(s1)
    800036ce:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    800036d0:	03400613          	li	a2,52
    800036d4:	05048593          	addi	a1,s1,80
    800036d8:	00c78513          	addi	a0,a5,12
    800036dc:	ffffd097          	auipc	ra,0xffffd
    800036e0:	650080e7          	jalr	1616(ra) # 80000d2c <memmove>
  log_write(bp);
    800036e4:	854a                	mv	a0,s2
    800036e6:	00001097          	auipc	ra,0x1
    800036ea:	bfe080e7          	jalr	-1026(ra) # 800042e4 <log_write>
  brelse(bp);
    800036ee:	854a                	mv	a0,s2
    800036f0:	00000097          	auipc	ra,0x0
    800036f4:	96a080e7          	jalr	-1686(ra) # 8000305a <brelse>
}
    800036f8:	60e2                	ld	ra,24(sp)
    800036fa:	6442                	ld	s0,16(sp)
    800036fc:	64a2                	ld	s1,8(sp)
    800036fe:	6902                	ld	s2,0(sp)
    80003700:	6105                	addi	sp,sp,32
    80003702:	8082                	ret

0000000080003704 <idup>:
{
    80003704:	1101                	addi	sp,sp,-32
    80003706:	ec06                	sd	ra,24(sp)
    80003708:	e822                	sd	s0,16(sp)
    8000370a:	e426                	sd	s1,8(sp)
    8000370c:	1000                	addi	s0,sp,32
    8000370e:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003710:	0001c517          	auipc	a0,0x1c
    80003714:	d6850513          	addi	a0,a0,-664 # 8001f478 <itable>
    80003718:	ffffd097          	auipc	ra,0xffffd
    8000371c:	4bc080e7          	jalr	1212(ra) # 80000bd4 <acquire>
  ip->ref++;
    80003720:	449c                	lw	a5,8(s1)
    80003722:	2785                	addiw	a5,a5,1
    80003724:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003726:	0001c517          	auipc	a0,0x1c
    8000372a:	d5250513          	addi	a0,a0,-686 # 8001f478 <itable>
    8000372e:	ffffd097          	auipc	ra,0xffffd
    80003732:	55a080e7          	jalr	1370(ra) # 80000c88 <release>
}
    80003736:	8526                	mv	a0,s1
    80003738:	60e2                	ld	ra,24(sp)
    8000373a:	6442                	ld	s0,16(sp)
    8000373c:	64a2                	ld	s1,8(sp)
    8000373e:	6105                	addi	sp,sp,32
    80003740:	8082                	ret

0000000080003742 <ilock>:
{
    80003742:	1101                	addi	sp,sp,-32
    80003744:	ec06                	sd	ra,24(sp)
    80003746:	e822                	sd	s0,16(sp)
    80003748:	e426                	sd	s1,8(sp)
    8000374a:	e04a                	sd	s2,0(sp)
    8000374c:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    8000374e:	c115                	beqz	a0,80003772 <ilock+0x30>
    80003750:	84aa                	mv	s1,a0
    80003752:	451c                	lw	a5,8(a0)
    80003754:	00f05f63          	blez	a5,80003772 <ilock+0x30>
  acquiresleep(&ip->lock);
    80003758:	0541                	addi	a0,a0,16
    8000375a:	00001097          	auipc	ra,0x1
    8000375e:	ca8080e7          	jalr	-856(ra) # 80004402 <acquiresleep>
  if(ip->valid == 0){
    80003762:	40bc                	lw	a5,64(s1)
    80003764:	cf99                	beqz	a5,80003782 <ilock+0x40>
}
    80003766:	60e2                	ld	ra,24(sp)
    80003768:	6442                	ld	s0,16(sp)
    8000376a:	64a2                	ld	s1,8(sp)
    8000376c:	6902                	ld	s2,0(sp)
    8000376e:	6105                	addi	sp,sp,32
    80003770:	8082                	ret
    panic("ilock");
    80003772:	00005517          	auipc	a0,0x5
    80003776:	e5e50513          	addi	a0,a0,-418 # 800085d0 <syscalls+0x180>
    8000377a:	ffffd097          	auipc	ra,0xffffd
    8000377e:	dc4080e7          	jalr	-572(ra) # 8000053e <panic>
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003782:	40dc                	lw	a5,4(s1)
    80003784:	0047d79b          	srliw	a5,a5,0x4
    80003788:	0001c597          	auipc	a1,0x1c
    8000378c:	ce85a583          	lw	a1,-792(a1) # 8001f470 <sb+0x18>
    80003790:	9dbd                	addw	a1,a1,a5
    80003792:	4088                	lw	a0,0(s1)
    80003794:	fffff097          	auipc	ra,0xfffff
    80003798:	796080e7          	jalr	1942(ra) # 80002f2a <bread>
    8000379c:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000379e:	05850593          	addi	a1,a0,88
    800037a2:	40dc                	lw	a5,4(s1)
    800037a4:	8bbd                	andi	a5,a5,15
    800037a6:	079a                	slli	a5,a5,0x6
    800037a8:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    800037aa:	00059783          	lh	a5,0(a1)
    800037ae:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    800037b2:	00259783          	lh	a5,2(a1)
    800037b6:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    800037ba:	00459783          	lh	a5,4(a1)
    800037be:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    800037c2:	00659783          	lh	a5,6(a1)
    800037c6:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    800037ca:	459c                	lw	a5,8(a1)
    800037cc:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    800037ce:	03400613          	li	a2,52
    800037d2:	05b1                	addi	a1,a1,12
    800037d4:	05048513          	addi	a0,s1,80
    800037d8:	ffffd097          	auipc	ra,0xffffd
    800037dc:	554080e7          	jalr	1364(ra) # 80000d2c <memmove>
    brelse(bp);
    800037e0:	854a                	mv	a0,s2
    800037e2:	00000097          	auipc	ra,0x0
    800037e6:	878080e7          	jalr	-1928(ra) # 8000305a <brelse>
    ip->valid = 1;
    800037ea:	4785                	li	a5,1
    800037ec:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    800037ee:	04449783          	lh	a5,68(s1)
    800037f2:	fbb5                	bnez	a5,80003766 <ilock+0x24>
      panic("ilock: no type");
    800037f4:	00005517          	auipc	a0,0x5
    800037f8:	de450513          	addi	a0,a0,-540 # 800085d8 <syscalls+0x188>
    800037fc:	ffffd097          	auipc	ra,0xffffd
    80003800:	d42080e7          	jalr	-702(ra) # 8000053e <panic>

0000000080003804 <iunlock>:
{
    80003804:	1101                	addi	sp,sp,-32
    80003806:	ec06                	sd	ra,24(sp)
    80003808:	e822                	sd	s0,16(sp)
    8000380a:	e426                	sd	s1,8(sp)
    8000380c:	e04a                	sd	s2,0(sp)
    8000380e:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    80003810:	c905                	beqz	a0,80003840 <iunlock+0x3c>
    80003812:	84aa                	mv	s1,a0
    80003814:	01050913          	addi	s2,a0,16
    80003818:	854a                	mv	a0,s2
    8000381a:	00001097          	auipc	ra,0x1
    8000381e:	c82080e7          	jalr	-894(ra) # 8000449c <holdingsleep>
    80003822:	cd19                	beqz	a0,80003840 <iunlock+0x3c>
    80003824:	449c                	lw	a5,8(s1)
    80003826:	00f05d63          	blez	a5,80003840 <iunlock+0x3c>
  releasesleep(&ip->lock);
    8000382a:	854a                	mv	a0,s2
    8000382c:	00001097          	auipc	ra,0x1
    80003830:	c2c080e7          	jalr	-980(ra) # 80004458 <releasesleep>
}
    80003834:	60e2                	ld	ra,24(sp)
    80003836:	6442                	ld	s0,16(sp)
    80003838:	64a2                	ld	s1,8(sp)
    8000383a:	6902                	ld	s2,0(sp)
    8000383c:	6105                	addi	sp,sp,32
    8000383e:	8082                	ret
    panic("iunlock");
    80003840:	00005517          	auipc	a0,0x5
    80003844:	da850513          	addi	a0,a0,-600 # 800085e8 <syscalls+0x198>
    80003848:	ffffd097          	auipc	ra,0xffffd
    8000384c:	cf6080e7          	jalr	-778(ra) # 8000053e <panic>

0000000080003850 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    80003850:	7179                	addi	sp,sp,-48
    80003852:	f406                	sd	ra,40(sp)
    80003854:	f022                	sd	s0,32(sp)
    80003856:	ec26                	sd	s1,24(sp)
    80003858:	e84a                	sd	s2,16(sp)
    8000385a:	e44e                	sd	s3,8(sp)
    8000385c:	e052                	sd	s4,0(sp)
    8000385e:	1800                	addi	s0,sp,48
    80003860:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    80003862:	05050493          	addi	s1,a0,80
    80003866:	08050913          	addi	s2,a0,128
    8000386a:	a021                	j	80003872 <itrunc+0x22>
    8000386c:	0491                	addi	s1,s1,4
    8000386e:	01248d63          	beq	s1,s2,80003888 <itrunc+0x38>
    if(ip->addrs[i]){
    80003872:	408c                	lw	a1,0(s1)
    80003874:	dde5                	beqz	a1,8000386c <itrunc+0x1c>
      bfree(ip->dev, ip->addrs[i]);
    80003876:	0009a503          	lw	a0,0(s3)
    8000387a:	00000097          	auipc	ra,0x0
    8000387e:	8f6080e7          	jalr	-1802(ra) # 80003170 <bfree>
      ip->addrs[i] = 0;
    80003882:	0004a023          	sw	zero,0(s1)
    80003886:	b7dd                	j	8000386c <itrunc+0x1c>
    }
  }

  if(ip->addrs[NDIRECT]){
    80003888:	0809a583          	lw	a1,128(s3)
    8000388c:	e185                	bnez	a1,800038ac <itrunc+0x5c>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    8000388e:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80003892:	854e                	mv	a0,s3
    80003894:	00000097          	auipc	ra,0x0
    80003898:	de2080e7          	jalr	-542(ra) # 80003676 <iupdate>
}
    8000389c:	70a2                	ld	ra,40(sp)
    8000389e:	7402                	ld	s0,32(sp)
    800038a0:	64e2                	ld	s1,24(sp)
    800038a2:	6942                	ld	s2,16(sp)
    800038a4:	69a2                	ld	s3,8(sp)
    800038a6:	6a02                	ld	s4,0(sp)
    800038a8:	6145                	addi	sp,sp,48
    800038aa:	8082                	ret
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    800038ac:	0009a503          	lw	a0,0(s3)
    800038b0:	fffff097          	auipc	ra,0xfffff
    800038b4:	67a080e7          	jalr	1658(ra) # 80002f2a <bread>
    800038b8:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    800038ba:	05850493          	addi	s1,a0,88
    800038be:	45850913          	addi	s2,a0,1112
    800038c2:	a021                	j	800038ca <itrunc+0x7a>
    800038c4:	0491                	addi	s1,s1,4
    800038c6:	01248b63          	beq	s1,s2,800038dc <itrunc+0x8c>
      if(a[j])
    800038ca:	408c                	lw	a1,0(s1)
    800038cc:	dde5                	beqz	a1,800038c4 <itrunc+0x74>
        bfree(ip->dev, a[j]);
    800038ce:	0009a503          	lw	a0,0(s3)
    800038d2:	00000097          	auipc	ra,0x0
    800038d6:	89e080e7          	jalr	-1890(ra) # 80003170 <bfree>
    800038da:	b7ed                	j	800038c4 <itrunc+0x74>
    brelse(bp);
    800038dc:	8552                	mv	a0,s4
    800038de:	fffff097          	auipc	ra,0xfffff
    800038e2:	77c080e7          	jalr	1916(ra) # 8000305a <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    800038e6:	0809a583          	lw	a1,128(s3)
    800038ea:	0009a503          	lw	a0,0(s3)
    800038ee:	00000097          	auipc	ra,0x0
    800038f2:	882080e7          	jalr	-1918(ra) # 80003170 <bfree>
    ip->addrs[NDIRECT] = 0;
    800038f6:	0809a023          	sw	zero,128(s3)
    800038fa:	bf51                	j	8000388e <itrunc+0x3e>

00000000800038fc <iput>:
{
    800038fc:	1101                	addi	sp,sp,-32
    800038fe:	ec06                	sd	ra,24(sp)
    80003900:	e822                	sd	s0,16(sp)
    80003902:	e426                	sd	s1,8(sp)
    80003904:	e04a                	sd	s2,0(sp)
    80003906:	1000                	addi	s0,sp,32
    80003908:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000390a:	0001c517          	auipc	a0,0x1c
    8000390e:	b6e50513          	addi	a0,a0,-1170 # 8001f478 <itable>
    80003912:	ffffd097          	auipc	ra,0xffffd
    80003916:	2c2080e7          	jalr	706(ra) # 80000bd4 <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    8000391a:	4498                	lw	a4,8(s1)
    8000391c:	4785                	li	a5,1
    8000391e:	02f70363          	beq	a4,a5,80003944 <iput+0x48>
  ip->ref--;
    80003922:	449c                	lw	a5,8(s1)
    80003924:	37fd                	addiw	a5,a5,-1
    80003926:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003928:	0001c517          	auipc	a0,0x1c
    8000392c:	b5050513          	addi	a0,a0,-1200 # 8001f478 <itable>
    80003930:	ffffd097          	auipc	ra,0xffffd
    80003934:	358080e7          	jalr	856(ra) # 80000c88 <release>
}
    80003938:	60e2                	ld	ra,24(sp)
    8000393a:	6442                	ld	s0,16(sp)
    8000393c:	64a2                	ld	s1,8(sp)
    8000393e:	6902                	ld	s2,0(sp)
    80003940:	6105                	addi	sp,sp,32
    80003942:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80003944:	40bc                	lw	a5,64(s1)
    80003946:	dff1                	beqz	a5,80003922 <iput+0x26>
    80003948:	04a49783          	lh	a5,74(s1)
    8000394c:	fbf9                	bnez	a5,80003922 <iput+0x26>
    acquiresleep(&ip->lock);
    8000394e:	01048913          	addi	s2,s1,16
    80003952:	854a                	mv	a0,s2
    80003954:	00001097          	auipc	ra,0x1
    80003958:	aae080e7          	jalr	-1362(ra) # 80004402 <acquiresleep>
    release(&itable.lock);
    8000395c:	0001c517          	auipc	a0,0x1c
    80003960:	b1c50513          	addi	a0,a0,-1252 # 8001f478 <itable>
    80003964:	ffffd097          	auipc	ra,0xffffd
    80003968:	324080e7          	jalr	804(ra) # 80000c88 <release>
    itrunc(ip);
    8000396c:	8526                	mv	a0,s1
    8000396e:	00000097          	auipc	ra,0x0
    80003972:	ee2080e7          	jalr	-286(ra) # 80003850 <itrunc>
    ip->type = 0;
    80003976:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    8000397a:	8526                	mv	a0,s1
    8000397c:	00000097          	auipc	ra,0x0
    80003980:	cfa080e7          	jalr	-774(ra) # 80003676 <iupdate>
    ip->valid = 0;
    80003984:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80003988:	854a                	mv	a0,s2
    8000398a:	00001097          	auipc	ra,0x1
    8000398e:	ace080e7          	jalr	-1330(ra) # 80004458 <releasesleep>
    acquire(&itable.lock);
    80003992:	0001c517          	auipc	a0,0x1c
    80003996:	ae650513          	addi	a0,a0,-1306 # 8001f478 <itable>
    8000399a:	ffffd097          	auipc	ra,0xffffd
    8000399e:	23a080e7          	jalr	570(ra) # 80000bd4 <acquire>
    800039a2:	b741                	j	80003922 <iput+0x26>

00000000800039a4 <iunlockput>:
{
    800039a4:	1101                	addi	sp,sp,-32
    800039a6:	ec06                	sd	ra,24(sp)
    800039a8:	e822                	sd	s0,16(sp)
    800039aa:	e426                	sd	s1,8(sp)
    800039ac:	1000                	addi	s0,sp,32
    800039ae:	84aa                	mv	s1,a0
  iunlock(ip);
    800039b0:	00000097          	auipc	ra,0x0
    800039b4:	e54080e7          	jalr	-428(ra) # 80003804 <iunlock>
  iput(ip);
    800039b8:	8526                	mv	a0,s1
    800039ba:	00000097          	auipc	ra,0x0
    800039be:	f42080e7          	jalr	-190(ra) # 800038fc <iput>
}
    800039c2:	60e2                	ld	ra,24(sp)
    800039c4:	6442                	ld	s0,16(sp)
    800039c6:	64a2                	ld	s1,8(sp)
    800039c8:	6105                	addi	sp,sp,32
    800039ca:	8082                	ret

00000000800039cc <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    800039cc:	1141                	addi	sp,sp,-16
    800039ce:	e422                	sd	s0,8(sp)
    800039d0:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    800039d2:	411c                	lw	a5,0(a0)
    800039d4:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    800039d6:	415c                	lw	a5,4(a0)
    800039d8:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    800039da:	04451783          	lh	a5,68(a0)
    800039de:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    800039e2:	04a51783          	lh	a5,74(a0)
    800039e6:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    800039ea:	04c56783          	lwu	a5,76(a0)
    800039ee:	e99c                	sd	a5,16(a1)
}
    800039f0:	6422                	ld	s0,8(sp)
    800039f2:	0141                	addi	sp,sp,16
    800039f4:	8082                	ret

00000000800039f6 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    800039f6:	457c                	lw	a5,76(a0)
    800039f8:	0ed7e963          	bltu	a5,a3,80003aea <readi+0xf4>
{
    800039fc:	7159                	addi	sp,sp,-112
    800039fe:	f486                	sd	ra,104(sp)
    80003a00:	f0a2                	sd	s0,96(sp)
    80003a02:	eca6                	sd	s1,88(sp)
    80003a04:	e8ca                	sd	s2,80(sp)
    80003a06:	e4ce                	sd	s3,72(sp)
    80003a08:	e0d2                	sd	s4,64(sp)
    80003a0a:	fc56                	sd	s5,56(sp)
    80003a0c:	f85a                	sd	s6,48(sp)
    80003a0e:	f45e                	sd	s7,40(sp)
    80003a10:	f062                	sd	s8,32(sp)
    80003a12:	ec66                	sd	s9,24(sp)
    80003a14:	e86a                	sd	s10,16(sp)
    80003a16:	e46e                	sd	s11,8(sp)
    80003a18:	1880                	addi	s0,sp,112
    80003a1a:	8b2a                	mv	s6,a0
    80003a1c:	8bae                	mv	s7,a1
    80003a1e:	8a32                	mv	s4,a2
    80003a20:	84b6                	mv	s1,a3
    80003a22:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80003a24:	9f35                	addw	a4,a4,a3
    return 0;
    80003a26:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    80003a28:	0ad76063          	bltu	a4,a3,80003ac8 <readi+0xd2>
  if(off + n > ip->size)
    80003a2c:	00e7f463          	bgeu	a5,a4,80003a34 <readi+0x3e>
    n = ip->size - off;
    80003a30:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003a34:	0a0a8963          	beqz	s5,80003ae6 <readi+0xf0>
    80003a38:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003a3a:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80003a3e:	5c7d                	li	s8,-1
    80003a40:	a82d                	j	80003a7a <readi+0x84>
    80003a42:	020d1d93          	slli	s11,s10,0x20
    80003a46:	020ddd93          	srli	s11,s11,0x20
    80003a4a:	05890613          	addi	a2,s2,88
    80003a4e:	86ee                	mv	a3,s11
    80003a50:	963a                	add	a2,a2,a4
    80003a52:	85d2                	mv	a1,s4
    80003a54:	855e                	mv	a0,s7
    80003a56:	fffff097          	auipc	ra,0xfffff
    80003a5a:	b1a080e7          	jalr	-1254(ra) # 80002570 <either_copyout>
    80003a5e:	05850d63          	beq	a0,s8,80003ab8 <readi+0xc2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80003a62:	854a                	mv	a0,s2
    80003a64:	fffff097          	auipc	ra,0xfffff
    80003a68:	5f6080e7          	jalr	1526(ra) # 8000305a <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003a6c:	013d09bb          	addw	s3,s10,s3
    80003a70:	009d04bb          	addw	s1,s10,s1
    80003a74:	9a6e                	add	s4,s4,s11
    80003a76:	0559f763          	bgeu	s3,s5,80003ac4 <readi+0xce>
    uint addr = bmap(ip, off/BSIZE);
    80003a7a:	00a4d59b          	srliw	a1,s1,0xa
    80003a7e:	855a                	mv	a0,s6
    80003a80:	00000097          	auipc	ra,0x0
    80003a84:	89e080e7          	jalr	-1890(ra) # 8000331e <bmap>
    80003a88:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003a8c:	cd85                	beqz	a1,80003ac4 <readi+0xce>
    bp = bread(ip->dev, addr);
    80003a8e:	000b2503          	lw	a0,0(s6)
    80003a92:	fffff097          	auipc	ra,0xfffff
    80003a96:	498080e7          	jalr	1176(ra) # 80002f2a <bread>
    80003a9a:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003a9c:	3ff4f713          	andi	a4,s1,1023
    80003aa0:	40ec87bb          	subw	a5,s9,a4
    80003aa4:	413a86bb          	subw	a3,s5,s3
    80003aa8:	8d3e                	mv	s10,a5
    80003aaa:	2781                	sext.w	a5,a5
    80003aac:	0006861b          	sext.w	a2,a3
    80003ab0:	f8f679e3          	bgeu	a2,a5,80003a42 <readi+0x4c>
    80003ab4:	8d36                	mv	s10,a3
    80003ab6:	b771                	j	80003a42 <readi+0x4c>
      brelse(bp);
    80003ab8:	854a                	mv	a0,s2
    80003aba:	fffff097          	auipc	ra,0xfffff
    80003abe:	5a0080e7          	jalr	1440(ra) # 8000305a <brelse>
      tot = -1;
    80003ac2:	59fd                	li	s3,-1
  }
  return tot;
    80003ac4:	0009851b          	sext.w	a0,s3
}
    80003ac8:	70a6                	ld	ra,104(sp)
    80003aca:	7406                	ld	s0,96(sp)
    80003acc:	64e6                	ld	s1,88(sp)
    80003ace:	6946                	ld	s2,80(sp)
    80003ad0:	69a6                	ld	s3,72(sp)
    80003ad2:	6a06                	ld	s4,64(sp)
    80003ad4:	7ae2                	ld	s5,56(sp)
    80003ad6:	7b42                	ld	s6,48(sp)
    80003ad8:	7ba2                	ld	s7,40(sp)
    80003ada:	7c02                	ld	s8,32(sp)
    80003adc:	6ce2                	ld	s9,24(sp)
    80003ade:	6d42                	ld	s10,16(sp)
    80003ae0:	6da2                	ld	s11,8(sp)
    80003ae2:	6165                	addi	sp,sp,112
    80003ae4:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003ae6:	89d6                	mv	s3,s5
    80003ae8:	bff1                	j	80003ac4 <readi+0xce>
    return 0;
    80003aea:	4501                	li	a0,0
}
    80003aec:	8082                	ret

0000000080003aee <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003aee:	457c                	lw	a5,76(a0)
    80003af0:	10d7e863          	bltu	a5,a3,80003c00 <writei+0x112>
{
    80003af4:	7159                	addi	sp,sp,-112
    80003af6:	f486                	sd	ra,104(sp)
    80003af8:	f0a2                	sd	s0,96(sp)
    80003afa:	eca6                	sd	s1,88(sp)
    80003afc:	e8ca                	sd	s2,80(sp)
    80003afe:	e4ce                	sd	s3,72(sp)
    80003b00:	e0d2                	sd	s4,64(sp)
    80003b02:	fc56                	sd	s5,56(sp)
    80003b04:	f85a                	sd	s6,48(sp)
    80003b06:	f45e                	sd	s7,40(sp)
    80003b08:	f062                	sd	s8,32(sp)
    80003b0a:	ec66                	sd	s9,24(sp)
    80003b0c:	e86a                	sd	s10,16(sp)
    80003b0e:	e46e                	sd	s11,8(sp)
    80003b10:	1880                	addi	s0,sp,112
    80003b12:	8aaa                	mv	s5,a0
    80003b14:	8bae                	mv	s7,a1
    80003b16:	8a32                	mv	s4,a2
    80003b18:	8936                	mv	s2,a3
    80003b1a:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80003b1c:	00e687bb          	addw	a5,a3,a4
    80003b20:	0ed7e263          	bltu	a5,a3,80003c04 <writei+0x116>
    return -1;
  if(off + n > MAXFILE*BSIZE)
    80003b24:	00043737          	lui	a4,0x43
    80003b28:	0ef76063          	bltu	a4,a5,80003c08 <writei+0x11a>
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003b2c:	0c0b0863          	beqz	s6,80003bfc <writei+0x10e>
    80003b30:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003b32:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003b36:	5c7d                	li	s8,-1
    80003b38:	a091                	j	80003b7c <writei+0x8e>
    80003b3a:	020d1d93          	slli	s11,s10,0x20
    80003b3e:	020ddd93          	srli	s11,s11,0x20
    80003b42:	05848513          	addi	a0,s1,88
    80003b46:	86ee                	mv	a3,s11
    80003b48:	8652                	mv	a2,s4
    80003b4a:	85de                	mv	a1,s7
    80003b4c:	953a                	add	a0,a0,a4
    80003b4e:	fffff097          	auipc	ra,0xfffff
    80003b52:	a78080e7          	jalr	-1416(ra) # 800025c6 <either_copyin>
    80003b56:	07850263          	beq	a0,s8,80003bba <writei+0xcc>
      brelse(bp);
      break;
    }
    log_write(bp);
    80003b5a:	8526                	mv	a0,s1
    80003b5c:	00000097          	auipc	ra,0x0
    80003b60:	788080e7          	jalr	1928(ra) # 800042e4 <log_write>
    brelse(bp);
    80003b64:	8526                	mv	a0,s1
    80003b66:	fffff097          	auipc	ra,0xfffff
    80003b6a:	4f4080e7          	jalr	1268(ra) # 8000305a <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003b6e:	013d09bb          	addw	s3,s10,s3
    80003b72:	012d093b          	addw	s2,s10,s2
    80003b76:	9a6e                	add	s4,s4,s11
    80003b78:	0569f663          	bgeu	s3,s6,80003bc4 <writei+0xd6>
    uint addr = bmap(ip, off/BSIZE);
    80003b7c:	00a9559b          	srliw	a1,s2,0xa
    80003b80:	8556                	mv	a0,s5
    80003b82:	fffff097          	auipc	ra,0xfffff
    80003b86:	79c080e7          	jalr	1948(ra) # 8000331e <bmap>
    80003b8a:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003b8e:	c99d                	beqz	a1,80003bc4 <writei+0xd6>
    bp = bread(ip->dev, addr);
    80003b90:	000aa503          	lw	a0,0(s5)
    80003b94:	fffff097          	auipc	ra,0xfffff
    80003b98:	396080e7          	jalr	918(ra) # 80002f2a <bread>
    80003b9c:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003b9e:	3ff97713          	andi	a4,s2,1023
    80003ba2:	40ec87bb          	subw	a5,s9,a4
    80003ba6:	413b06bb          	subw	a3,s6,s3
    80003baa:	8d3e                	mv	s10,a5
    80003bac:	2781                	sext.w	a5,a5
    80003bae:	0006861b          	sext.w	a2,a3
    80003bb2:	f8f674e3          	bgeu	a2,a5,80003b3a <writei+0x4c>
    80003bb6:	8d36                	mv	s10,a3
    80003bb8:	b749                	j	80003b3a <writei+0x4c>
      brelse(bp);
    80003bba:	8526                	mv	a0,s1
    80003bbc:	fffff097          	auipc	ra,0xfffff
    80003bc0:	49e080e7          	jalr	1182(ra) # 8000305a <brelse>
  }

  if(off > ip->size)
    80003bc4:	04caa783          	lw	a5,76(s5)
    80003bc8:	0127f463          	bgeu	a5,s2,80003bd0 <writei+0xe2>
    ip->size = off;
    80003bcc:	052aa623          	sw	s2,76(s5)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80003bd0:	8556                	mv	a0,s5
    80003bd2:	00000097          	auipc	ra,0x0
    80003bd6:	aa4080e7          	jalr	-1372(ra) # 80003676 <iupdate>

  return tot;
    80003bda:	0009851b          	sext.w	a0,s3
}
    80003bde:	70a6                	ld	ra,104(sp)
    80003be0:	7406                	ld	s0,96(sp)
    80003be2:	64e6                	ld	s1,88(sp)
    80003be4:	6946                	ld	s2,80(sp)
    80003be6:	69a6                	ld	s3,72(sp)
    80003be8:	6a06                	ld	s4,64(sp)
    80003bea:	7ae2                	ld	s5,56(sp)
    80003bec:	7b42                	ld	s6,48(sp)
    80003bee:	7ba2                	ld	s7,40(sp)
    80003bf0:	7c02                	ld	s8,32(sp)
    80003bf2:	6ce2                	ld	s9,24(sp)
    80003bf4:	6d42                	ld	s10,16(sp)
    80003bf6:	6da2                	ld	s11,8(sp)
    80003bf8:	6165                	addi	sp,sp,112
    80003bfa:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003bfc:	89da                	mv	s3,s6
    80003bfe:	bfc9                	j	80003bd0 <writei+0xe2>
    return -1;
    80003c00:	557d                	li	a0,-1
}
    80003c02:	8082                	ret
    return -1;
    80003c04:	557d                	li	a0,-1
    80003c06:	bfe1                	j	80003bde <writei+0xf0>
    return -1;
    80003c08:	557d                	li	a0,-1
    80003c0a:	bfd1                	j	80003bde <writei+0xf0>

0000000080003c0c <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003c0c:	1141                	addi	sp,sp,-16
    80003c0e:	e406                	sd	ra,8(sp)
    80003c10:	e022                	sd	s0,0(sp)
    80003c12:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003c14:	4639                	li	a2,14
    80003c16:	ffffd097          	auipc	ra,0xffffd
    80003c1a:	18a080e7          	jalr	394(ra) # 80000da0 <strncmp>
}
    80003c1e:	60a2                	ld	ra,8(sp)
    80003c20:	6402                	ld	s0,0(sp)
    80003c22:	0141                	addi	sp,sp,16
    80003c24:	8082                	ret

0000000080003c26 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003c26:	7139                	addi	sp,sp,-64
    80003c28:	fc06                	sd	ra,56(sp)
    80003c2a:	f822                	sd	s0,48(sp)
    80003c2c:	f426                	sd	s1,40(sp)
    80003c2e:	f04a                	sd	s2,32(sp)
    80003c30:	ec4e                	sd	s3,24(sp)
    80003c32:	e852                	sd	s4,16(sp)
    80003c34:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80003c36:	04451703          	lh	a4,68(a0)
    80003c3a:	4785                	li	a5,1
    80003c3c:	00f71a63          	bne	a4,a5,80003c50 <dirlookup+0x2a>
    80003c40:	892a                	mv	s2,a0
    80003c42:	89ae                	mv	s3,a1
    80003c44:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80003c46:	457c                	lw	a5,76(a0)
    80003c48:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003c4a:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003c4c:	e79d                	bnez	a5,80003c7a <dirlookup+0x54>
    80003c4e:	a8a5                	j	80003cc6 <dirlookup+0xa0>
    panic("dirlookup not DIR");
    80003c50:	00005517          	auipc	a0,0x5
    80003c54:	9a050513          	addi	a0,a0,-1632 # 800085f0 <syscalls+0x1a0>
    80003c58:	ffffd097          	auipc	ra,0xffffd
    80003c5c:	8e6080e7          	jalr	-1818(ra) # 8000053e <panic>
      panic("dirlookup read");
    80003c60:	00005517          	auipc	a0,0x5
    80003c64:	9a850513          	addi	a0,a0,-1624 # 80008608 <syscalls+0x1b8>
    80003c68:	ffffd097          	auipc	ra,0xffffd
    80003c6c:	8d6080e7          	jalr	-1834(ra) # 8000053e <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003c70:	24c1                	addiw	s1,s1,16
    80003c72:	04c92783          	lw	a5,76(s2)
    80003c76:	04f4f763          	bgeu	s1,a5,80003cc4 <dirlookup+0x9e>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003c7a:	4741                	li	a4,16
    80003c7c:	86a6                	mv	a3,s1
    80003c7e:	fc040613          	addi	a2,s0,-64
    80003c82:	4581                	li	a1,0
    80003c84:	854a                	mv	a0,s2
    80003c86:	00000097          	auipc	ra,0x0
    80003c8a:	d70080e7          	jalr	-656(ra) # 800039f6 <readi>
    80003c8e:	47c1                	li	a5,16
    80003c90:	fcf518e3          	bne	a0,a5,80003c60 <dirlookup+0x3a>
    if(de.inum == 0)
    80003c94:	fc045783          	lhu	a5,-64(s0)
    80003c98:	dfe1                	beqz	a5,80003c70 <dirlookup+0x4a>
    if(namecmp(name, de.name) == 0){
    80003c9a:	fc240593          	addi	a1,s0,-62
    80003c9e:	854e                	mv	a0,s3
    80003ca0:	00000097          	auipc	ra,0x0
    80003ca4:	f6c080e7          	jalr	-148(ra) # 80003c0c <namecmp>
    80003ca8:	f561                	bnez	a0,80003c70 <dirlookup+0x4a>
      if(poff)
    80003caa:	000a0463          	beqz	s4,80003cb2 <dirlookup+0x8c>
        *poff = off;
    80003cae:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    80003cb2:	fc045583          	lhu	a1,-64(s0)
    80003cb6:	00092503          	lw	a0,0(s2)
    80003cba:	fffff097          	auipc	ra,0xfffff
    80003cbe:	74e080e7          	jalr	1870(ra) # 80003408 <iget>
    80003cc2:	a011                	j	80003cc6 <dirlookup+0xa0>
  return 0;
    80003cc4:	4501                	li	a0,0
}
    80003cc6:	70e2                	ld	ra,56(sp)
    80003cc8:	7442                	ld	s0,48(sp)
    80003cca:	74a2                	ld	s1,40(sp)
    80003ccc:	7902                	ld	s2,32(sp)
    80003cce:	69e2                	ld	s3,24(sp)
    80003cd0:	6a42                	ld	s4,16(sp)
    80003cd2:	6121                	addi	sp,sp,64
    80003cd4:	8082                	ret

0000000080003cd6 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80003cd6:	711d                	addi	sp,sp,-96
    80003cd8:	ec86                	sd	ra,88(sp)
    80003cda:	e8a2                	sd	s0,80(sp)
    80003cdc:	e4a6                	sd	s1,72(sp)
    80003cde:	e0ca                	sd	s2,64(sp)
    80003ce0:	fc4e                	sd	s3,56(sp)
    80003ce2:	f852                	sd	s4,48(sp)
    80003ce4:	f456                	sd	s5,40(sp)
    80003ce6:	f05a                	sd	s6,32(sp)
    80003ce8:	ec5e                	sd	s7,24(sp)
    80003cea:	e862                	sd	s8,16(sp)
    80003cec:	e466                	sd	s9,8(sp)
    80003cee:	e06a                	sd	s10,0(sp)
    80003cf0:	1080                	addi	s0,sp,96
    80003cf2:	84aa                	mv	s1,a0
    80003cf4:	8b2e                	mv	s6,a1
    80003cf6:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80003cf8:	00054703          	lbu	a4,0(a0)
    80003cfc:	02f00793          	li	a5,47
    80003d00:	02f70363          	beq	a4,a5,80003d26 <namex+0x50>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003d04:	ffffe097          	auipc	ra,0xffffe
    80003d08:	ca6080e7          	jalr	-858(ra) # 800019aa <myproc>
    80003d0c:	15053503          	ld	a0,336(a0)
    80003d10:	00000097          	auipc	ra,0x0
    80003d14:	9f4080e7          	jalr	-1548(ra) # 80003704 <idup>
    80003d18:	8a2a                	mv	s4,a0
  while(*path == '/')
    80003d1a:	02f00913          	li	s2,47
  if(len >= DIRSIZ)
    80003d1e:	4cb5                	li	s9,13
  len = path - s;
    80003d20:	4b81                	li	s7,0

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80003d22:	4c05                	li	s8,1
    80003d24:	a87d                	j	80003de2 <namex+0x10c>
    ip = iget(ROOTDEV, ROOTINO);
    80003d26:	4585                	li	a1,1
    80003d28:	4505                	li	a0,1
    80003d2a:	fffff097          	auipc	ra,0xfffff
    80003d2e:	6de080e7          	jalr	1758(ra) # 80003408 <iget>
    80003d32:	8a2a                	mv	s4,a0
    80003d34:	b7dd                	j	80003d1a <namex+0x44>
      iunlockput(ip);
    80003d36:	8552                	mv	a0,s4
    80003d38:	00000097          	auipc	ra,0x0
    80003d3c:	c6c080e7          	jalr	-916(ra) # 800039a4 <iunlockput>
      return 0;
    80003d40:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80003d42:	8552                	mv	a0,s4
    80003d44:	60e6                	ld	ra,88(sp)
    80003d46:	6446                	ld	s0,80(sp)
    80003d48:	64a6                	ld	s1,72(sp)
    80003d4a:	6906                	ld	s2,64(sp)
    80003d4c:	79e2                	ld	s3,56(sp)
    80003d4e:	7a42                	ld	s4,48(sp)
    80003d50:	7aa2                	ld	s5,40(sp)
    80003d52:	7b02                	ld	s6,32(sp)
    80003d54:	6be2                	ld	s7,24(sp)
    80003d56:	6c42                	ld	s8,16(sp)
    80003d58:	6ca2                	ld	s9,8(sp)
    80003d5a:	6d02                	ld	s10,0(sp)
    80003d5c:	6125                	addi	sp,sp,96
    80003d5e:	8082                	ret
      iunlock(ip);
    80003d60:	8552                	mv	a0,s4
    80003d62:	00000097          	auipc	ra,0x0
    80003d66:	aa2080e7          	jalr	-1374(ra) # 80003804 <iunlock>
      return ip;
    80003d6a:	bfe1                	j	80003d42 <namex+0x6c>
      iunlockput(ip);
    80003d6c:	8552                	mv	a0,s4
    80003d6e:	00000097          	auipc	ra,0x0
    80003d72:	c36080e7          	jalr	-970(ra) # 800039a4 <iunlockput>
      return 0;
    80003d76:	8a4e                	mv	s4,s3
    80003d78:	b7e9                	j	80003d42 <namex+0x6c>
  len = path - s;
    80003d7a:	40998633          	sub	a2,s3,s1
    80003d7e:	00060d1b          	sext.w	s10,a2
  if(len >= DIRSIZ)
    80003d82:	09acd863          	bge	s9,s10,80003e12 <namex+0x13c>
    memmove(name, s, DIRSIZ);
    80003d86:	4639                	li	a2,14
    80003d88:	85a6                	mv	a1,s1
    80003d8a:	8556                	mv	a0,s5
    80003d8c:	ffffd097          	auipc	ra,0xffffd
    80003d90:	fa0080e7          	jalr	-96(ra) # 80000d2c <memmove>
    80003d94:	84ce                	mv	s1,s3
  while(*path == '/')
    80003d96:	0004c783          	lbu	a5,0(s1)
    80003d9a:	01279763          	bne	a5,s2,80003da8 <namex+0xd2>
    path++;
    80003d9e:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003da0:	0004c783          	lbu	a5,0(s1)
    80003da4:	ff278de3          	beq	a5,s2,80003d9e <namex+0xc8>
    ilock(ip);
    80003da8:	8552                	mv	a0,s4
    80003daa:	00000097          	auipc	ra,0x0
    80003dae:	998080e7          	jalr	-1640(ra) # 80003742 <ilock>
    if(ip->type != T_DIR){
    80003db2:	044a1783          	lh	a5,68(s4)
    80003db6:	f98790e3          	bne	a5,s8,80003d36 <namex+0x60>
    if(nameiparent && *path == '\0'){
    80003dba:	000b0563          	beqz	s6,80003dc4 <namex+0xee>
    80003dbe:	0004c783          	lbu	a5,0(s1)
    80003dc2:	dfd9                	beqz	a5,80003d60 <namex+0x8a>
    if((next = dirlookup(ip, name, 0)) == 0){
    80003dc4:	865e                	mv	a2,s7
    80003dc6:	85d6                	mv	a1,s5
    80003dc8:	8552                	mv	a0,s4
    80003dca:	00000097          	auipc	ra,0x0
    80003dce:	e5c080e7          	jalr	-420(ra) # 80003c26 <dirlookup>
    80003dd2:	89aa                	mv	s3,a0
    80003dd4:	dd41                	beqz	a0,80003d6c <namex+0x96>
    iunlockput(ip);
    80003dd6:	8552                	mv	a0,s4
    80003dd8:	00000097          	auipc	ra,0x0
    80003ddc:	bcc080e7          	jalr	-1076(ra) # 800039a4 <iunlockput>
    ip = next;
    80003de0:	8a4e                	mv	s4,s3
  while(*path == '/')
    80003de2:	0004c783          	lbu	a5,0(s1)
    80003de6:	01279763          	bne	a5,s2,80003df4 <namex+0x11e>
    path++;
    80003dea:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003dec:	0004c783          	lbu	a5,0(s1)
    80003df0:	ff278de3          	beq	a5,s2,80003dea <namex+0x114>
  if(*path == 0)
    80003df4:	cb9d                	beqz	a5,80003e2a <namex+0x154>
  while(*path != '/' && *path != 0)
    80003df6:	0004c783          	lbu	a5,0(s1)
    80003dfa:	89a6                	mv	s3,s1
  len = path - s;
    80003dfc:	8d5e                	mv	s10,s7
    80003dfe:	865e                	mv	a2,s7
  while(*path != '/' && *path != 0)
    80003e00:	01278963          	beq	a5,s2,80003e12 <namex+0x13c>
    80003e04:	dbbd                	beqz	a5,80003d7a <namex+0xa4>
    path++;
    80003e06:	0985                	addi	s3,s3,1
  while(*path != '/' && *path != 0)
    80003e08:	0009c783          	lbu	a5,0(s3)
    80003e0c:	ff279ce3          	bne	a5,s2,80003e04 <namex+0x12e>
    80003e10:	b7ad                	j	80003d7a <namex+0xa4>
    memmove(name, s, len);
    80003e12:	2601                	sext.w	a2,a2
    80003e14:	85a6                	mv	a1,s1
    80003e16:	8556                	mv	a0,s5
    80003e18:	ffffd097          	auipc	ra,0xffffd
    80003e1c:	f14080e7          	jalr	-236(ra) # 80000d2c <memmove>
    name[len] = 0;
    80003e20:	9d56                	add	s10,s10,s5
    80003e22:	000d0023          	sb	zero,0(s10)
    80003e26:	84ce                	mv	s1,s3
    80003e28:	b7bd                	j	80003d96 <namex+0xc0>
  if(nameiparent){
    80003e2a:	f00b0ce3          	beqz	s6,80003d42 <namex+0x6c>
    iput(ip);
    80003e2e:	8552                	mv	a0,s4
    80003e30:	00000097          	auipc	ra,0x0
    80003e34:	acc080e7          	jalr	-1332(ra) # 800038fc <iput>
    return 0;
    80003e38:	4a01                	li	s4,0
    80003e3a:	b721                	j	80003d42 <namex+0x6c>

0000000080003e3c <dirlink>:
{
    80003e3c:	7139                	addi	sp,sp,-64
    80003e3e:	fc06                	sd	ra,56(sp)
    80003e40:	f822                	sd	s0,48(sp)
    80003e42:	f426                	sd	s1,40(sp)
    80003e44:	f04a                	sd	s2,32(sp)
    80003e46:	ec4e                	sd	s3,24(sp)
    80003e48:	e852                	sd	s4,16(sp)
    80003e4a:	0080                	addi	s0,sp,64
    80003e4c:	892a                	mv	s2,a0
    80003e4e:	8a2e                	mv	s4,a1
    80003e50:	89b2                	mv	s3,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80003e52:	4601                	li	a2,0
    80003e54:	00000097          	auipc	ra,0x0
    80003e58:	dd2080e7          	jalr	-558(ra) # 80003c26 <dirlookup>
    80003e5c:	e93d                	bnez	a0,80003ed2 <dirlink+0x96>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003e5e:	04c92483          	lw	s1,76(s2)
    80003e62:	c49d                	beqz	s1,80003e90 <dirlink+0x54>
    80003e64:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003e66:	4741                	li	a4,16
    80003e68:	86a6                	mv	a3,s1
    80003e6a:	fc040613          	addi	a2,s0,-64
    80003e6e:	4581                	li	a1,0
    80003e70:	854a                	mv	a0,s2
    80003e72:	00000097          	auipc	ra,0x0
    80003e76:	b84080e7          	jalr	-1148(ra) # 800039f6 <readi>
    80003e7a:	47c1                	li	a5,16
    80003e7c:	06f51163          	bne	a0,a5,80003ede <dirlink+0xa2>
    if(de.inum == 0)
    80003e80:	fc045783          	lhu	a5,-64(s0)
    80003e84:	c791                	beqz	a5,80003e90 <dirlink+0x54>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003e86:	24c1                	addiw	s1,s1,16
    80003e88:	04c92783          	lw	a5,76(s2)
    80003e8c:	fcf4ede3          	bltu	s1,a5,80003e66 <dirlink+0x2a>
  strncpy(de.name, name, DIRSIZ);
    80003e90:	4639                	li	a2,14
    80003e92:	85d2                	mv	a1,s4
    80003e94:	fc240513          	addi	a0,s0,-62
    80003e98:	ffffd097          	auipc	ra,0xffffd
    80003e9c:	f44080e7          	jalr	-188(ra) # 80000ddc <strncpy>
  de.inum = inum;
    80003ea0:	fd341023          	sh	s3,-64(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003ea4:	4741                	li	a4,16
    80003ea6:	86a6                	mv	a3,s1
    80003ea8:	fc040613          	addi	a2,s0,-64
    80003eac:	4581                	li	a1,0
    80003eae:	854a                	mv	a0,s2
    80003eb0:	00000097          	auipc	ra,0x0
    80003eb4:	c3e080e7          	jalr	-962(ra) # 80003aee <writei>
    80003eb8:	1541                	addi	a0,a0,-16
    80003eba:	00a03533          	snez	a0,a0
    80003ebe:	40a00533          	neg	a0,a0
}
    80003ec2:	70e2                	ld	ra,56(sp)
    80003ec4:	7442                	ld	s0,48(sp)
    80003ec6:	74a2                	ld	s1,40(sp)
    80003ec8:	7902                	ld	s2,32(sp)
    80003eca:	69e2                	ld	s3,24(sp)
    80003ecc:	6a42                	ld	s4,16(sp)
    80003ece:	6121                	addi	sp,sp,64
    80003ed0:	8082                	ret
    iput(ip);
    80003ed2:	00000097          	auipc	ra,0x0
    80003ed6:	a2a080e7          	jalr	-1494(ra) # 800038fc <iput>
    return -1;
    80003eda:	557d                	li	a0,-1
    80003edc:	b7dd                	j	80003ec2 <dirlink+0x86>
      panic("dirlink read");
    80003ede:	00004517          	auipc	a0,0x4
    80003ee2:	73a50513          	addi	a0,a0,1850 # 80008618 <syscalls+0x1c8>
    80003ee6:	ffffc097          	auipc	ra,0xffffc
    80003eea:	658080e7          	jalr	1624(ra) # 8000053e <panic>

0000000080003eee <namei>:

struct inode*
namei(char *path)
{
    80003eee:	1101                	addi	sp,sp,-32
    80003ef0:	ec06                	sd	ra,24(sp)
    80003ef2:	e822                	sd	s0,16(sp)
    80003ef4:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003ef6:	fe040613          	addi	a2,s0,-32
    80003efa:	4581                	li	a1,0
    80003efc:	00000097          	auipc	ra,0x0
    80003f00:	dda080e7          	jalr	-550(ra) # 80003cd6 <namex>
}
    80003f04:	60e2                	ld	ra,24(sp)
    80003f06:	6442                	ld	s0,16(sp)
    80003f08:	6105                	addi	sp,sp,32
    80003f0a:	8082                	ret

0000000080003f0c <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80003f0c:	1141                	addi	sp,sp,-16
    80003f0e:	e406                	sd	ra,8(sp)
    80003f10:	e022                	sd	s0,0(sp)
    80003f12:	0800                	addi	s0,sp,16
    80003f14:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003f16:	4585                	li	a1,1
    80003f18:	00000097          	auipc	ra,0x0
    80003f1c:	dbe080e7          	jalr	-578(ra) # 80003cd6 <namex>
}
    80003f20:	60a2                	ld	ra,8(sp)
    80003f22:	6402                	ld	s0,0(sp)
    80003f24:	0141                	addi	sp,sp,16
    80003f26:	8082                	ret

0000000080003f28 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003f28:	1101                	addi	sp,sp,-32
    80003f2a:	ec06                	sd	ra,24(sp)
    80003f2c:	e822                	sd	s0,16(sp)
    80003f2e:	e426                	sd	s1,8(sp)
    80003f30:	e04a                	sd	s2,0(sp)
    80003f32:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003f34:	0001d917          	auipc	s2,0x1d
    80003f38:	fec90913          	addi	s2,s2,-20 # 80020f20 <log>
    80003f3c:	01892583          	lw	a1,24(s2)
    80003f40:	02892503          	lw	a0,40(s2)
    80003f44:	fffff097          	auipc	ra,0xfffff
    80003f48:	fe6080e7          	jalr	-26(ra) # 80002f2a <bread>
    80003f4c:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003f4e:	02c92683          	lw	a3,44(s2)
    80003f52:	cd34                	sw	a3,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003f54:	02d05863          	blez	a3,80003f84 <write_head+0x5c>
    80003f58:	0001d797          	auipc	a5,0x1d
    80003f5c:	ff878793          	addi	a5,a5,-8 # 80020f50 <log+0x30>
    80003f60:	05c50713          	addi	a4,a0,92
    80003f64:	36fd                	addiw	a3,a3,-1
    80003f66:	02069613          	slli	a2,a3,0x20
    80003f6a:	01e65693          	srli	a3,a2,0x1e
    80003f6e:	0001d617          	auipc	a2,0x1d
    80003f72:	fe660613          	addi	a2,a2,-26 # 80020f54 <log+0x34>
    80003f76:	96b2                	add	a3,a3,a2
    hb->block[i] = log.lh.block[i];
    80003f78:	4390                	lw	a2,0(a5)
    80003f7a:	c310                	sw	a2,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003f7c:	0791                	addi	a5,a5,4
    80003f7e:	0711                	addi	a4,a4,4 # 43004 <_entry-0x7ffbcffc>
    80003f80:	fed79ce3          	bne	a5,a3,80003f78 <write_head+0x50>
  }
  bwrite(buf);
    80003f84:	8526                	mv	a0,s1
    80003f86:	fffff097          	auipc	ra,0xfffff
    80003f8a:	096080e7          	jalr	150(ra) # 8000301c <bwrite>
  brelse(buf);
    80003f8e:	8526                	mv	a0,s1
    80003f90:	fffff097          	auipc	ra,0xfffff
    80003f94:	0ca080e7          	jalr	202(ra) # 8000305a <brelse>
}
    80003f98:	60e2                	ld	ra,24(sp)
    80003f9a:	6442                	ld	s0,16(sp)
    80003f9c:	64a2                	ld	s1,8(sp)
    80003f9e:	6902                	ld	s2,0(sp)
    80003fa0:	6105                	addi	sp,sp,32
    80003fa2:	8082                	ret

0000000080003fa4 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003fa4:	0001d797          	auipc	a5,0x1d
    80003fa8:	fa87a783          	lw	a5,-88(a5) # 80020f4c <log+0x2c>
    80003fac:	0af05d63          	blez	a5,80004066 <install_trans+0xc2>
{
    80003fb0:	7139                	addi	sp,sp,-64
    80003fb2:	fc06                	sd	ra,56(sp)
    80003fb4:	f822                	sd	s0,48(sp)
    80003fb6:	f426                	sd	s1,40(sp)
    80003fb8:	f04a                	sd	s2,32(sp)
    80003fba:	ec4e                	sd	s3,24(sp)
    80003fbc:	e852                	sd	s4,16(sp)
    80003fbe:	e456                	sd	s5,8(sp)
    80003fc0:	e05a                	sd	s6,0(sp)
    80003fc2:	0080                	addi	s0,sp,64
    80003fc4:	8b2a                	mv	s6,a0
    80003fc6:	0001da97          	auipc	s5,0x1d
    80003fca:	f8aa8a93          	addi	s5,s5,-118 # 80020f50 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003fce:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003fd0:	0001d997          	auipc	s3,0x1d
    80003fd4:	f5098993          	addi	s3,s3,-176 # 80020f20 <log>
    80003fd8:	a00d                	j	80003ffa <install_trans+0x56>
    brelse(lbuf);
    80003fda:	854a                	mv	a0,s2
    80003fdc:	fffff097          	auipc	ra,0xfffff
    80003fe0:	07e080e7          	jalr	126(ra) # 8000305a <brelse>
    brelse(dbuf);
    80003fe4:	8526                	mv	a0,s1
    80003fe6:	fffff097          	auipc	ra,0xfffff
    80003fea:	074080e7          	jalr	116(ra) # 8000305a <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003fee:	2a05                	addiw	s4,s4,1
    80003ff0:	0a91                	addi	s5,s5,4
    80003ff2:	02c9a783          	lw	a5,44(s3)
    80003ff6:	04fa5e63          	bge	s4,a5,80004052 <install_trans+0xae>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003ffa:	0189a583          	lw	a1,24(s3)
    80003ffe:	014585bb          	addw	a1,a1,s4
    80004002:	2585                	addiw	a1,a1,1
    80004004:	0289a503          	lw	a0,40(s3)
    80004008:	fffff097          	auipc	ra,0xfffff
    8000400c:	f22080e7          	jalr	-222(ra) # 80002f2a <bread>
    80004010:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80004012:	000aa583          	lw	a1,0(s5)
    80004016:	0289a503          	lw	a0,40(s3)
    8000401a:	fffff097          	auipc	ra,0xfffff
    8000401e:	f10080e7          	jalr	-240(ra) # 80002f2a <bread>
    80004022:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80004024:	40000613          	li	a2,1024
    80004028:	05890593          	addi	a1,s2,88
    8000402c:	05850513          	addi	a0,a0,88
    80004030:	ffffd097          	auipc	ra,0xffffd
    80004034:	cfc080e7          	jalr	-772(ra) # 80000d2c <memmove>
    bwrite(dbuf);  // write dst to disk
    80004038:	8526                	mv	a0,s1
    8000403a:	fffff097          	auipc	ra,0xfffff
    8000403e:	fe2080e7          	jalr	-30(ra) # 8000301c <bwrite>
    if(recovering == 0)
    80004042:	f80b1ce3          	bnez	s6,80003fda <install_trans+0x36>
      bunpin(dbuf);
    80004046:	8526                	mv	a0,s1
    80004048:	fffff097          	auipc	ra,0xfffff
    8000404c:	0ec080e7          	jalr	236(ra) # 80003134 <bunpin>
    80004050:	b769                	j	80003fda <install_trans+0x36>
}
    80004052:	70e2                	ld	ra,56(sp)
    80004054:	7442                	ld	s0,48(sp)
    80004056:	74a2                	ld	s1,40(sp)
    80004058:	7902                	ld	s2,32(sp)
    8000405a:	69e2                	ld	s3,24(sp)
    8000405c:	6a42                	ld	s4,16(sp)
    8000405e:	6aa2                	ld	s5,8(sp)
    80004060:	6b02                	ld	s6,0(sp)
    80004062:	6121                	addi	sp,sp,64
    80004064:	8082                	ret
    80004066:	8082                	ret

0000000080004068 <initlog>:
{
    80004068:	7179                	addi	sp,sp,-48
    8000406a:	f406                	sd	ra,40(sp)
    8000406c:	f022                	sd	s0,32(sp)
    8000406e:	ec26                	sd	s1,24(sp)
    80004070:	e84a                	sd	s2,16(sp)
    80004072:	e44e                	sd	s3,8(sp)
    80004074:	1800                	addi	s0,sp,48
    80004076:	892a                	mv	s2,a0
    80004078:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    8000407a:	0001d497          	auipc	s1,0x1d
    8000407e:	ea648493          	addi	s1,s1,-346 # 80020f20 <log>
    80004082:	00004597          	auipc	a1,0x4
    80004086:	5a658593          	addi	a1,a1,1446 # 80008628 <syscalls+0x1d8>
    8000408a:	8526                	mv	a0,s1
    8000408c:	ffffd097          	auipc	ra,0xffffd
    80004090:	ab8080e7          	jalr	-1352(ra) # 80000b44 <initlock>
  log.start = sb->logstart;
    80004094:	0149a583          	lw	a1,20(s3)
    80004098:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    8000409a:	0109a783          	lw	a5,16(s3)
    8000409e:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    800040a0:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    800040a4:	854a                	mv	a0,s2
    800040a6:	fffff097          	auipc	ra,0xfffff
    800040aa:	e84080e7          	jalr	-380(ra) # 80002f2a <bread>
  log.lh.n = lh->n;
    800040ae:	4d34                	lw	a3,88(a0)
    800040b0:	d4d4                	sw	a3,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    800040b2:	02d05663          	blez	a3,800040de <initlog+0x76>
    800040b6:	05c50793          	addi	a5,a0,92
    800040ba:	0001d717          	auipc	a4,0x1d
    800040be:	e9670713          	addi	a4,a4,-362 # 80020f50 <log+0x30>
    800040c2:	36fd                	addiw	a3,a3,-1
    800040c4:	02069613          	slli	a2,a3,0x20
    800040c8:	01e65693          	srli	a3,a2,0x1e
    800040cc:	06050613          	addi	a2,a0,96
    800040d0:	96b2                	add	a3,a3,a2
    log.lh.block[i] = lh->block[i];
    800040d2:	4390                	lw	a2,0(a5)
    800040d4:	c310                	sw	a2,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    800040d6:	0791                	addi	a5,a5,4
    800040d8:	0711                	addi	a4,a4,4
    800040da:	fed79ce3          	bne	a5,a3,800040d2 <initlog+0x6a>
  brelse(buf);
    800040de:	fffff097          	auipc	ra,0xfffff
    800040e2:	f7c080e7          	jalr	-132(ra) # 8000305a <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    800040e6:	4505                	li	a0,1
    800040e8:	00000097          	auipc	ra,0x0
    800040ec:	ebc080e7          	jalr	-324(ra) # 80003fa4 <install_trans>
  log.lh.n = 0;
    800040f0:	0001d797          	auipc	a5,0x1d
    800040f4:	e407ae23          	sw	zero,-420(a5) # 80020f4c <log+0x2c>
  write_head(); // clear the log
    800040f8:	00000097          	auipc	ra,0x0
    800040fc:	e30080e7          	jalr	-464(ra) # 80003f28 <write_head>
}
    80004100:	70a2                	ld	ra,40(sp)
    80004102:	7402                	ld	s0,32(sp)
    80004104:	64e2                	ld	s1,24(sp)
    80004106:	6942                	ld	s2,16(sp)
    80004108:	69a2                	ld	s3,8(sp)
    8000410a:	6145                	addi	sp,sp,48
    8000410c:	8082                	ret

000000008000410e <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    8000410e:	1101                	addi	sp,sp,-32
    80004110:	ec06                	sd	ra,24(sp)
    80004112:	e822                	sd	s0,16(sp)
    80004114:	e426                	sd	s1,8(sp)
    80004116:	e04a                	sd	s2,0(sp)
    80004118:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    8000411a:	0001d517          	auipc	a0,0x1d
    8000411e:	e0650513          	addi	a0,a0,-506 # 80020f20 <log>
    80004122:	ffffd097          	auipc	ra,0xffffd
    80004126:	ab2080e7          	jalr	-1358(ra) # 80000bd4 <acquire>
  while(1){
    if(log.committing){
    8000412a:	0001d497          	auipc	s1,0x1d
    8000412e:	df648493          	addi	s1,s1,-522 # 80020f20 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80004132:	4979                	li	s2,30
    80004134:	a039                	j	80004142 <begin_op+0x34>
      sleep(&log, &log.lock);
    80004136:	85a6                	mv	a1,s1
    80004138:	8526                	mv	a0,s1
    8000413a:	ffffe097          	auipc	ra,0xffffe
    8000413e:	01c080e7          	jalr	28(ra) # 80002156 <sleep>
    if(log.committing){
    80004142:	50dc                	lw	a5,36(s1)
    80004144:	fbed                	bnez	a5,80004136 <begin_op+0x28>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80004146:	5098                	lw	a4,32(s1)
    80004148:	2705                	addiw	a4,a4,1
    8000414a:	0007069b          	sext.w	a3,a4
    8000414e:	0027179b          	slliw	a5,a4,0x2
    80004152:	9fb9                	addw	a5,a5,a4
    80004154:	0017979b          	slliw	a5,a5,0x1
    80004158:	54d8                	lw	a4,44(s1)
    8000415a:	9fb9                	addw	a5,a5,a4
    8000415c:	00f95963          	bge	s2,a5,8000416e <begin_op+0x60>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80004160:	85a6                	mv	a1,s1
    80004162:	8526                	mv	a0,s1
    80004164:	ffffe097          	auipc	ra,0xffffe
    80004168:	ff2080e7          	jalr	-14(ra) # 80002156 <sleep>
    8000416c:	bfd9                	j	80004142 <begin_op+0x34>
    } else {
      log.outstanding += 1;
    8000416e:	0001d517          	auipc	a0,0x1d
    80004172:	db250513          	addi	a0,a0,-590 # 80020f20 <log>
    80004176:	d114                	sw	a3,32(a0)
      release(&log.lock);
    80004178:	ffffd097          	auipc	ra,0xffffd
    8000417c:	b10080e7          	jalr	-1264(ra) # 80000c88 <release>
      break;
    }
  }
}
    80004180:	60e2                	ld	ra,24(sp)
    80004182:	6442                	ld	s0,16(sp)
    80004184:	64a2                	ld	s1,8(sp)
    80004186:	6902                	ld	s2,0(sp)
    80004188:	6105                	addi	sp,sp,32
    8000418a:	8082                	ret

000000008000418c <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    8000418c:	7139                	addi	sp,sp,-64
    8000418e:	fc06                	sd	ra,56(sp)
    80004190:	f822                	sd	s0,48(sp)
    80004192:	f426                	sd	s1,40(sp)
    80004194:	f04a                	sd	s2,32(sp)
    80004196:	ec4e                	sd	s3,24(sp)
    80004198:	e852                	sd	s4,16(sp)
    8000419a:	e456                	sd	s5,8(sp)
    8000419c:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    8000419e:	0001d497          	auipc	s1,0x1d
    800041a2:	d8248493          	addi	s1,s1,-638 # 80020f20 <log>
    800041a6:	8526                	mv	a0,s1
    800041a8:	ffffd097          	auipc	ra,0xffffd
    800041ac:	a2c080e7          	jalr	-1492(ra) # 80000bd4 <acquire>
  log.outstanding -= 1;
    800041b0:	509c                	lw	a5,32(s1)
    800041b2:	37fd                	addiw	a5,a5,-1
    800041b4:	0007891b          	sext.w	s2,a5
    800041b8:	d09c                	sw	a5,32(s1)
  if(log.committing)
    800041ba:	50dc                	lw	a5,36(s1)
    800041bc:	e7b9                	bnez	a5,8000420a <end_op+0x7e>
    panic("log.committing");
  if(log.outstanding == 0){
    800041be:	04091e63          	bnez	s2,8000421a <end_op+0x8e>
    do_commit = 1;
    log.committing = 1;
    800041c2:	0001d497          	auipc	s1,0x1d
    800041c6:	d5e48493          	addi	s1,s1,-674 # 80020f20 <log>
    800041ca:	4785                	li	a5,1
    800041cc:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    800041ce:	8526                	mv	a0,s1
    800041d0:	ffffd097          	auipc	ra,0xffffd
    800041d4:	ab8080e7          	jalr	-1352(ra) # 80000c88 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    800041d8:	54dc                	lw	a5,44(s1)
    800041da:	06f04763          	bgtz	a5,80004248 <end_op+0xbc>
    acquire(&log.lock);
    800041de:	0001d497          	auipc	s1,0x1d
    800041e2:	d4248493          	addi	s1,s1,-702 # 80020f20 <log>
    800041e6:	8526                	mv	a0,s1
    800041e8:	ffffd097          	auipc	ra,0xffffd
    800041ec:	9ec080e7          	jalr	-1556(ra) # 80000bd4 <acquire>
    log.committing = 0;
    800041f0:	0204a223          	sw	zero,36(s1)
    wakeup(&log);
    800041f4:	8526                	mv	a0,s1
    800041f6:	ffffe097          	auipc	ra,0xffffe
    800041fa:	fd6080e7          	jalr	-42(ra) # 800021cc <wakeup>
    release(&log.lock);
    800041fe:	8526                	mv	a0,s1
    80004200:	ffffd097          	auipc	ra,0xffffd
    80004204:	a88080e7          	jalr	-1400(ra) # 80000c88 <release>
}
    80004208:	a03d                	j	80004236 <end_op+0xaa>
    panic("log.committing");
    8000420a:	00004517          	auipc	a0,0x4
    8000420e:	42650513          	addi	a0,a0,1062 # 80008630 <syscalls+0x1e0>
    80004212:	ffffc097          	auipc	ra,0xffffc
    80004216:	32c080e7          	jalr	812(ra) # 8000053e <panic>
    wakeup(&log);
    8000421a:	0001d497          	auipc	s1,0x1d
    8000421e:	d0648493          	addi	s1,s1,-762 # 80020f20 <log>
    80004222:	8526                	mv	a0,s1
    80004224:	ffffe097          	auipc	ra,0xffffe
    80004228:	fa8080e7          	jalr	-88(ra) # 800021cc <wakeup>
  release(&log.lock);
    8000422c:	8526                	mv	a0,s1
    8000422e:	ffffd097          	auipc	ra,0xffffd
    80004232:	a5a080e7          	jalr	-1446(ra) # 80000c88 <release>
}
    80004236:	70e2                	ld	ra,56(sp)
    80004238:	7442                	ld	s0,48(sp)
    8000423a:	74a2                	ld	s1,40(sp)
    8000423c:	7902                	ld	s2,32(sp)
    8000423e:	69e2                	ld	s3,24(sp)
    80004240:	6a42                	ld	s4,16(sp)
    80004242:	6aa2                	ld	s5,8(sp)
    80004244:	6121                	addi	sp,sp,64
    80004246:	8082                	ret
  for (tail = 0; tail < log.lh.n; tail++) {
    80004248:	0001da97          	auipc	s5,0x1d
    8000424c:	d08a8a93          	addi	s5,s5,-760 # 80020f50 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80004250:	0001da17          	auipc	s4,0x1d
    80004254:	cd0a0a13          	addi	s4,s4,-816 # 80020f20 <log>
    80004258:	018a2583          	lw	a1,24(s4)
    8000425c:	012585bb          	addw	a1,a1,s2
    80004260:	2585                	addiw	a1,a1,1
    80004262:	028a2503          	lw	a0,40(s4)
    80004266:	fffff097          	auipc	ra,0xfffff
    8000426a:	cc4080e7          	jalr	-828(ra) # 80002f2a <bread>
    8000426e:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80004270:	000aa583          	lw	a1,0(s5)
    80004274:	028a2503          	lw	a0,40(s4)
    80004278:	fffff097          	auipc	ra,0xfffff
    8000427c:	cb2080e7          	jalr	-846(ra) # 80002f2a <bread>
    80004280:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80004282:	40000613          	li	a2,1024
    80004286:	05850593          	addi	a1,a0,88
    8000428a:	05848513          	addi	a0,s1,88
    8000428e:	ffffd097          	auipc	ra,0xffffd
    80004292:	a9e080e7          	jalr	-1378(ra) # 80000d2c <memmove>
    bwrite(to);  // write the log
    80004296:	8526                	mv	a0,s1
    80004298:	fffff097          	auipc	ra,0xfffff
    8000429c:	d84080e7          	jalr	-636(ra) # 8000301c <bwrite>
    brelse(from);
    800042a0:	854e                	mv	a0,s3
    800042a2:	fffff097          	auipc	ra,0xfffff
    800042a6:	db8080e7          	jalr	-584(ra) # 8000305a <brelse>
    brelse(to);
    800042aa:	8526                	mv	a0,s1
    800042ac:	fffff097          	auipc	ra,0xfffff
    800042b0:	dae080e7          	jalr	-594(ra) # 8000305a <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    800042b4:	2905                	addiw	s2,s2,1
    800042b6:	0a91                	addi	s5,s5,4
    800042b8:	02ca2783          	lw	a5,44(s4)
    800042bc:	f8f94ee3          	blt	s2,a5,80004258 <end_op+0xcc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    800042c0:	00000097          	auipc	ra,0x0
    800042c4:	c68080e7          	jalr	-920(ra) # 80003f28 <write_head>
    install_trans(0); // Now install writes to home locations
    800042c8:	4501                	li	a0,0
    800042ca:	00000097          	auipc	ra,0x0
    800042ce:	cda080e7          	jalr	-806(ra) # 80003fa4 <install_trans>
    log.lh.n = 0;
    800042d2:	0001d797          	auipc	a5,0x1d
    800042d6:	c607ad23          	sw	zero,-902(a5) # 80020f4c <log+0x2c>
    write_head();    // Erase the transaction from the log
    800042da:	00000097          	auipc	ra,0x0
    800042de:	c4e080e7          	jalr	-946(ra) # 80003f28 <write_head>
    800042e2:	bdf5                	j	800041de <end_op+0x52>

00000000800042e4 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    800042e4:	1101                	addi	sp,sp,-32
    800042e6:	ec06                	sd	ra,24(sp)
    800042e8:	e822                	sd	s0,16(sp)
    800042ea:	e426                	sd	s1,8(sp)
    800042ec:	e04a                	sd	s2,0(sp)
    800042ee:	1000                	addi	s0,sp,32
    800042f0:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    800042f2:	0001d917          	auipc	s2,0x1d
    800042f6:	c2e90913          	addi	s2,s2,-978 # 80020f20 <log>
    800042fa:	854a                	mv	a0,s2
    800042fc:	ffffd097          	auipc	ra,0xffffd
    80004300:	8d8080e7          	jalr	-1832(ra) # 80000bd4 <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    80004304:	02c92603          	lw	a2,44(s2)
    80004308:	47f5                	li	a5,29
    8000430a:	06c7c563          	blt	a5,a2,80004374 <log_write+0x90>
    8000430e:	0001d797          	auipc	a5,0x1d
    80004312:	c2e7a783          	lw	a5,-978(a5) # 80020f3c <log+0x1c>
    80004316:	37fd                	addiw	a5,a5,-1
    80004318:	04f65e63          	bge	a2,a5,80004374 <log_write+0x90>
    panic("too big a transaction");
  if (log.outstanding < 1)
    8000431c:	0001d797          	auipc	a5,0x1d
    80004320:	c247a783          	lw	a5,-988(a5) # 80020f40 <log+0x20>
    80004324:	06f05063          	blez	a5,80004384 <log_write+0xa0>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80004328:	4781                	li	a5,0
    8000432a:	06c05563          	blez	a2,80004394 <log_write+0xb0>
    if (log.lh.block[i] == b->blockno)   // log absorption
    8000432e:	44cc                	lw	a1,12(s1)
    80004330:	0001d717          	auipc	a4,0x1d
    80004334:	c2070713          	addi	a4,a4,-992 # 80020f50 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    80004338:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    8000433a:	4314                	lw	a3,0(a4)
    8000433c:	04b68c63          	beq	a3,a1,80004394 <log_write+0xb0>
  for (i = 0; i < log.lh.n; i++) {
    80004340:	2785                	addiw	a5,a5,1
    80004342:	0711                	addi	a4,a4,4
    80004344:	fef61be3          	bne	a2,a5,8000433a <log_write+0x56>
      break;
  }
  log.lh.block[i] = b->blockno;
    80004348:	0621                	addi	a2,a2,8
    8000434a:	060a                	slli	a2,a2,0x2
    8000434c:	0001d797          	auipc	a5,0x1d
    80004350:	bd478793          	addi	a5,a5,-1068 # 80020f20 <log>
    80004354:	97b2                	add	a5,a5,a2
    80004356:	44d8                	lw	a4,12(s1)
    80004358:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    8000435a:	8526                	mv	a0,s1
    8000435c:	fffff097          	auipc	ra,0xfffff
    80004360:	d9c080e7          	jalr	-612(ra) # 800030f8 <bpin>
    log.lh.n++;
    80004364:	0001d717          	auipc	a4,0x1d
    80004368:	bbc70713          	addi	a4,a4,-1092 # 80020f20 <log>
    8000436c:	575c                	lw	a5,44(a4)
    8000436e:	2785                	addiw	a5,a5,1
    80004370:	d75c                	sw	a5,44(a4)
    80004372:	a82d                	j	800043ac <log_write+0xc8>
    panic("too big a transaction");
    80004374:	00004517          	auipc	a0,0x4
    80004378:	2cc50513          	addi	a0,a0,716 # 80008640 <syscalls+0x1f0>
    8000437c:	ffffc097          	auipc	ra,0xffffc
    80004380:	1c2080e7          	jalr	450(ra) # 8000053e <panic>
    panic("log_write outside of trans");
    80004384:	00004517          	auipc	a0,0x4
    80004388:	2d450513          	addi	a0,a0,724 # 80008658 <syscalls+0x208>
    8000438c:	ffffc097          	auipc	ra,0xffffc
    80004390:	1b2080e7          	jalr	434(ra) # 8000053e <panic>
  log.lh.block[i] = b->blockno;
    80004394:	00878693          	addi	a3,a5,8
    80004398:	068a                	slli	a3,a3,0x2
    8000439a:	0001d717          	auipc	a4,0x1d
    8000439e:	b8670713          	addi	a4,a4,-1146 # 80020f20 <log>
    800043a2:	9736                	add	a4,a4,a3
    800043a4:	44d4                	lw	a3,12(s1)
    800043a6:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    800043a8:	faf609e3          	beq	a2,a5,8000435a <log_write+0x76>
  }
  release(&log.lock);
    800043ac:	0001d517          	auipc	a0,0x1d
    800043b0:	b7450513          	addi	a0,a0,-1164 # 80020f20 <log>
    800043b4:	ffffd097          	auipc	ra,0xffffd
    800043b8:	8d4080e7          	jalr	-1836(ra) # 80000c88 <release>
}
    800043bc:	60e2                	ld	ra,24(sp)
    800043be:	6442                	ld	s0,16(sp)
    800043c0:	64a2                	ld	s1,8(sp)
    800043c2:	6902                	ld	s2,0(sp)
    800043c4:	6105                	addi	sp,sp,32
    800043c6:	8082                	ret

00000000800043c8 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    800043c8:	1101                	addi	sp,sp,-32
    800043ca:	ec06                	sd	ra,24(sp)
    800043cc:	e822                	sd	s0,16(sp)
    800043ce:	e426                	sd	s1,8(sp)
    800043d0:	e04a                	sd	s2,0(sp)
    800043d2:	1000                	addi	s0,sp,32
    800043d4:	84aa                	mv	s1,a0
    800043d6:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    800043d8:	00004597          	auipc	a1,0x4
    800043dc:	2a058593          	addi	a1,a1,672 # 80008678 <syscalls+0x228>
    800043e0:	0521                	addi	a0,a0,8
    800043e2:	ffffc097          	auipc	ra,0xffffc
    800043e6:	762080e7          	jalr	1890(ra) # 80000b44 <initlock>
  lk->name = name;
    800043ea:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    800043ee:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800043f2:	0204a423          	sw	zero,40(s1)
}
    800043f6:	60e2                	ld	ra,24(sp)
    800043f8:	6442                	ld	s0,16(sp)
    800043fa:	64a2                	ld	s1,8(sp)
    800043fc:	6902                	ld	s2,0(sp)
    800043fe:	6105                	addi	sp,sp,32
    80004400:	8082                	ret

0000000080004402 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80004402:	1101                	addi	sp,sp,-32
    80004404:	ec06                	sd	ra,24(sp)
    80004406:	e822                	sd	s0,16(sp)
    80004408:	e426                	sd	s1,8(sp)
    8000440a:	e04a                	sd	s2,0(sp)
    8000440c:	1000                	addi	s0,sp,32
    8000440e:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80004410:	00850913          	addi	s2,a0,8
    80004414:	854a                	mv	a0,s2
    80004416:	ffffc097          	auipc	ra,0xffffc
    8000441a:	7be080e7          	jalr	1982(ra) # 80000bd4 <acquire>
  while (lk->locked) {
    8000441e:	409c                	lw	a5,0(s1)
    80004420:	cb89                	beqz	a5,80004432 <acquiresleep+0x30>
    sleep(lk, &lk->lk);
    80004422:	85ca                	mv	a1,s2
    80004424:	8526                	mv	a0,s1
    80004426:	ffffe097          	auipc	ra,0xffffe
    8000442a:	d30080e7          	jalr	-720(ra) # 80002156 <sleep>
  while (lk->locked) {
    8000442e:	409c                	lw	a5,0(s1)
    80004430:	fbed                	bnez	a5,80004422 <acquiresleep+0x20>
  }
  lk->locked = 1;
    80004432:	4785                	li	a5,1
    80004434:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80004436:	ffffd097          	auipc	ra,0xffffd
    8000443a:	574080e7          	jalr	1396(ra) # 800019aa <myproc>
    8000443e:	591c                	lw	a5,48(a0)
    80004440:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80004442:	854a                	mv	a0,s2
    80004444:	ffffd097          	auipc	ra,0xffffd
    80004448:	844080e7          	jalr	-1980(ra) # 80000c88 <release>
}
    8000444c:	60e2                	ld	ra,24(sp)
    8000444e:	6442                	ld	s0,16(sp)
    80004450:	64a2                	ld	s1,8(sp)
    80004452:	6902                	ld	s2,0(sp)
    80004454:	6105                	addi	sp,sp,32
    80004456:	8082                	ret

0000000080004458 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80004458:	1101                	addi	sp,sp,-32
    8000445a:	ec06                	sd	ra,24(sp)
    8000445c:	e822                	sd	s0,16(sp)
    8000445e:	e426                	sd	s1,8(sp)
    80004460:	e04a                	sd	s2,0(sp)
    80004462:	1000                	addi	s0,sp,32
    80004464:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80004466:	00850913          	addi	s2,a0,8
    8000446a:	854a                	mv	a0,s2
    8000446c:	ffffc097          	auipc	ra,0xffffc
    80004470:	768080e7          	jalr	1896(ra) # 80000bd4 <acquire>
  lk->locked = 0;
    80004474:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004478:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    8000447c:	8526                	mv	a0,s1
    8000447e:	ffffe097          	auipc	ra,0xffffe
    80004482:	d4e080e7          	jalr	-690(ra) # 800021cc <wakeup>
  release(&lk->lk);
    80004486:	854a                	mv	a0,s2
    80004488:	ffffd097          	auipc	ra,0xffffd
    8000448c:	800080e7          	jalr	-2048(ra) # 80000c88 <release>
}
    80004490:	60e2                	ld	ra,24(sp)
    80004492:	6442                	ld	s0,16(sp)
    80004494:	64a2                	ld	s1,8(sp)
    80004496:	6902                	ld	s2,0(sp)
    80004498:	6105                	addi	sp,sp,32
    8000449a:	8082                	ret

000000008000449c <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    8000449c:	7179                	addi	sp,sp,-48
    8000449e:	f406                	sd	ra,40(sp)
    800044a0:	f022                	sd	s0,32(sp)
    800044a2:	ec26                	sd	s1,24(sp)
    800044a4:	e84a                	sd	s2,16(sp)
    800044a6:	e44e                	sd	s3,8(sp)
    800044a8:	1800                	addi	s0,sp,48
    800044aa:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    800044ac:	00850913          	addi	s2,a0,8
    800044b0:	854a                	mv	a0,s2
    800044b2:	ffffc097          	auipc	ra,0xffffc
    800044b6:	722080e7          	jalr	1826(ra) # 80000bd4 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    800044ba:	409c                	lw	a5,0(s1)
    800044bc:	ef99                	bnez	a5,800044da <holdingsleep+0x3e>
    800044be:	4481                	li	s1,0
  release(&lk->lk);
    800044c0:	854a                	mv	a0,s2
    800044c2:	ffffc097          	auipc	ra,0xffffc
    800044c6:	7c6080e7          	jalr	1990(ra) # 80000c88 <release>
  return r;
}
    800044ca:	8526                	mv	a0,s1
    800044cc:	70a2                	ld	ra,40(sp)
    800044ce:	7402                	ld	s0,32(sp)
    800044d0:	64e2                	ld	s1,24(sp)
    800044d2:	6942                	ld	s2,16(sp)
    800044d4:	69a2                	ld	s3,8(sp)
    800044d6:	6145                	addi	sp,sp,48
    800044d8:	8082                	ret
  r = lk->locked && (lk->pid == myproc()->pid);
    800044da:	0284a983          	lw	s3,40(s1)
    800044de:	ffffd097          	auipc	ra,0xffffd
    800044e2:	4cc080e7          	jalr	1228(ra) # 800019aa <myproc>
    800044e6:	5904                	lw	s1,48(a0)
    800044e8:	413484b3          	sub	s1,s1,s3
    800044ec:	0014b493          	seqz	s1,s1
    800044f0:	bfc1                	j	800044c0 <holdingsleep+0x24>

00000000800044f2 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    800044f2:	1141                	addi	sp,sp,-16
    800044f4:	e406                	sd	ra,8(sp)
    800044f6:	e022                	sd	s0,0(sp)
    800044f8:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    800044fa:	00004597          	auipc	a1,0x4
    800044fe:	18e58593          	addi	a1,a1,398 # 80008688 <syscalls+0x238>
    80004502:	0001d517          	auipc	a0,0x1d
    80004506:	b6650513          	addi	a0,a0,-1178 # 80021068 <ftable>
    8000450a:	ffffc097          	auipc	ra,0xffffc
    8000450e:	63a080e7          	jalr	1594(ra) # 80000b44 <initlock>
}
    80004512:	60a2                	ld	ra,8(sp)
    80004514:	6402                	ld	s0,0(sp)
    80004516:	0141                	addi	sp,sp,16
    80004518:	8082                	ret

000000008000451a <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    8000451a:	1101                	addi	sp,sp,-32
    8000451c:	ec06                	sd	ra,24(sp)
    8000451e:	e822                	sd	s0,16(sp)
    80004520:	e426                	sd	s1,8(sp)
    80004522:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80004524:	0001d517          	auipc	a0,0x1d
    80004528:	b4450513          	addi	a0,a0,-1212 # 80021068 <ftable>
    8000452c:	ffffc097          	auipc	ra,0xffffc
    80004530:	6a8080e7          	jalr	1704(ra) # 80000bd4 <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80004534:	0001d497          	auipc	s1,0x1d
    80004538:	b4c48493          	addi	s1,s1,-1204 # 80021080 <ftable+0x18>
    8000453c:	0001e717          	auipc	a4,0x1e
    80004540:	ae470713          	addi	a4,a4,-1308 # 80022020 <disk>
    if(f->ref == 0){
    80004544:	40dc                	lw	a5,4(s1)
    80004546:	cf99                	beqz	a5,80004564 <filealloc+0x4a>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80004548:	02848493          	addi	s1,s1,40
    8000454c:	fee49ce3          	bne	s1,a4,80004544 <filealloc+0x2a>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80004550:	0001d517          	auipc	a0,0x1d
    80004554:	b1850513          	addi	a0,a0,-1256 # 80021068 <ftable>
    80004558:	ffffc097          	auipc	ra,0xffffc
    8000455c:	730080e7          	jalr	1840(ra) # 80000c88 <release>
  return 0;
    80004560:	4481                	li	s1,0
    80004562:	a819                	j	80004578 <filealloc+0x5e>
      f->ref = 1;
    80004564:	4785                	li	a5,1
    80004566:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80004568:	0001d517          	auipc	a0,0x1d
    8000456c:	b0050513          	addi	a0,a0,-1280 # 80021068 <ftable>
    80004570:	ffffc097          	auipc	ra,0xffffc
    80004574:	718080e7          	jalr	1816(ra) # 80000c88 <release>
}
    80004578:	8526                	mv	a0,s1
    8000457a:	60e2                	ld	ra,24(sp)
    8000457c:	6442                	ld	s0,16(sp)
    8000457e:	64a2                	ld	s1,8(sp)
    80004580:	6105                	addi	sp,sp,32
    80004582:	8082                	ret

0000000080004584 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    80004584:	1101                	addi	sp,sp,-32
    80004586:	ec06                	sd	ra,24(sp)
    80004588:	e822                	sd	s0,16(sp)
    8000458a:	e426                	sd	s1,8(sp)
    8000458c:	1000                	addi	s0,sp,32
    8000458e:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80004590:	0001d517          	auipc	a0,0x1d
    80004594:	ad850513          	addi	a0,a0,-1320 # 80021068 <ftable>
    80004598:	ffffc097          	auipc	ra,0xffffc
    8000459c:	63c080e7          	jalr	1596(ra) # 80000bd4 <acquire>
  if(f->ref < 1)
    800045a0:	40dc                	lw	a5,4(s1)
    800045a2:	02f05263          	blez	a5,800045c6 <filedup+0x42>
    panic("filedup");
  f->ref++;
    800045a6:	2785                	addiw	a5,a5,1
    800045a8:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    800045aa:	0001d517          	auipc	a0,0x1d
    800045ae:	abe50513          	addi	a0,a0,-1346 # 80021068 <ftable>
    800045b2:	ffffc097          	auipc	ra,0xffffc
    800045b6:	6d6080e7          	jalr	1750(ra) # 80000c88 <release>
  return f;
}
    800045ba:	8526                	mv	a0,s1
    800045bc:	60e2                	ld	ra,24(sp)
    800045be:	6442                	ld	s0,16(sp)
    800045c0:	64a2                	ld	s1,8(sp)
    800045c2:	6105                	addi	sp,sp,32
    800045c4:	8082                	ret
    panic("filedup");
    800045c6:	00004517          	auipc	a0,0x4
    800045ca:	0ca50513          	addi	a0,a0,202 # 80008690 <syscalls+0x240>
    800045ce:	ffffc097          	auipc	ra,0xffffc
    800045d2:	f70080e7          	jalr	-144(ra) # 8000053e <panic>

00000000800045d6 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    800045d6:	7139                	addi	sp,sp,-64
    800045d8:	fc06                	sd	ra,56(sp)
    800045da:	f822                	sd	s0,48(sp)
    800045dc:	f426                	sd	s1,40(sp)
    800045de:	f04a                	sd	s2,32(sp)
    800045e0:	ec4e                	sd	s3,24(sp)
    800045e2:	e852                	sd	s4,16(sp)
    800045e4:	e456                	sd	s5,8(sp)
    800045e6:	0080                	addi	s0,sp,64
    800045e8:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    800045ea:	0001d517          	auipc	a0,0x1d
    800045ee:	a7e50513          	addi	a0,a0,-1410 # 80021068 <ftable>
    800045f2:	ffffc097          	auipc	ra,0xffffc
    800045f6:	5e2080e7          	jalr	1506(ra) # 80000bd4 <acquire>
  if(f->ref < 1)
    800045fa:	40dc                	lw	a5,4(s1)
    800045fc:	06f05163          	blez	a5,8000465e <fileclose+0x88>
    panic("fileclose");
  if(--f->ref > 0){
    80004600:	37fd                	addiw	a5,a5,-1
    80004602:	0007871b          	sext.w	a4,a5
    80004606:	c0dc                	sw	a5,4(s1)
    80004608:	06e04363          	bgtz	a4,8000466e <fileclose+0x98>
    release(&ftable.lock);
    return;
  }
  ff = *f;
    8000460c:	0004a903          	lw	s2,0(s1)
    80004610:	0094ca83          	lbu	s5,9(s1)
    80004614:	0104ba03          	ld	s4,16(s1)
    80004618:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    8000461c:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80004620:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80004624:	0001d517          	auipc	a0,0x1d
    80004628:	a4450513          	addi	a0,a0,-1468 # 80021068 <ftable>
    8000462c:	ffffc097          	auipc	ra,0xffffc
    80004630:	65c080e7          	jalr	1628(ra) # 80000c88 <release>

  if(ff.type == FD_PIPE){
    80004634:	4785                	li	a5,1
    80004636:	04f90d63          	beq	s2,a5,80004690 <fileclose+0xba>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    8000463a:	3979                	addiw	s2,s2,-2
    8000463c:	4785                	li	a5,1
    8000463e:	0527e063          	bltu	a5,s2,8000467e <fileclose+0xa8>
    begin_op();
    80004642:	00000097          	auipc	ra,0x0
    80004646:	acc080e7          	jalr	-1332(ra) # 8000410e <begin_op>
    iput(ff.ip);
    8000464a:	854e                	mv	a0,s3
    8000464c:	fffff097          	auipc	ra,0xfffff
    80004650:	2b0080e7          	jalr	688(ra) # 800038fc <iput>
    end_op();
    80004654:	00000097          	auipc	ra,0x0
    80004658:	b38080e7          	jalr	-1224(ra) # 8000418c <end_op>
    8000465c:	a00d                	j	8000467e <fileclose+0xa8>
    panic("fileclose");
    8000465e:	00004517          	auipc	a0,0x4
    80004662:	03a50513          	addi	a0,a0,58 # 80008698 <syscalls+0x248>
    80004666:	ffffc097          	auipc	ra,0xffffc
    8000466a:	ed8080e7          	jalr	-296(ra) # 8000053e <panic>
    release(&ftable.lock);
    8000466e:	0001d517          	auipc	a0,0x1d
    80004672:	9fa50513          	addi	a0,a0,-1542 # 80021068 <ftable>
    80004676:	ffffc097          	auipc	ra,0xffffc
    8000467a:	612080e7          	jalr	1554(ra) # 80000c88 <release>
  }
}
    8000467e:	70e2                	ld	ra,56(sp)
    80004680:	7442                	ld	s0,48(sp)
    80004682:	74a2                	ld	s1,40(sp)
    80004684:	7902                	ld	s2,32(sp)
    80004686:	69e2                	ld	s3,24(sp)
    80004688:	6a42                	ld	s4,16(sp)
    8000468a:	6aa2                	ld	s5,8(sp)
    8000468c:	6121                	addi	sp,sp,64
    8000468e:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    80004690:	85d6                	mv	a1,s5
    80004692:	8552                	mv	a0,s4
    80004694:	00000097          	auipc	ra,0x0
    80004698:	34c080e7          	jalr	844(ra) # 800049e0 <pipeclose>
    8000469c:	b7cd                	j	8000467e <fileclose+0xa8>

000000008000469e <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    8000469e:	715d                	addi	sp,sp,-80
    800046a0:	e486                	sd	ra,72(sp)
    800046a2:	e0a2                	sd	s0,64(sp)
    800046a4:	fc26                	sd	s1,56(sp)
    800046a6:	f84a                	sd	s2,48(sp)
    800046a8:	f44e                	sd	s3,40(sp)
    800046aa:	0880                	addi	s0,sp,80
    800046ac:	84aa                	mv	s1,a0
    800046ae:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    800046b0:	ffffd097          	auipc	ra,0xffffd
    800046b4:	2fa080e7          	jalr	762(ra) # 800019aa <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    800046b8:	409c                	lw	a5,0(s1)
    800046ba:	37f9                	addiw	a5,a5,-2
    800046bc:	4705                	li	a4,1
    800046be:	04f76763          	bltu	a4,a5,8000470c <filestat+0x6e>
    800046c2:	892a                	mv	s2,a0
    ilock(f->ip);
    800046c4:	6c88                	ld	a0,24(s1)
    800046c6:	fffff097          	auipc	ra,0xfffff
    800046ca:	07c080e7          	jalr	124(ra) # 80003742 <ilock>
    stati(f->ip, &st);
    800046ce:	fb840593          	addi	a1,s0,-72
    800046d2:	6c88                	ld	a0,24(s1)
    800046d4:	fffff097          	auipc	ra,0xfffff
    800046d8:	2f8080e7          	jalr	760(ra) # 800039cc <stati>
    iunlock(f->ip);
    800046dc:	6c88                	ld	a0,24(s1)
    800046de:	fffff097          	auipc	ra,0xfffff
    800046e2:	126080e7          	jalr	294(ra) # 80003804 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    800046e6:	46e1                	li	a3,24
    800046e8:	fb840613          	addi	a2,s0,-72
    800046ec:	85ce                	mv	a1,s3
    800046ee:	05093503          	ld	a0,80(s2)
    800046f2:	ffffd097          	auipc	ra,0xffffd
    800046f6:	f78080e7          	jalr	-136(ra) # 8000166a <copyout>
    800046fa:	41f5551b          	sraiw	a0,a0,0x1f
      return -1;
    return 0;
  }
  return -1;
}
    800046fe:	60a6                	ld	ra,72(sp)
    80004700:	6406                	ld	s0,64(sp)
    80004702:	74e2                	ld	s1,56(sp)
    80004704:	7942                	ld	s2,48(sp)
    80004706:	79a2                	ld	s3,40(sp)
    80004708:	6161                	addi	sp,sp,80
    8000470a:	8082                	ret
  return -1;
    8000470c:	557d                	li	a0,-1
    8000470e:	bfc5                	j	800046fe <filestat+0x60>

0000000080004710 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80004710:	7179                	addi	sp,sp,-48
    80004712:	f406                	sd	ra,40(sp)
    80004714:	f022                	sd	s0,32(sp)
    80004716:	ec26                	sd	s1,24(sp)
    80004718:	e84a                	sd	s2,16(sp)
    8000471a:	e44e                	sd	s3,8(sp)
    8000471c:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    8000471e:	00854783          	lbu	a5,8(a0)
    80004722:	c3d5                	beqz	a5,800047c6 <fileread+0xb6>
    80004724:	84aa                	mv	s1,a0
    80004726:	89ae                	mv	s3,a1
    80004728:	8932                	mv	s2,a2
    return -1;

  if(f->type == FD_PIPE){
    8000472a:	411c                	lw	a5,0(a0)
    8000472c:	4705                	li	a4,1
    8000472e:	04e78963          	beq	a5,a4,80004780 <fileread+0x70>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80004732:	470d                	li	a4,3
    80004734:	04e78d63          	beq	a5,a4,8000478e <fileread+0x7e>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    80004738:	4709                	li	a4,2
    8000473a:	06e79e63          	bne	a5,a4,800047b6 <fileread+0xa6>
    ilock(f->ip);
    8000473e:	6d08                	ld	a0,24(a0)
    80004740:	fffff097          	auipc	ra,0xfffff
    80004744:	002080e7          	jalr	2(ra) # 80003742 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80004748:	874a                	mv	a4,s2
    8000474a:	5094                	lw	a3,32(s1)
    8000474c:	864e                	mv	a2,s3
    8000474e:	4585                	li	a1,1
    80004750:	6c88                	ld	a0,24(s1)
    80004752:	fffff097          	auipc	ra,0xfffff
    80004756:	2a4080e7          	jalr	676(ra) # 800039f6 <readi>
    8000475a:	892a                	mv	s2,a0
    8000475c:	00a05563          	blez	a0,80004766 <fileread+0x56>
      f->off += r;
    80004760:	509c                	lw	a5,32(s1)
    80004762:	9fa9                	addw	a5,a5,a0
    80004764:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80004766:	6c88                	ld	a0,24(s1)
    80004768:	fffff097          	auipc	ra,0xfffff
    8000476c:	09c080e7          	jalr	156(ra) # 80003804 <iunlock>
  } else {
    panic("fileread");
  }

  return r;
}
    80004770:	854a                	mv	a0,s2
    80004772:	70a2                	ld	ra,40(sp)
    80004774:	7402                	ld	s0,32(sp)
    80004776:	64e2                	ld	s1,24(sp)
    80004778:	6942                	ld	s2,16(sp)
    8000477a:	69a2                	ld	s3,8(sp)
    8000477c:	6145                	addi	sp,sp,48
    8000477e:	8082                	ret
    r = piperead(f->pipe, addr, n);
    80004780:	6908                	ld	a0,16(a0)
    80004782:	00000097          	auipc	ra,0x0
    80004786:	3c6080e7          	jalr	966(ra) # 80004b48 <piperead>
    8000478a:	892a                	mv	s2,a0
    8000478c:	b7d5                	j	80004770 <fileread+0x60>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    8000478e:	02451783          	lh	a5,36(a0)
    80004792:	03079693          	slli	a3,a5,0x30
    80004796:	92c1                	srli	a3,a3,0x30
    80004798:	4725                	li	a4,9
    8000479a:	02d76863          	bltu	a4,a3,800047ca <fileread+0xba>
    8000479e:	0792                	slli	a5,a5,0x4
    800047a0:	0001d717          	auipc	a4,0x1d
    800047a4:	82870713          	addi	a4,a4,-2008 # 80020fc8 <devsw>
    800047a8:	97ba                	add	a5,a5,a4
    800047aa:	639c                	ld	a5,0(a5)
    800047ac:	c38d                	beqz	a5,800047ce <fileread+0xbe>
    r = devsw[f->major].read(1, addr, n);
    800047ae:	4505                	li	a0,1
    800047b0:	9782                	jalr	a5
    800047b2:	892a                	mv	s2,a0
    800047b4:	bf75                	j	80004770 <fileread+0x60>
    panic("fileread");
    800047b6:	00004517          	auipc	a0,0x4
    800047ba:	ef250513          	addi	a0,a0,-270 # 800086a8 <syscalls+0x258>
    800047be:	ffffc097          	auipc	ra,0xffffc
    800047c2:	d80080e7          	jalr	-640(ra) # 8000053e <panic>
    return -1;
    800047c6:	597d                	li	s2,-1
    800047c8:	b765                	j	80004770 <fileread+0x60>
      return -1;
    800047ca:	597d                	li	s2,-1
    800047cc:	b755                	j	80004770 <fileread+0x60>
    800047ce:	597d                	li	s2,-1
    800047d0:	b745                	j	80004770 <fileread+0x60>

00000000800047d2 <filewrite>:

// Write to file f.
// addr is a user virtual address.
int
filewrite(struct file *f, uint64 addr, int n)
{
    800047d2:	715d                	addi	sp,sp,-80
    800047d4:	e486                	sd	ra,72(sp)
    800047d6:	e0a2                	sd	s0,64(sp)
    800047d8:	fc26                	sd	s1,56(sp)
    800047da:	f84a                	sd	s2,48(sp)
    800047dc:	f44e                	sd	s3,40(sp)
    800047de:	f052                	sd	s4,32(sp)
    800047e0:	ec56                	sd	s5,24(sp)
    800047e2:	e85a                	sd	s6,16(sp)
    800047e4:	e45e                	sd	s7,8(sp)
    800047e6:	e062                	sd	s8,0(sp)
    800047e8:	0880                	addi	s0,sp,80
  int r, ret = 0;

  if(f->writable == 0)
    800047ea:	00954783          	lbu	a5,9(a0)
    800047ee:	10078663          	beqz	a5,800048fa <filewrite+0x128>
    800047f2:	892a                	mv	s2,a0
    800047f4:	8b2e                	mv	s6,a1
    800047f6:	8a32                	mv	s4,a2
    return -1;

  if(f->type == FD_PIPE){
    800047f8:	411c                	lw	a5,0(a0)
    800047fa:	4705                	li	a4,1
    800047fc:	02e78263          	beq	a5,a4,80004820 <filewrite+0x4e>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80004800:	470d                	li	a4,3
    80004802:	02e78663          	beq	a5,a4,8000482e <filewrite+0x5c>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    80004806:	4709                	li	a4,2
    80004808:	0ee79163          	bne	a5,a4,800048ea <filewrite+0x118>
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    8000480c:	0ac05d63          	blez	a2,800048c6 <filewrite+0xf4>
    int i = 0;
    80004810:	4981                	li	s3,0
    80004812:	6b85                	lui	s7,0x1
    80004814:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    80004818:	6c05                	lui	s8,0x1
    8000481a:	c00c0c1b          	addiw	s8,s8,-1024 # c00 <_entry-0x7ffff400>
    8000481e:	a861                	j	800048b6 <filewrite+0xe4>
    ret = pipewrite(f->pipe, addr, n);
    80004820:	6908                	ld	a0,16(a0)
    80004822:	00000097          	auipc	ra,0x0
    80004826:	22e080e7          	jalr	558(ra) # 80004a50 <pipewrite>
    8000482a:	8a2a                	mv	s4,a0
    8000482c:	a045                	j	800048cc <filewrite+0xfa>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    8000482e:	02451783          	lh	a5,36(a0)
    80004832:	03079693          	slli	a3,a5,0x30
    80004836:	92c1                	srli	a3,a3,0x30
    80004838:	4725                	li	a4,9
    8000483a:	0cd76263          	bltu	a4,a3,800048fe <filewrite+0x12c>
    8000483e:	0792                	slli	a5,a5,0x4
    80004840:	0001c717          	auipc	a4,0x1c
    80004844:	78870713          	addi	a4,a4,1928 # 80020fc8 <devsw>
    80004848:	97ba                	add	a5,a5,a4
    8000484a:	679c                	ld	a5,8(a5)
    8000484c:	cbdd                	beqz	a5,80004902 <filewrite+0x130>
    ret = devsw[f->major].write(1, addr, n);
    8000484e:	4505                	li	a0,1
    80004850:	9782                	jalr	a5
    80004852:	8a2a                	mv	s4,a0
    80004854:	a8a5                	j	800048cc <filewrite+0xfa>
    80004856:	00048a9b          	sext.w	s5,s1
      int n1 = n - i;
      if(n1 > max)
        n1 = max;

      begin_op();
    8000485a:	00000097          	auipc	ra,0x0
    8000485e:	8b4080e7          	jalr	-1868(ra) # 8000410e <begin_op>
      ilock(f->ip);
    80004862:	01893503          	ld	a0,24(s2)
    80004866:	fffff097          	auipc	ra,0xfffff
    8000486a:	edc080e7          	jalr	-292(ra) # 80003742 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    8000486e:	8756                	mv	a4,s5
    80004870:	02092683          	lw	a3,32(s2)
    80004874:	01698633          	add	a2,s3,s6
    80004878:	4585                	li	a1,1
    8000487a:	01893503          	ld	a0,24(s2)
    8000487e:	fffff097          	auipc	ra,0xfffff
    80004882:	270080e7          	jalr	624(ra) # 80003aee <writei>
    80004886:	84aa                	mv	s1,a0
    80004888:	00a05763          	blez	a0,80004896 <filewrite+0xc4>
        f->off += r;
    8000488c:	02092783          	lw	a5,32(s2)
    80004890:	9fa9                	addw	a5,a5,a0
    80004892:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    80004896:	01893503          	ld	a0,24(s2)
    8000489a:	fffff097          	auipc	ra,0xfffff
    8000489e:	f6a080e7          	jalr	-150(ra) # 80003804 <iunlock>
      end_op();
    800048a2:	00000097          	auipc	ra,0x0
    800048a6:	8ea080e7          	jalr	-1814(ra) # 8000418c <end_op>

      if(r != n1){
    800048aa:	009a9f63          	bne	s5,s1,800048c8 <filewrite+0xf6>
        // error from writei
        break;
      }
      i += r;
    800048ae:	013489bb          	addw	s3,s1,s3
    while(i < n){
    800048b2:	0149db63          	bge	s3,s4,800048c8 <filewrite+0xf6>
      int n1 = n - i;
    800048b6:	413a04bb          	subw	s1,s4,s3
    800048ba:	0004879b          	sext.w	a5,s1
    800048be:	f8fbdce3          	bge	s7,a5,80004856 <filewrite+0x84>
    800048c2:	84e2                	mv	s1,s8
    800048c4:	bf49                	j	80004856 <filewrite+0x84>
    int i = 0;
    800048c6:	4981                	li	s3,0
    }
    ret = (i == n ? n : -1);
    800048c8:	013a1f63          	bne	s4,s3,800048e6 <filewrite+0x114>
  } else {
    panic("filewrite");
  }

  return ret;
}
    800048cc:	8552                	mv	a0,s4
    800048ce:	60a6                	ld	ra,72(sp)
    800048d0:	6406                	ld	s0,64(sp)
    800048d2:	74e2                	ld	s1,56(sp)
    800048d4:	7942                	ld	s2,48(sp)
    800048d6:	79a2                	ld	s3,40(sp)
    800048d8:	7a02                	ld	s4,32(sp)
    800048da:	6ae2                	ld	s5,24(sp)
    800048dc:	6b42                	ld	s6,16(sp)
    800048de:	6ba2                	ld	s7,8(sp)
    800048e0:	6c02                	ld	s8,0(sp)
    800048e2:	6161                	addi	sp,sp,80
    800048e4:	8082                	ret
    ret = (i == n ? n : -1);
    800048e6:	5a7d                	li	s4,-1
    800048e8:	b7d5                	j	800048cc <filewrite+0xfa>
    panic("filewrite");
    800048ea:	00004517          	auipc	a0,0x4
    800048ee:	dce50513          	addi	a0,a0,-562 # 800086b8 <syscalls+0x268>
    800048f2:	ffffc097          	auipc	ra,0xffffc
    800048f6:	c4c080e7          	jalr	-948(ra) # 8000053e <panic>
    return -1;
    800048fa:	5a7d                	li	s4,-1
    800048fc:	bfc1                	j	800048cc <filewrite+0xfa>
      return -1;
    800048fe:	5a7d                	li	s4,-1
    80004900:	b7f1                	j	800048cc <filewrite+0xfa>
    80004902:	5a7d                	li	s4,-1
    80004904:	b7e1                	j	800048cc <filewrite+0xfa>

0000000080004906 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    80004906:	7179                	addi	sp,sp,-48
    80004908:	f406                	sd	ra,40(sp)
    8000490a:	f022                	sd	s0,32(sp)
    8000490c:	ec26                	sd	s1,24(sp)
    8000490e:	e84a                	sd	s2,16(sp)
    80004910:	e44e                	sd	s3,8(sp)
    80004912:	e052                	sd	s4,0(sp)
    80004914:	1800                	addi	s0,sp,48
    80004916:	84aa                	mv	s1,a0
    80004918:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    8000491a:	0005b023          	sd	zero,0(a1)
    8000491e:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    80004922:	00000097          	auipc	ra,0x0
    80004926:	bf8080e7          	jalr	-1032(ra) # 8000451a <filealloc>
    8000492a:	e088                	sd	a0,0(s1)
    8000492c:	c551                	beqz	a0,800049b8 <pipealloc+0xb2>
    8000492e:	00000097          	auipc	ra,0x0
    80004932:	bec080e7          	jalr	-1044(ra) # 8000451a <filealloc>
    80004936:	00aa3023          	sd	a0,0(s4)
    8000493a:	c92d                	beqz	a0,800049ac <pipealloc+0xa6>
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    8000493c:	ffffc097          	auipc	ra,0xffffc
    80004940:	1a8080e7          	jalr	424(ra) # 80000ae4 <kalloc>
    80004944:	892a                	mv	s2,a0
    80004946:	c125                	beqz	a0,800049a6 <pipealloc+0xa0>
    goto bad;
  pi->readopen = 1;
    80004948:	4985                	li	s3,1
    8000494a:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    8000494e:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80004952:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    80004956:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    8000495a:	00004597          	auipc	a1,0x4
    8000495e:	d6e58593          	addi	a1,a1,-658 # 800086c8 <syscalls+0x278>
    80004962:	ffffc097          	auipc	ra,0xffffc
    80004966:	1e2080e7          	jalr	482(ra) # 80000b44 <initlock>
  (*f0)->type = FD_PIPE;
    8000496a:	609c                	ld	a5,0(s1)
    8000496c:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80004970:	609c                	ld	a5,0(s1)
    80004972:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80004976:	609c                	ld	a5,0(s1)
    80004978:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    8000497c:	609c                	ld	a5,0(s1)
    8000497e:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80004982:	000a3783          	ld	a5,0(s4)
    80004986:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    8000498a:	000a3783          	ld	a5,0(s4)
    8000498e:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80004992:	000a3783          	ld	a5,0(s4)
    80004996:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    8000499a:	000a3783          	ld	a5,0(s4)
    8000499e:	0127b823          	sd	s2,16(a5)
  return 0;
    800049a2:	4501                	li	a0,0
    800049a4:	a025                	j	800049cc <pipealloc+0xc6>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    800049a6:	6088                	ld	a0,0(s1)
    800049a8:	e501                	bnez	a0,800049b0 <pipealloc+0xaa>
    800049aa:	a039                	j	800049b8 <pipealloc+0xb2>
    800049ac:	6088                	ld	a0,0(s1)
    800049ae:	c51d                	beqz	a0,800049dc <pipealloc+0xd6>
    fileclose(*f0);
    800049b0:	00000097          	auipc	ra,0x0
    800049b4:	c26080e7          	jalr	-986(ra) # 800045d6 <fileclose>
  if(*f1)
    800049b8:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    800049bc:	557d                	li	a0,-1
  if(*f1)
    800049be:	c799                	beqz	a5,800049cc <pipealloc+0xc6>
    fileclose(*f1);
    800049c0:	853e                	mv	a0,a5
    800049c2:	00000097          	auipc	ra,0x0
    800049c6:	c14080e7          	jalr	-1004(ra) # 800045d6 <fileclose>
  return -1;
    800049ca:	557d                	li	a0,-1
}
    800049cc:	70a2                	ld	ra,40(sp)
    800049ce:	7402                	ld	s0,32(sp)
    800049d0:	64e2                	ld	s1,24(sp)
    800049d2:	6942                	ld	s2,16(sp)
    800049d4:	69a2                	ld	s3,8(sp)
    800049d6:	6a02                	ld	s4,0(sp)
    800049d8:	6145                	addi	sp,sp,48
    800049da:	8082                	ret
  return -1;
    800049dc:	557d                	li	a0,-1
    800049de:	b7fd                	j	800049cc <pipealloc+0xc6>

00000000800049e0 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    800049e0:	1101                	addi	sp,sp,-32
    800049e2:	ec06                	sd	ra,24(sp)
    800049e4:	e822                	sd	s0,16(sp)
    800049e6:	e426                	sd	s1,8(sp)
    800049e8:	e04a                	sd	s2,0(sp)
    800049ea:	1000                	addi	s0,sp,32
    800049ec:	84aa                	mv	s1,a0
    800049ee:	892e                	mv	s2,a1
  acquire(&pi->lock);
    800049f0:	ffffc097          	auipc	ra,0xffffc
    800049f4:	1e4080e7          	jalr	484(ra) # 80000bd4 <acquire>
  if(writable){
    800049f8:	02090d63          	beqz	s2,80004a32 <pipeclose+0x52>
    pi->writeopen = 0;
    800049fc:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80004a00:	21848513          	addi	a0,s1,536
    80004a04:	ffffd097          	auipc	ra,0xffffd
    80004a08:	7c8080e7          	jalr	1992(ra) # 800021cc <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    80004a0c:	2204b783          	ld	a5,544(s1)
    80004a10:	eb95                	bnez	a5,80004a44 <pipeclose+0x64>
    release(&pi->lock);
    80004a12:	8526                	mv	a0,s1
    80004a14:	ffffc097          	auipc	ra,0xffffc
    80004a18:	274080e7          	jalr	628(ra) # 80000c88 <release>
    kfree((char*)pi);
    80004a1c:	8526                	mv	a0,s1
    80004a1e:	ffffc097          	auipc	ra,0xffffc
    80004a22:	fc8080e7          	jalr	-56(ra) # 800009e6 <kfree>
  } else
    release(&pi->lock);
}
    80004a26:	60e2                	ld	ra,24(sp)
    80004a28:	6442                	ld	s0,16(sp)
    80004a2a:	64a2                	ld	s1,8(sp)
    80004a2c:	6902                	ld	s2,0(sp)
    80004a2e:	6105                	addi	sp,sp,32
    80004a30:	8082                	ret
    pi->readopen = 0;
    80004a32:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80004a36:	21c48513          	addi	a0,s1,540
    80004a3a:	ffffd097          	auipc	ra,0xffffd
    80004a3e:	792080e7          	jalr	1938(ra) # 800021cc <wakeup>
    80004a42:	b7e9                	j	80004a0c <pipeclose+0x2c>
    release(&pi->lock);
    80004a44:	8526                	mv	a0,s1
    80004a46:	ffffc097          	auipc	ra,0xffffc
    80004a4a:	242080e7          	jalr	578(ra) # 80000c88 <release>
}
    80004a4e:	bfe1                	j	80004a26 <pipeclose+0x46>

0000000080004a50 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80004a50:	711d                	addi	sp,sp,-96
    80004a52:	ec86                	sd	ra,88(sp)
    80004a54:	e8a2                	sd	s0,80(sp)
    80004a56:	e4a6                	sd	s1,72(sp)
    80004a58:	e0ca                	sd	s2,64(sp)
    80004a5a:	fc4e                	sd	s3,56(sp)
    80004a5c:	f852                	sd	s4,48(sp)
    80004a5e:	f456                	sd	s5,40(sp)
    80004a60:	f05a                	sd	s6,32(sp)
    80004a62:	ec5e                	sd	s7,24(sp)
    80004a64:	e862                	sd	s8,16(sp)
    80004a66:	1080                	addi	s0,sp,96
    80004a68:	84aa                	mv	s1,a0
    80004a6a:	8aae                	mv	s5,a1
    80004a6c:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80004a6e:	ffffd097          	auipc	ra,0xffffd
    80004a72:	f3c080e7          	jalr	-196(ra) # 800019aa <myproc>
    80004a76:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80004a78:	8526                	mv	a0,s1
    80004a7a:	ffffc097          	auipc	ra,0xffffc
    80004a7e:	15a080e7          	jalr	346(ra) # 80000bd4 <acquire>
  while(i < n){
    80004a82:	0b405663          	blez	s4,80004b2e <pipewrite+0xde>
  int i = 0;
    80004a86:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004a88:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80004a8a:	21848c13          	addi	s8,s1,536
      sleep(&pi->nwrite, &pi->lock);
    80004a8e:	21c48b93          	addi	s7,s1,540
    80004a92:	a089                	j	80004ad4 <pipewrite+0x84>
      release(&pi->lock);
    80004a94:	8526                	mv	a0,s1
    80004a96:	ffffc097          	auipc	ra,0xffffc
    80004a9a:	1f2080e7          	jalr	498(ra) # 80000c88 <release>
      return -1;
    80004a9e:	597d                	li	s2,-1
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80004aa0:	854a                	mv	a0,s2
    80004aa2:	60e6                	ld	ra,88(sp)
    80004aa4:	6446                	ld	s0,80(sp)
    80004aa6:	64a6                	ld	s1,72(sp)
    80004aa8:	6906                	ld	s2,64(sp)
    80004aaa:	79e2                	ld	s3,56(sp)
    80004aac:	7a42                	ld	s4,48(sp)
    80004aae:	7aa2                	ld	s5,40(sp)
    80004ab0:	7b02                	ld	s6,32(sp)
    80004ab2:	6be2                	ld	s7,24(sp)
    80004ab4:	6c42                	ld	s8,16(sp)
    80004ab6:	6125                	addi	sp,sp,96
    80004ab8:	8082                	ret
      wakeup(&pi->nread);
    80004aba:	8562                	mv	a0,s8
    80004abc:	ffffd097          	auipc	ra,0xffffd
    80004ac0:	710080e7          	jalr	1808(ra) # 800021cc <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80004ac4:	85a6                	mv	a1,s1
    80004ac6:	855e                	mv	a0,s7
    80004ac8:	ffffd097          	auipc	ra,0xffffd
    80004acc:	68e080e7          	jalr	1678(ra) # 80002156 <sleep>
  while(i < n){
    80004ad0:	07495063          	bge	s2,s4,80004b30 <pipewrite+0xe0>
    if(pi->readopen == 0 || killed(pr)){
    80004ad4:	2204a783          	lw	a5,544(s1)
    80004ad8:	dfd5                	beqz	a5,80004a94 <pipewrite+0x44>
    80004ada:	854e                	mv	a0,s3
    80004adc:	ffffe097          	auipc	ra,0xffffe
    80004ae0:	934080e7          	jalr	-1740(ra) # 80002410 <killed>
    80004ae4:	f945                	bnez	a0,80004a94 <pipewrite+0x44>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    80004ae6:	2184a783          	lw	a5,536(s1)
    80004aea:	21c4a703          	lw	a4,540(s1)
    80004aee:	2007879b          	addiw	a5,a5,512
    80004af2:	fcf704e3          	beq	a4,a5,80004aba <pipewrite+0x6a>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004af6:	4685                	li	a3,1
    80004af8:	01590633          	add	a2,s2,s5
    80004afc:	faf40593          	addi	a1,s0,-81
    80004b00:	0509b503          	ld	a0,80(s3)
    80004b04:	ffffd097          	auipc	ra,0xffffd
    80004b08:	bf2080e7          	jalr	-1038(ra) # 800016f6 <copyin>
    80004b0c:	03650263          	beq	a0,s6,80004b30 <pipewrite+0xe0>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80004b10:	21c4a783          	lw	a5,540(s1)
    80004b14:	0017871b          	addiw	a4,a5,1
    80004b18:	20e4ae23          	sw	a4,540(s1)
    80004b1c:	1ff7f793          	andi	a5,a5,511
    80004b20:	97a6                	add	a5,a5,s1
    80004b22:	faf44703          	lbu	a4,-81(s0)
    80004b26:	00e78c23          	sb	a4,24(a5)
      i++;
    80004b2a:	2905                	addiw	s2,s2,1
    80004b2c:	b755                	j	80004ad0 <pipewrite+0x80>
  int i = 0;
    80004b2e:	4901                	li	s2,0
  wakeup(&pi->nread);
    80004b30:	21848513          	addi	a0,s1,536
    80004b34:	ffffd097          	auipc	ra,0xffffd
    80004b38:	698080e7          	jalr	1688(ra) # 800021cc <wakeup>
  release(&pi->lock);
    80004b3c:	8526                	mv	a0,s1
    80004b3e:	ffffc097          	auipc	ra,0xffffc
    80004b42:	14a080e7          	jalr	330(ra) # 80000c88 <release>
  return i;
    80004b46:	bfa9                	j	80004aa0 <pipewrite+0x50>

0000000080004b48 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80004b48:	715d                	addi	sp,sp,-80
    80004b4a:	e486                	sd	ra,72(sp)
    80004b4c:	e0a2                	sd	s0,64(sp)
    80004b4e:	fc26                	sd	s1,56(sp)
    80004b50:	f84a                	sd	s2,48(sp)
    80004b52:	f44e                	sd	s3,40(sp)
    80004b54:	f052                	sd	s4,32(sp)
    80004b56:	ec56                	sd	s5,24(sp)
    80004b58:	e85a                	sd	s6,16(sp)
    80004b5a:	0880                	addi	s0,sp,80
    80004b5c:	84aa                	mv	s1,a0
    80004b5e:	892e                	mv	s2,a1
    80004b60:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80004b62:	ffffd097          	auipc	ra,0xffffd
    80004b66:	e48080e7          	jalr	-440(ra) # 800019aa <myproc>
    80004b6a:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    80004b6c:	8526                	mv	a0,s1
    80004b6e:	ffffc097          	auipc	ra,0xffffc
    80004b72:	066080e7          	jalr	102(ra) # 80000bd4 <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004b76:	2184a703          	lw	a4,536(s1)
    80004b7a:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004b7e:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004b82:	02f71763          	bne	a4,a5,80004bb0 <piperead+0x68>
    80004b86:	2244a783          	lw	a5,548(s1)
    80004b8a:	c39d                	beqz	a5,80004bb0 <piperead+0x68>
    if(killed(pr)){
    80004b8c:	8552                	mv	a0,s4
    80004b8e:	ffffe097          	auipc	ra,0xffffe
    80004b92:	882080e7          	jalr	-1918(ra) # 80002410 <killed>
    80004b96:	e949                	bnez	a0,80004c28 <piperead+0xe0>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004b98:	85a6                	mv	a1,s1
    80004b9a:	854e                	mv	a0,s3
    80004b9c:	ffffd097          	auipc	ra,0xffffd
    80004ba0:	5ba080e7          	jalr	1466(ra) # 80002156 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004ba4:	2184a703          	lw	a4,536(s1)
    80004ba8:	21c4a783          	lw	a5,540(s1)
    80004bac:	fcf70de3          	beq	a4,a5,80004b86 <piperead+0x3e>
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004bb0:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004bb2:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004bb4:	05505463          	blez	s5,80004bfc <piperead+0xb4>
    if(pi->nread == pi->nwrite)
    80004bb8:	2184a783          	lw	a5,536(s1)
    80004bbc:	21c4a703          	lw	a4,540(s1)
    80004bc0:	02f70e63          	beq	a4,a5,80004bfc <piperead+0xb4>
    ch = pi->data[pi->nread++ % PIPESIZE];
    80004bc4:	0017871b          	addiw	a4,a5,1
    80004bc8:	20e4ac23          	sw	a4,536(s1)
    80004bcc:	1ff7f793          	andi	a5,a5,511
    80004bd0:	97a6                	add	a5,a5,s1
    80004bd2:	0187c783          	lbu	a5,24(a5)
    80004bd6:	faf40fa3          	sb	a5,-65(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004bda:	4685                	li	a3,1
    80004bdc:	fbf40613          	addi	a2,s0,-65
    80004be0:	85ca                	mv	a1,s2
    80004be2:	050a3503          	ld	a0,80(s4)
    80004be6:	ffffd097          	auipc	ra,0xffffd
    80004bea:	a84080e7          	jalr	-1404(ra) # 8000166a <copyout>
    80004bee:	01650763          	beq	a0,s6,80004bfc <piperead+0xb4>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004bf2:	2985                	addiw	s3,s3,1
    80004bf4:	0905                	addi	s2,s2,1
    80004bf6:	fd3a91e3          	bne	s5,s3,80004bb8 <piperead+0x70>
    80004bfa:	89d6                	mv	s3,s5
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80004bfc:	21c48513          	addi	a0,s1,540
    80004c00:	ffffd097          	auipc	ra,0xffffd
    80004c04:	5cc080e7          	jalr	1484(ra) # 800021cc <wakeup>
  release(&pi->lock);
    80004c08:	8526                	mv	a0,s1
    80004c0a:	ffffc097          	auipc	ra,0xffffc
    80004c0e:	07e080e7          	jalr	126(ra) # 80000c88 <release>
  return i;
}
    80004c12:	854e                	mv	a0,s3
    80004c14:	60a6                	ld	ra,72(sp)
    80004c16:	6406                	ld	s0,64(sp)
    80004c18:	74e2                	ld	s1,56(sp)
    80004c1a:	7942                	ld	s2,48(sp)
    80004c1c:	79a2                	ld	s3,40(sp)
    80004c1e:	7a02                	ld	s4,32(sp)
    80004c20:	6ae2                	ld	s5,24(sp)
    80004c22:	6b42                	ld	s6,16(sp)
    80004c24:	6161                	addi	sp,sp,80
    80004c26:	8082                	ret
      release(&pi->lock);
    80004c28:	8526                	mv	a0,s1
    80004c2a:	ffffc097          	auipc	ra,0xffffc
    80004c2e:	05e080e7          	jalr	94(ra) # 80000c88 <release>
      return -1;
    80004c32:	59fd                	li	s3,-1
    80004c34:	bff9                	j	80004c12 <piperead+0xca>

0000000080004c36 <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    80004c36:	1141                	addi	sp,sp,-16
    80004c38:	e422                	sd	s0,8(sp)
    80004c3a:	0800                	addi	s0,sp,16
    80004c3c:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80004c3e:	8905                	andi	a0,a0,1
    80004c40:	050e                	slli	a0,a0,0x3
      perm = PTE_X;
    if(flags & 0x2)
    80004c42:	8b89                	andi	a5,a5,2
    80004c44:	c399                	beqz	a5,80004c4a <flags2perm+0x14>
      perm |= PTE_W;
    80004c46:	00456513          	ori	a0,a0,4
    return perm;
}
    80004c4a:	6422                	ld	s0,8(sp)
    80004c4c:	0141                	addi	sp,sp,16
    80004c4e:	8082                	ret

0000000080004c50 <exec>:

int
exec(char *path, char **argv)
{
    80004c50:	de010113          	addi	sp,sp,-544
    80004c54:	20113c23          	sd	ra,536(sp)
    80004c58:	20813823          	sd	s0,528(sp)
    80004c5c:	20913423          	sd	s1,520(sp)
    80004c60:	21213023          	sd	s2,512(sp)
    80004c64:	ffce                	sd	s3,504(sp)
    80004c66:	fbd2                	sd	s4,496(sp)
    80004c68:	f7d6                	sd	s5,488(sp)
    80004c6a:	f3da                	sd	s6,480(sp)
    80004c6c:	efde                	sd	s7,472(sp)
    80004c6e:	ebe2                	sd	s8,464(sp)
    80004c70:	e7e6                	sd	s9,456(sp)
    80004c72:	e3ea                	sd	s10,448(sp)
    80004c74:	ff6e                	sd	s11,440(sp)
    80004c76:	1400                	addi	s0,sp,544
    80004c78:	892a                	mv	s2,a0
    80004c7a:	dea43423          	sd	a0,-536(s0)
    80004c7e:	deb43823          	sd	a1,-528(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80004c82:	ffffd097          	auipc	ra,0xffffd
    80004c86:	d28080e7          	jalr	-728(ra) # 800019aa <myproc>
    80004c8a:	84aa                	mv	s1,a0

  begin_op();
    80004c8c:	fffff097          	auipc	ra,0xfffff
    80004c90:	482080e7          	jalr	1154(ra) # 8000410e <begin_op>

  if((ip = namei(path)) == 0){
    80004c94:	854a                	mv	a0,s2
    80004c96:	fffff097          	auipc	ra,0xfffff
    80004c9a:	258080e7          	jalr	600(ra) # 80003eee <namei>
    80004c9e:	c93d                	beqz	a0,80004d14 <exec+0xc4>
    80004ca0:	8aaa                	mv	s5,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80004ca2:	fffff097          	auipc	ra,0xfffff
    80004ca6:	aa0080e7          	jalr	-1376(ra) # 80003742 <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80004caa:	04000713          	li	a4,64
    80004cae:	4681                	li	a3,0
    80004cb0:	e5040613          	addi	a2,s0,-432
    80004cb4:	4581                	li	a1,0
    80004cb6:	8556                	mv	a0,s5
    80004cb8:	fffff097          	auipc	ra,0xfffff
    80004cbc:	d3e080e7          	jalr	-706(ra) # 800039f6 <readi>
    80004cc0:	04000793          	li	a5,64
    80004cc4:	00f51a63          	bne	a0,a5,80004cd8 <exec+0x88>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    80004cc8:	e5042703          	lw	a4,-432(s0)
    80004ccc:	464c47b7          	lui	a5,0x464c4
    80004cd0:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004cd4:	04f70663          	beq	a4,a5,80004d20 <exec+0xd0>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80004cd8:	8556                	mv	a0,s5
    80004cda:	fffff097          	auipc	ra,0xfffff
    80004cde:	cca080e7          	jalr	-822(ra) # 800039a4 <iunlockput>
    end_op();
    80004ce2:	fffff097          	auipc	ra,0xfffff
    80004ce6:	4aa080e7          	jalr	1194(ra) # 8000418c <end_op>
  }
  return -1;
    80004cea:	557d                	li	a0,-1
}
    80004cec:	21813083          	ld	ra,536(sp)
    80004cf0:	21013403          	ld	s0,528(sp)
    80004cf4:	20813483          	ld	s1,520(sp)
    80004cf8:	20013903          	ld	s2,512(sp)
    80004cfc:	79fe                	ld	s3,504(sp)
    80004cfe:	7a5e                	ld	s4,496(sp)
    80004d00:	7abe                	ld	s5,488(sp)
    80004d02:	7b1e                	ld	s6,480(sp)
    80004d04:	6bfe                	ld	s7,472(sp)
    80004d06:	6c5e                	ld	s8,464(sp)
    80004d08:	6cbe                	ld	s9,456(sp)
    80004d0a:	6d1e                	ld	s10,448(sp)
    80004d0c:	7dfa                	ld	s11,440(sp)
    80004d0e:	22010113          	addi	sp,sp,544
    80004d12:	8082                	ret
    end_op();
    80004d14:	fffff097          	auipc	ra,0xfffff
    80004d18:	478080e7          	jalr	1144(ra) # 8000418c <end_op>
    return -1;
    80004d1c:	557d                	li	a0,-1
    80004d1e:	b7f9                	j	80004cec <exec+0x9c>
  if((pagetable = proc_pagetable(p)) == 0)
    80004d20:	8526                	mv	a0,s1
    80004d22:	ffffd097          	auipc	ra,0xffffd
    80004d26:	d4c080e7          	jalr	-692(ra) # 80001a6e <proc_pagetable>
    80004d2a:	8b2a                	mv	s6,a0
    80004d2c:	d555                	beqz	a0,80004cd8 <exec+0x88>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004d2e:	e7042783          	lw	a5,-400(s0)
    80004d32:	e8845703          	lhu	a4,-376(s0)
    80004d36:	c735                	beqz	a4,80004da2 <exec+0x152>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004d38:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004d3a:	e0043423          	sd	zero,-504(s0)
    if(ph.vaddr % PGSIZE != 0)
    80004d3e:	6a05                	lui	s4,0x1
    80004d40:	fffa0713          	addi	a4,s4,-1 # fff <_entry-0x7ffff001>
    80004d44:	dee43023          	sd	a4,-544(s0)
loadseg(pagetable_t pagetable, uint64 va, struct inode *ip, uint offset, uint sz)
{
  uint i, n;
  uint64 pa;

  for(i = 0; i < sz; i += PGSIZE){
    80004d48:	6d85                	lui	s11,0x1
    80004d4a:	7d7d                	lui	s10,0xfffff
    80004d4c:	ac3d                	j	80004f8a <exec+0x33a>
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    80004d4e:	00004517          	auipc	a0,0x4
    80004d52:	98250513          	addi	a0,a0,-1662 # 800086d0 <syscalls+0x280>
    80004d56:	ffffb097          	auipc	ra,0xffffb
    80004d5a:	7e8080e7          	jalr	2024(ra) # 8000053e <panic>
    if(sz - i < PGSIZE)
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80004d5e:	874a                	mv	a4,s2
    80004d60:	009c86bb          	addw	a3,s9,s1
    80004d64:	4581                	li	a1,0
    80004d66:	8556                	mv	a0,s5
    80004d68:	fffff097          	auipc	ra,0xfffff
    80004d6c:	c8e080e7          	jalr	-882(ra) # 800039f6 <readi>
    80004d70:	2501                	sext.w	a0,a0
    80004d72:	1aa91963          	bne	s2,a0,80004f24 <exec+0x2d4>
  for(i = 0; i < sz; i += PGSIZE){
    80004d76:	009d84bb          	addw	s1,s11,s1
    80004d7a:	013d09bb          	addw	s3,s10,s3
    80004d7e:	1f74f663          	bgeu	s1,s7,80004f6a <exec+0x31a>
    pa = walkaddr(pagetable, va + i);
    80004d82:	02049593          	slli	a1,s1,0x20
    80004d86:	9181                	srli	a1,a1,0x20
    80004d88:	95e2                	add	a1,a1,s8
    80004d8a:	855a                	mv	a0,s6
    80004d8c:	ffffc097          	auipc	ra,0xffffc
    80004d90:	2ce080e7          	jalr	718(ra) # 8000105a <walkaddr>
    80004d94:	862a                	mv	a2,a0
    if(pa == 0)
    80004d96:	dd45                	beqz	a0,80004d4e <exec+0xfe>
      n = PGSIZE;
    80004d98:	8952                	mv	s2,s4
    if(sz - i < PGSIZE)
    80004d9a:	fd49f2e3          	bgeu	s3,s4,80004d5e <exec+0x10e>
      n = sz - i;
    80004d9e:	894e                	mv	s2,s3
    80004da0:	bf7d                	j	80004d5e <exec+0x10e>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004da2:	4901                	li	s2,0
  iunlockput(ip);
    80004da4:	8556                	mv	a0,s5
    80004da6:	fffff097          	auipc	ra,0xfffff
    80004daa:	bfe080e7          	jalr	-1026(ra) # 800039a4 <iunlockput>
  end_op();
    80004dae:	fffff097          	auipc	ra,0xfffff
    80004db2:	3de080e7          	jalr	990(ra) # 8000418c <end_op>
  p = myproc();
    80004db6:	ffffd097          	auipc	ra,0xffffd
    80004dba:	bf4080e7          	jalr	-1036(ra) # 800019aa <myproc>
    80004dbe:	8baa                	mv	s7,a0
  uint64 oldsz = p->sz;
    80004dc0:	04853d03          	ld	s10,72(a0)
  sz = PGROUNDUP(sz);
    80004dc4:	6785                	lui	a5,0x1
    80004dc6:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80004dc8:	97ca                	add	a5,a5,s2
    80004dca:	777d                	lui	a4,0xfffff
    80004dcc:	8ff9                	and	a5,a5,a4
    80004dce:	def43c23          	sd	a5,-520(s0)
  if((sz1 = uvmalloc(pagetable, sz, sz + 2*PGSIZE, PTE_W)) == 0)
    80004dd2:	4691                	li	a3,4
    80004dd4:	6609                	lui	a2,0x2
    80004dd6:	963e                	add	a2,a2,a5
    80004dd8:	85be                	mv	a1,a5
    80004dda:	855a                	mv	a0,s6
    80004ddc:	ffffc097          	auipc	ra,0xffffc
    80004de0:	632080e7          	jalr	1586(ra) # 8000140e <uvmalloc>
    80004de4:	8c2a                	mv	s8,a0
  ip = 0;
    80004de6:	4a81                	li	s5,0
  if((sz1 = uvmalloc(pagetable, sz, sz + 2*PGSIZE, PTE_W)) == 0)
    80004de8:	12050e63          	beqz	a0,80004f24 <exec+0x2d4>
  uvmclear(pagetable, sz-2*PGSIZE);
    80004dec:	75f9                	lui	a1,0xffffe
    80004dee:	95aa                	add	a1,a1,a0
    80004df0:	855a                	mv	a0,s6
    80004df2:	ffffd097          	auipc	ra,0xffffd
    80004df6:	846080e7          	jalr	-1978(ra) # 80001638 <uvmclear>
  stackbase = sp - PGSIZE;
    80004dfa:	7afd                	lui	s5,0xfffff
    80004dfc:	9ae2                	add	s5,s5,s8
  for(argc = 0; argv[argc]; argc++) {
    80004dfe:	df043783          	ld	a5,-528(s0)
    80004e02:	6388                	ld	a0,0(a5)
    80004e04:	c925                	beqz	a0,80004e74 <exec+0x224>
    80004e06:	e9040993          	addi	s3,s0,-368
    80004e0a:	f9040c93          	addi	s9,s0,-112
  sp = sz;
    80004e0e:	8962                	mv	s2,s8
  for(argc = 0; argv[argc]; argc++) {
    80004e10:	4481                	li	s1,0
    sp -= strlen(argv[argc]) + 1;
    80004e12:	ffffc097          	auipc	ra,0xffffc
    80004e16:	03a080e7          	jalr	58(ra) # 80000e4c <strlen>
    80004e1a:	0015079b          	addiw	a5,a0,1
    80004e1e:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004e22:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    80004e26:	13596663          	bltu	s2,s5,80004f52 <exec+0x302>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004e2a:	df043d83          	ld	s11,-528(s0)
    80004e2e:	000dba03          	ld	s4,0(s11) # 1000 <_entry-0x7ffff000>
    80004e32:	8552                	mv	a0,s4
    80004e34:	ffffc097          	auipc	ra,0xffffc
    80004e38:	018080e7          	jalr	24(ra) # 80000e4c <strlen>
    80004e3c:	0015069b          	addiw	a3,a0,1
    80004e40:	8652                	mv	a2,s4
    80004e42:	85ca                	mv	a1,s2
    80004e44:	855a                	mv	a0,s6
    80004e46:	ffffd097          	auipc	ra,0xffffd
    80004e4a:	824080e7          	jalr	-2012(ra) # 8000166a <copyout>
    80004e4e:	10054663          	bltz	a0,80004f5a <exec+0x30a>
    ustack[argc] = sp;
    80004e52:	0129b023          	sd	s2,0(s3)
  for(argc = 0; argv[argc]; argc++) {
    80004e56:	0485                	addi	s1,s1,1
    80004e58:	008d8793          	addi	a5,s11,8
    80004e5c:	def43823          	sd	a5,-528(s0)
    80004e60:	008db503          	ld	a0,8(s11)
    80004e64:	c911                	beqz	a0,80004e78 <exec+0x228>
    if(argc >= MAXARG)
    80004e66:	09a1                	addi	s3,s3,8
    80004e68:	fb3c95e3          	bne	s9,s3,80004e12 <exec+0x1c2>
  sz = sz1;
    80004e6c:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004e70:	4a81                	li	s5,0
    80004e72:	a84d                	j	80004f24 <exec+0x2d4>
  sp = sz;
    80004e74:	8962                	mv	s2,s8
  for(argc = 0; argv[argc]; argc++) {
    80004e76:	4481                	li	s1,0
  ustack[argc] = 0;
    80004e78:	00349793          	slli	a5,s1,0x3
    80004e7c:	f9078793          	addi	a5,a5,-112
    80004e80:	97a2                	add	a5,a5,s0
    80004e82:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    80004e86:	00148693          	addi	a3,s1,1
    80004e8a:	068e                	slli	a3,a3,0x3
    80004e8c:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80004e90:	ff097913          	andi	s2,s2,-16
  if(sp < stackbase)
    80004e94:	01597663          	bgeu	s2,s5,80004ea0 <exec+0x250>
  sz = sz1;
    80004e98:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004e9c:	4a81                	li	s5,0
    80004e9e:	a059                	j	80004f24 <exec+0x2d4>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80004ea0:	e9040613          	addi	a2,s0,-368
    80004ea4:	85ca                	mv	a1,s2
    80004ea6:	855a                	mv	a0,s6
    80004ea8:	ffffc097          	auipc	ra,0xffffc
    80004eac:	7c2080e7          	jalr	1986(ra) # 8000166a <copyout>
    80004eb0:	0a054963          	bltz	a0,80004f62 <exec+0x312>
  p->trapframe->a1 = sp;
    80004eb4:	058bb783          	ld	a5,88(s7)
    80004eb8:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80004ebc:	de843783          	ld	a5,-536(s0)
    80004ec0:	0007c703          	lbu	a4,0(a5)
    80004ec4:	cf11                	beqz	a4,80004ee0 <exec+0x290>
    80004ec6:	0785                	addi	a5,a5,1
    if(*s == '/')
    80004ec8:	02f00693          	li	a3,47
    80004ecc:	a039                	j	80004eda <exec+0x28a>
      last = s+1;
    80004ece:	def43423          	sd	a5,-536(s0)
  for(last=s=path; *s; s++)
    80004ed2:	0785                	addi	a5,a5,1
    80004ed4:	fff7c703          	lbu	a4,-1(a5)
    80004ed8:	c701                	beqz	a4,80004ee0 <exec+0x290>
    if(*s == '/')
    80004eda:	fed71ce3          	bne	a4,a3,80004ed2 <exec+0x282>
    80004ede:	bfc5                	j	80004ece <exec+0x27e>
  safestrcpy(p->name, last, sizeof(p->name));
    80004ee0:	4641                	li	a2,16
    80004ee2:	de843583          	ld	a1,-536(s0)
    80004ee6:	158b8513          	addi	a0,s7,344
    80004eea:	ffffc097          	auipc	ra,0xffffc
    80004eee:	f30080e7          	jalr	-208(ra) # 80000e1a <safestrcpy>
  oldpagetable = p->pagetable;
    80004ef2:	050bb503          	ld	a0,80(s7)
  p->pagetable = pagetable;
    80004ef6:	056bb823          	sd	s6,80(s7)
  p->sz = sz;
    80004efa:	058bb423          	sd	s8,72(s7)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    80004efe:	058bb783          	ld	a5,88(s7)
    80004f02:	e6843703          	ld	a4,-408(s0)
    80004f06:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80004f08:	058bb783          	ld	a5,88(s7)
    80004f0c:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004f10:	85ea                	mv	a1,s10
    80004f12:	ffffd097          	auipc	ra,0xffffd
    80004f16:	bf8080e7          	jalr	-1032(ra) # 80001b0a <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004f1a:	0004851b          	sext.w	a0,s1
    80004f1e:	b3f9                	j	80004cec <exec+0x9c>
    80004f20:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80004f24:	df843583          	ld	a1,-520(s0)
    80004f28:	855a                	mv	a0,s6
    80004f2a:	ffffd097          	auipc	ra,0xffffd
    80004f2e:	be0080e7          	jalr	-1056(ra) # 80001b0a <proc_freepagetable>
  if(ip){
    80004f32:	da0a93e3          	bnez	s5,80004cd8 <exec+0x88>
  return -1;
    80004f36:	557d                	li	a0,-1
    80004f38:	bb55                	j	80004cec <exec+0x9c>
    80004f3a:	df243c23          	sd	s2,-520(s0)
    80004f3e:	b7dd                	j	80004f24 <exec+0x2d4>
    80004f40:	df243c23          	sd	s2,-520(s0)
    80004f44:	b7c5                	j	80004f24 <exec+0x2d4>
    80004f46:	df243c23          	sd	s2,-520(s0)
    80004f4a:	bfe9                	j	80004f24 <exec+0x2d4>
    80004f4c:	df243c23          	sd	s2,-520(s0)
    80004f50:	bfd1                	j	80004f24 <exec+0x2d4>
  sz = sz1;
    80004f52:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004f56:	4a81                	li	s5,0
    80004f58:	b7f1                	j	80004f24 <exec+0x2d4>
  sz = sz1;
    80004f5a:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004f5e:	4a81                	li	s5,0
    80004f60:	b7d1                	j	80004f24 <exec+0x2d4>
  sz = sz1;
    80004f62:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004f66:	4a81                	li	s5,0
    80004f68:	bf75                	j	80004f24 <exec+0x2d4>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004f6a:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004f6e:	e0843783          	ld	a5,-504(s0)
    80004f72:	0017869b          	addiw	a3,a5,1
    80004f76:	e0d43423          	sd	a3,-504(s0)
    80004f7a:	e0043783          	ld	a5,-512(s0)
    80004f7e:	0387879b          	addiw	a5,a5,56
    80004f82:	e8845703          	lhu	a4,-376(s0)
    80004f86:	e0e6dfe3          	bge	a3,a4,80004da4 <exec+0x154>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004f8a:	2781                	sext.w	a5,a5
    80004f8c:	e0f43023          	sd	a5,-512(s0)
    80004f90:	03800713          	li	a4,56
    80004f94:	86be                	mv	a3,a5
    80004f96:	e1840613          	addi	a2,s0,-488
    80004f9a:	4581                	li	a1,0
    80004f9c:	8556                	mv	a0,s5
    80004f9e:	fffff097          	auipc	ra,0xfffff
    80004fa2:	a58080e7          	jalr	-1448(ra) # 800039f6 <readi>
    80004fa6:	03800793          	li	a5,56
    80004faa:	f6f51be3          	bne	a0,a5,80004f20 <exec+0x2d0>
    if(ph.type != ELF_PROG_LOAD)
    80004fae:	e1842783          	lw	a5,-488(s0)
    80004fb2:	4705                	li	a4,1
    80004fb4:	fae79de3          	bne	a5,a4,80004f6e <exec+0x31e>
    if(ph.memsz < ph.filesz)
    80004fb8:	e4043483          	ld	s1,-448(s0)
    80004fbc:	e3843783          	ld	a5,-456(s0)
    80004fc0:	f6f4ede3          	bltu	s1,a5,80004f3a <exec+0x2ea>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80004fc4:	e2843783          	ld	a5,-472(s0)
    80004fc8:	94be                	add	s1,s1,a5
    80004fca:	f6f4ebe3          	bltu	s1,a5,80004f40 <exec+0x2f0>
    if(ph.vaddr % PGSIZE != 0)
    80004fce:	de043703          	ld	a4,-544(s0)
    80004fd2:	8ff9                	and	a5,a5,a4
    80004fd4:	fbad                	bnez	a5,80004f46 <exec+0x2f6>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004fd6:	e1c42503          	lw	a0,-484(s0)
    80004fda:	00000097          	auipc	ra,0x0
    80004fde:	c5c080e7          	jalr	-932(ra) # 80004c36 <flags2perm>
    80004fe2:	86aa                	mv	a3,a0
    80004fe4:	8626                	mv	a2,s1
    80004fe6:	85ca                	mv	a1,s2
    80004fe8:	855a                	mv	a0,s6
    80004fea:	ffffc097          	auipc	ra,0xffffc
    80004fee:	424080e7          	jalr	1060(ra) # 8000140e <uvmalloc>
    80004ff2:	dea43c23          	sd	a0,-520(s0)
    80004ff6:	d939                	beqz	a0,80004f4c <exec+0x2fc>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004ff8:	e2843c03          	ld	s8,-472(s0)
    80004ffc:	e2042c83          	lw	s9,-480(s0)
    80005000:	e3842b83          	lw	s7,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80005004:	f60b83e3          	beqz	s7,80004f6a <exec+0x31a>
    80005008:	89de                	mv	s3,s7
    8000500a:	4481                	li	s1,0
    8000500c:	bb9d                	j	80004d82 <exec+0x132>

000000008000500e <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    8000500e:	7179                	addi	sp,sp,-48
    80005010:	f406                	sd	ra,40(sp)
    80005012:	f022                	sd	s0,32(sp)
    80005014:	ec26                	sd	s1,24(sp)
    80005016:	e84a                	sd	s2,16(sp)
    80005018:	1800                	addi	s0,sp,48
    8000501a:	892e                	mv	s2,a1
    8000501c:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    8000501e:	fdc40593          	addi	a1,s0,-36
    80005022:	ffffe097          	auipc	ra,0xffffe
    80005026:	bb6080e7          	jalr	-1098(ra) # 80002bd8 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    8000502a:	fdc42703          	lw	a4,-36(s0)
    8000502e:	47bd                	li	a5,15
    80005030:	02e7eb63          	bltu	a5,a4,80005066 <argfd+0x58>
    80005034:	ffffd097          	auipc	ra,0xffffd
    80005038:	976080e7          	jalr	-1674(ra) # 800019aa <myproc>
    8000503c:	fdc42703          	lw	a4,-36(s0)
    80005040:	01a70793          	addi	a5,a4,26 # fffffffffffff01a <end+0xffffffff7ffdceba>
    80005044:	078e                	slli	a5,a5,0x3
    80005046:	953e                	add	a0,a0,a5
    80005048:	611c                	ld	a5,0(a0)
    8000504a:	c385                	beqz	a5,8000506a <argfd+0x5c>
    return -1;
  if(pfd)
    8000504c:	00090463          	beqz	s2,80005054 <argfd+0x46>
    *pfd = fd;
    80005050:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80005054:	4501                	li	a0,0
  if(pf)
    80005056:	c091                	beqz	s1,8000505a <argfd+0x4c>
    *pf = f;
    80005058:	e09c                	sd	a5,0(s1)
}
    8000505a:	70a2                	ld	ra,40(sp)
    8000505c:	7402                	ld	s0,32(sp)
    8000505e:	64e2                	ld	s1,24(sp)
    80005060:	6942                	ld	s2,16(sp)
    80005062:	6145                	addi	sp,sp,48
    80005064:	8082                	ret
    return -1;
    80005066:	557d                	li	a0,-1
    80005068:	bfcd                	j	8000505a <argfd+0x4c>
    8000506a:	557d                	li	a0,-1
    8000506c:	b7fd                	j	8000505a <argfd+0x4c>

000000008000506e <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    8000506e:	1101                	addi	sp,sp,-32
    80005070:	ec06                	sd	ra,24(sp)
    80005072:	e822                	sd	s0,16(sp)
    80005074:	e426                	sd	s1,8(sp)
    80005076:	1000                	addi	s0,sp,32
    80005078:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    8000507a:	ffffd097          	auipc	ra,0xffffd
    8000507e:	930080e7          	jalr	-1744(ra) # 800019aa <myproc>
    80005082:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80005084:	0d050793          	addi	a5,a0,208
    80005088:	4501                	li	a0,0
    8000508a:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    8000508c:	6398                	ld	a4,0(a5)
    8000508e:	cb19                	beqz	a4,800050a4 <fdalloc+0x36>
  for(fd = 0; fd < NOFILE; fd++){
    80005090:	2505                	addiw	a0,a0,1
    80005092:	07a1                	addi	a5,a5,8
    80005094:	fed51ce3          	bne	a0,a3,8000508c <fdalloc+0x1e>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80005098:	557d                	li	a0,-1
}
    8000509a:	60e2                	ld	ra,24(sp)
    8000509c:	6442                	ld	s0,16(sp)
    8000509e:	64a2                	ld	s1,8(sp)
    800050a0:	6105                	addi	sp,sp,32
    800050a2:	8082                	ret
      p->ofile[fd] = f;
    800050a4:	01a50793          	addi	a5,a0,26
    800050a8:	078e                	slli	a5,a5,0x3
    800050aa:	963e                	add	a2,a2,a5
    800050ac:	e204                	sd	s1,0(a2)
      return fd;
    800050ae:	b7f5                	j	8000509a <fdalloc+0x2c>

00000000800050b0 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    800050b0:	715d                	addi	sp,sp,-80
    800050b2:	e486                	sd	ra,72(sp)
    800050b4:	e0a2                	sd	s0,64(sp)
    800050b6:	fc26                	sd	s1,56(sp)
    800050b8:	f84a                	sd	s2,48(sp)
    800050ba:	f44e                	sd	s3,40(sp)
    800050bc:	f052                	sd	s4,32(sp)
    800050be:	ec56                	sd	s5,24(sp)
    800050c0:	e85a                	sd	s6,16(sp)
    800050c2:	0880                	addi	s0,sp,80
    800050c4:	8b2e                	mv	s6,a1
    800050c6:	89b2                	mv	s3,a2
    800050c8:	8936                	mv	s2,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    800050ca:	fb040593          	addi	a1,s0,-80
    800050ce:	fffff097          	auipc	ra,0xfffff
    800050d2:	e3e080e7          	jalr	-450(ra) # 80003f0c <nameiparent>
    800050d6:	84aa                	mv	s1,a0
    800050d8:	14050f63          	beqz	a0,80005236 <create+0x186>
    return 0;

  ilock(dp);
    800050dc:	ffffe097          	auipc	ra,0xffffe
    800050e0:	666080e7          	jalr	1638(ra) # 80003742 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    800050e4:	4601                	li	a2,0
    800050e6:	fb040593          	addi	a1,s0,-80
    800050ea:	8526                	mv	a0,s1
    800050ec:	fffff097          	auipc	ra,0xfffff
    800050f0:	b3a080e7          	jalr	-1222(ra) # 80003c26 <dirlookup>
    800050f4:	8aaa                	mv	s5,a0
    800050f6:	c931                	beqz	a0,8000514a <create+0x9a>
    iunlockput(dp);
    800050f8:	8526                	mv	a0,s1
    800050fa:	fffff097          	auipc	ra,0xfffff
    800050fe:	8aa080e7          	jalr	-1878(ra) # 800039a4 <iunlockput>
    ilock(ip);
    80005102:	8556                	mv	a0,s5
    80005104:	ffffe097          	auipc	ra,0xffffe
    80005108:	63e080e7          	jalr	1598(ra) # 80003742 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    8000510c:	000b059b          	sext.w	a1,s6
    80005110:	4789                	li	a5,2
    80005112:	02f59563          	bne	a1,a5,8000513c <create+0x8c>
    80005116:	044ad783          	lhu	a5,68(s5) # fffffffffffff044 <end+0xffffffff7ffdcee4>
    8000511a:	37f9                	addiw	a5,a5,-2
    8000511c:	17c2                	slli	a5,a5,0x30
    8000511e:	93c1                	srli	a5,a5,0x30
    80005120:	4705                	li	a4,1
    80005122:	00f76d63          	bltu	a4,a5,8000513c <create+0x8c>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80005126:	8556                	mv	a0,s5
    80005128:	60a6                	ld	ra,72(sp)
    8000512a:	6406                	ld	s0,64(sp)
    8000512c:	74e2                	ld	s1,56(sp)
    8000512e:	7942                	ld	s2,48(sp)
    80005130:	79a2                	ld	s3,40(sp)
    80005132:	7a02                	ld	s4,32(sp)
    80005134:	6ae2                	ld	s5,24(sp)
    80005136:	6b42                	ld	s6,16(sp)
    80005138:	6161                	addi	sp,sp,80
    8000513a:	8082                	ret
    iunlockput(ip);
    8000513c:	8556                	mv	a0,s5
    8000513e:	fffff097          	auipc	ra,0xfffff
    80005142:	866080e7          	jalr	-1946(ra) # 800039a4 <iunlockput>
    return 0;
    80005146:	4a81                	li	s5,0
    80005148:	bff9                	j	80005126 <create+0x76>
  if((ip = ialloc(dp->dev, type)) == 0){
    8000514a:	85da                	mv	a1,s6
    8000514c:	4088                	lw	a0,0(s1)
    8000514e:	ffffe097          	auipc	ra,0xffffe
    80005152:	456080e7          	jalr	1110(ra) # 800035a4 <ialloc>
    80005156:	8a2a                	mv	s4,a0
    80005158:	c539                	beqz	a0,800051a6 <create+0xf6>
  ilock(ip);
    8000515a:	ffffe097          	auipc	ra,0xffffe
    8000515e:	5e8080e7          	jalr	1512(ra) # 80003742 <ilock>
  ip->major = major;
    80005162:	053a1323          	sh	s3,70(s4)
  ip->minor = minor;
    80005166:	052a1423          	sh	s2,72(s4)
  ip->nlink = 1;
    8000516a:	4905                	li	s2,1
    8000516c:	052a1523          	sh	s2,74(s4)
  iupdate(ip);
    80005170:	8552                	mv	a0,s4
    80005172:	ffffe097          	auipc	ra,0xffffe
    80005176:	504080e7          	jalr	1284(ra) # 80003676 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    8000517a:	000b059b          	sext.w	a1,s6
    8000517e:	03258b63          	beq	a1,s2,800051b4 <create+0x104>
  if(dirlink(dp, name, ip->inum) < 0)
    80005182:	004a2603          	lw	a2,4(s4)
    80005186:	fb040593          	addi	a1,s0,-80
    8000518a:	8526                	mv	a0,s1
    8000518c:	fffff097          	auipc	ra,0xfffff
    80005190:	cb0080e7          	jalr	-848(ra) # 80003e3c <dirlink>
    80005194:	06054f63          	bltz	a0,80005212 <create+0x162>
  iunlockput(dp);
    80005198:	8526                	mv	a0,s1
    8000519a:	fffff097          	auipc	ra,0xfffff
    8000519e:	80a080e7          	jalr	-2038(ra) # 800039a4 <iunlockput>
  return ip;
    800051a2:	8ad2                	mv	s5,s4
    800051a4:	b749                	j	80005126 <create+0x76>
    iunlockput(dp);
    800051a6:	8526                	mv	a0,s1
    800051a8:	ffffe097          	auipc	ra,0xffffe
    800051ac:	7fc080e7          	jalr	2044(ra) # 800039a4 <iunlockput>
    return 0;
    800051b0:	8ad2                	mv	s5,s4
    800051b2:	bf95                	j	80005126 <create+0x76>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    800051b4:	004a2603          	lw	a2,4(s4)
    800051b8:	00003597          	auipc	a1,0x3
    800051bc:	53858593          	addi	a1,a1,1336 # 800086f0 <syscalls+0x2a0>
    800051c0:	8552                	mv	a0,s4
    800051c2:	fffff097          	auipc	ra,0xfffff
    800051c6:	c7a080e7          	jalr	-902(ra) # 80003e3c <dirlink>
    800051ca:	04054463          	bltz	a0,80005212 <create+0x162>
    800051ce:	40d0                	lw	a2,4(s1)
    800051d0:	00003597          	auipc	a1,0x3
    800051d4:	52858593          	addi	a1,a1,1320 # 800086f8 <syscalls+0x2a8>
    800051d8:	8552                	mv	a0,s4
    800051da:	fffff097          	auipc	ra,0xfffff
    800051de:	c62080e7          	jalr	-926(ra) # 80003e3c <dirlink>
    800051e2:	02054863          	bltz	a0,80005212 <create+0x162>
  if(dirlink(dp, name, ip->inum) < 0)
    800051e6:	004a2603          	lw	a2,4(s4)
    800051ea:	fb040593          	addi	a1,s0,-80
    800051ee:	8526                	mv	a0,s1
    800051f0:	fffff097          	auipc	ra,0xfffff
    800051f4:	c4c080e7          	jalr	-948(ra) # 80003e3c <dirlink>
    800051f8:	00054d63          	bltz	a0,80005212 <create+0x162>
    dp->nlink++;  // for ".."
    800051fc:	04a4d783          	lhu	a5,74(s1)
    80005200:	2785                	addiw	a5,a5,1
    80005202:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80005206:	8526                	mv	a0,s1
    80005208:	ffffe097          	auipc	ra,0xffffe
    8000520c:	46e080e7          	jalr	1134(ra) # 80003676 <iupdate>
    80005210:	b761                	j	80005198 <create+0xe8>
  ip->nlink = 0;
    80005212:	040a1523          	sh	zero,74(s4)
  iupdate(ip);
    80005216:	8552                	mv	a0,s4
    80005218:	ffffe097          	auipc	ra,0xffffe
    8000521c:	45e080e7          	jalr	1118(ra) # 80003676 <iupdate>
  iunlockput(ip);
    80005220:	8552                	mv	a0,s4
    80005222:	ffffe097          	auipc	ra,0xffffe
    80005226:	782080e7          	jalr	1922(ra) # 800039a4 <iunlockput>
  iunlockput(dp);
    8000522a:	8526                	mv	a0,s1
    8000522c:	ffffe097          	auipc	ra,0xffffe
    80005230:	778080e7          	jalr	1912(ra) # 800039a4 <iunlockput>
  return 0;
    80005234:	bdcd                	j	80005126 <create+0x76>
    return 0;
    80005236:	8aaa                	mv	s5,a0
    80005238:	b5fd                	j	80005126 <create+0x76>

000000008000523a <sys_dup>:
{
    8000523a:	7179                	addi	sp,sp,-48
    8000523c:	f406                	sd	ra,40(sp)
    8000523e:	f022                	sd	s0,32(sp)
    80005240:	ec26                	sd	s1,24(sp)
    80005242:	e84a                	sd	s2,16(sp)
    80005244:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80005246:	fd840613          	addi	a2,s0,-40
    8000524a:	4581                	li	a1,0
    8000524c:	4501                	li	a0,0
    8000524e:	00000097          	auipc	ra,0x0
    80005252:	dc0080e7          	jalr	-576(ra) # 8000500e <argfd>
    return -1;
    80005256:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80005258:	02054363          	bltz	a0,8000527e <sys_dup+0x44>
  if((fd=fdalloc(f)) < 0)
    8000525c:	fd843903          	ld	s2,-40(s0)
    80005260:	854a                	mv	a0,s2
    80005262:	00000097          	auipc	ra,0x0
    80005266:	e0c080e7          	jalr	-500(ra) # 8000506e <fdalloc>
    8000526a:	84aa                	mv	s1,a0
    return -1;
    8000526c:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    8000526e:	00054863          	bltz	a0,8000527e <sys_dup+0x44>
  filedup(f);
    80005272:	854a                	mv	a0,s2
    80005274:	fffff097          	auipc	ra,0xfffff
    80005278:	310080e7          	jalr	784(ra) # 80004584 <filedup>
  return fd;
    8000527c:	87a6                	mv	a5,s1
}
    8000527e:	853e                	mv	a0,a5
    80005280:	70a2                	ld	ra,40(sp)
    80005282:	7402                	ld	s0,32(sp)
    80005284:	64e2                	ld	s1,24(sp)
    80005286:	6942                	ld	s2,16(sp)
    80005288:	6145                	addi	sp,sp,48
    8000528a:	8082                	ret

000000008000528c <sys_read>:
{
    8000528c:	7179                	addi	sp,sp,-48
    8000528e:	f406                	sd	ra,40(sp)
    80005290:	f022                	sd	s0,32(sp)
    80005292:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80005294:	fd840593          	addi	a1,s0,-40
    80005298:	4505                	li	a0,1
    8000529a:	ffffe097          	auipc	ra,0xffffe
    8000529e:	95e080e7          	jalr	-1698(ra) # 80002bf8 <argaddr>
  argint(2, &n);
    800052a2:	fe440593          	addi	a1,s0,-28
    800052a6:	4509                	li	a0,2
    800052a8:	ffffe097          	auipc	ra,0xffffe
    800052ac:	930080e7          	jalr	-1744(ra) # 80002bd8 <argint>
  if(argfd(0, 0, &f) < 0)
    800052b0:	fe840613          	addi	a2,s0,-24
    800052b4:	4581                	li	a1,0
    800052b6:	4501                	li	a0,0
    800052b8:	00000097          	auipc	ra,0x0
    800052bc:	d56080e7          	jalr	-682(ra) # 8000500e <argfd>
    800052c0:	87aa                	mv	a5,a0
    return -1;
    800052c2:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800052c4:	0007cc63          	bltz	a5,800052dc <sys_read+0x50>
  return fileread(f, p, n);
    800052c8:	fe442603          	lw	a2,-28(s0)
    800052cc:	fd843583          	ld	a1,-40(s0)
    800052d0:	fe843503          	ld	a0,-24(s0)
    800052d4:	fffff097          	auipc	ra,0xfffff
    800052d8:	43c080e7          	jalr	1084(ra) # 80004710 <fileread>
}
    800052dc:	70a2                	ld	ra,40(sp)
    800052de:	7402                	ld	s0,32(sp)
    800052e0:	6145                	addi	sp,sp,48
    800052e2:	8082                	ret

00000000800052e4 <sys_write>:
{
    800052e4:	7179                	addi	sp,sp,-48
    800052e6:	f406                	sd	ra,40(sp)
    800052e8:	f022                	sd	s0,32(sp)
    800052ea:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    800052ec:	fd840593          	addi	a1,s0,-40
    800052f0:	4505                	li	a0,1
    800052f2:	ffffe097          	auipc	ra,0xffffe
    800052f6:	906080e7          	jalr	-1786(ra) # 80002bf8 <argaddr>
  argint(2, &n);
    800052fa:	fe440593          	addi	a1,s0,-28
    800052fe:	4509                	li	a0,2
    80005300:	ffffe097          	auipc	ra,0xffffe
    80005304:	8d8080e7          	jalr	-1832(ra) # 80002bd8 <argint>
  if(argfd(0, 0, &f) < 0)
    80005308:	fe840613          	addi	a2,s0,-24
    8000530c:	4581                	li	a1,0
    8000530e:	4501                	li	a0,0
    80005310:	00000097          	auipc	ra,0x0
    80005314:	cfe080e7          	jalr	-770(ra) # 8000500e <argfd>
    80005318:	87aa                	mv	a5,a0
    return -1;
    8000531a:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    8000531c:	0007cc63          	bltz	a5,80005334 <sys_write+0x50>
  return filewrite(f, p, n);
    80005320:	fe442603          	lw	a2,-28(s0)
    80005324:	fd843583          	ld	a1,-40(s0)
    80005328:	fe843503          	ld	a0,-24(s0)
    8000532c:	fffff097          	auipc	ra,0xfffff
    80005330:	4a6080e7          	jalr	1190(ra) # 800047d2 <filewrite>
}
    80005334:	70a2                	ld	ra,40(sp)
    80005336:	7402                	ld	s0,32(sp)
    80005338:	6145                	addi	sp,sp,48
    8000533a:	8082                	ret

000000008000533c <sys_close>:
{
    8000533c:	1101                	addi	sp,sp,-32
    8000533e:	ec06                	sd	ra,24(sp)
    80005340:	e822                	sd	s0,16(sp)
    80005342:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80005344:	fe040613          	addi	a2,s0,-32
    80005348:	fec40593          	addi	a1,s0,-20
    8000534c:	4501                	li	a0,0
    8000534e:	00000097          	auipc	ra,0x0
    80005352:	cc0080e7          	jalr	-832(ra) # 8000500e <argfd>
    return -1;
    80005356:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80005358:	02054463          	bltz	a0,80005380 <sys_close+0x44>
  myproc()->ofile[fd] = 0;
    8000535c:	ffffc097          	auipc	ra,0xffffc
    80005360:	64e080e7          	jalr	1614(ra) # 800019aa <myproc>
    80005364:	fec42783          	lw	a5,-20(s0)
    80005368:	07e9                	addi	a5,a5,26
    8000536a:	078e                	slli	a5,a5,0x3
    8000536c:	953e                	add	a0,a0,a5
    8000536e:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80005372:	fe043503          	ld	a0,-32(s0)
    80005376:	fffff097          	auipc	ra,0xfffff
    8000537a:	260080e7          	jalr	608(ra) # 800045d6 <fileclose>
  return 0;
    8000537e:	4781                	li	a5,0
}
    80005380:	853e                	mv	a0,a5
    80005382:	60e2                	ld	ra,24(sp)
    80005384:	6442                	ld	s0,16(sp)
    80005386:	6105                	addi	sp,sp,32
    80005388:	8082                	ret

000000008000538a <sys_fstat>:
{
    8000538a:	1101                	addi	sp,sp,-32
    8000538c:	ec06                	sd	ra,24(sp)
    8000538e:	e822                	sd	s0,16(sp)
    80005390:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80005392:	fe040593          	addi	a1,s0,-32
    80005396:	4505                	li	a0,1
    80005398:	ffffe097          	auipc	ra,0xffffe
    8000539c:	860080e7          	jalr	-1952(ra) # 80002bf8 <argaddr>
  if(argfd(0, 0, &f) < 0)
    800053a0:	fe840613          	addi	a2,s0,-24
    800053a4:	4581                	li	a1,0
    800053a6:	4501                	li	a0,0
    800053a8:	00000097          	auipc	ra,0x0
    800053ac:	c66080e7          	jalr	-922(ra) # 8000500e <argfd>
    800053b0:	87aa                	mv	a5,a0
    return -1;
    800053b2:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800053b4:	0007ca63          	bltz	a5,800053c8 <sys_fstat+0x3e>
  return filestat(f, st);
    800053b8:	fe043583          	ld	a1,-32(s0)
    800053bc:	fe843503          	ld	a0,-24(s0)
    800053c0:	fffff097          	auipc	ra,0xfffff
    800053c4:	2de080e7          	jalr	734(ra) # 8000469e <filestat>
}
    800053c8:	60e2                	ld	ra,24(sp)
    800053ca:	6442                	ld	s0,16(sp)
    800053cc:	6105                	addi	sp,sp,32
    800053ce:	8082                	ret

00000000800053d0 <sys_link>:
{
    800053d0:	7169                	addi	sp,sp,-304
    800053d2:	f606                	sd	ra,296(sp)
    800053d4:	f222                	sd	s0,288(sp)
    800053d6:	ee26                	sd	s1,280(sp)
    800053d8:	ea4a                	sd	s2,272(sp)
    800053da:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    800053dc:	08000613          	li	a2,128
    800053e0:	ed040593          	addi	a1,s0,-304
    800053e4:	4501                	li	a0,0
    800053e6:	ffffe097          	auipc	ra,0xffffe
    800053ea:	832080e7          	jalr	-1998(ra) # 80002c18 <argstr>
    return -1;
    800053ee:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    800053f0:	10054e63          	bltz	a0,8000550c <sys_link+0x13c>
    800053f4:	08000613          	li	a2,128
    800053f8:	f5040593          	addi	a1,s0,-176
    800053fc:	4505                	li	a0,1
    800053fe:	ffffe097          	auipc	ra,0xffffe
    80005402:	81a080e7          	jalr	-2022(ra) # 80002c18 <argstr>
    return -1;
    80005406:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80005408:	10054263          	bltz	a0,8000550c <sys_link+0x13c>
  begin_op();
    8000540c:	fffff097          	auipc	ra,0xfffff
    80005410:	d02080e7          	jalr	-766(ra) # 8000410e <begin_op>
  if((ip = namei(old)) == 0){
    80005414:	ed040513          	addi	a0,s0,-304
    80005418:	fffff097          	auipc	ra,0xfffff
    8000541c:	ad6080e7          	jalr	-1322(ra) # 80003eee <namei>
    80005420:	84aa                	mv	s1,a0
    80005422:	c551                	beqz	a0,800054ae <sys_link+0xde>
  ilock(ip);
    80005424:	ffffe097          	auipc	ra,0xffffe
    80005428:	31e080e7          	jalr	798(ra) # 80003742 <ilock>
  if(ip->type == T_DIR){
    8000542c:	04449703          	lh	a4,68(s1)
    80005430:	4785                	li	a5,1
    80005432:	08f70463          	beq	a4,a5,800054ba <sys_link+0xea>
  ip->nlink++;
    80005436:	04a4d783          	lhu	a5,74(s1)
    8000543a:	2785                	addiw	a5,a5,1
    8000543c:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80005440:	8526                	mv	a0,s1
    80005442:	ffffe097          	auipc	ra,0xffffe
    80005446:	234080e7          	jalr	564(ra) # 80003676 <iupdate>
  iunlock(ip);
    8000544a:	8526                	mv	a0,s1
    8000544c:	ffffe097          	auipc	ra,0xffffe
    80005450:	3b8080e7          	jalr	952(ra) # 80003804 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80005454:	fd040593          	addi	a1,s0,-48
    80005458:	f5040513          	addi	a0,s0,-176
    8000545c:	fffff097          	auipc	ra,0xfffff
    80005460:	ab0080e7          	jalr	-1360(ra) # 80003f0c <nameiparent>
    80005464:	892a                	mv	s2,a0
    80005466:	c935                	beqz	a0,800054da <sys_link+0x10a>
  ilock(dp);
    80005468:	ffffe097          	auipc	ra,0xffffe
    8000546c:	2da080e7          	jalr	730(ra) # 80003742 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80005470:	00092703          	lw	a4,0(s2)
    80005474:	409c                	lw	a5,0(s1)
    80005476:	04f71d63          	bne	a4,a5,800054d0 <sys_link+0x100>
    8000547a:	40d0                	lw	a2,4(s1)
    8000547c:	fd040593          	addi	a1,s0,-48
    80005480:	854a                	mv	a0,s2
    80005482:	fffff097          	auipc	ra,0xfffff
    80005486:	9ba080e7          	jalr	-1606(ra) # 80003e3c <dirlink>
    8000548a:	04054363          	bltz	a0,800054d0 <sys_link+0x100>
  iunlockput(dp);
    8000548e:	854a                	mv	a0,s2
    80005490:	ffffe097          	auipc	ra,0xffffe
    80005494:	514080e7          	jalr	1300(ra) # 800039a4 <iunlockput>
  iput(ip);
    80005498:	8526                	mv	a0,s1
    8000549a:	ffffe097          	auipc	ra,0xffffe
    8000549e:	462080e7          	jalr	1122(ra) # 800038fc <iput>
  end_op();
    800054a2:	fffff097          	auipc	ra,0xfffff
    800054a6:	cea080e7          	jalr	-790(ra) # 8000418c <end_op>
  return 0;
    800054aa:	4781                	li	a5,0
    800054ac:	a085                	j	8000550c <sys_link+0x13c>
    end_op();
    800054ae:	fffff097          	auipc	ra,0xfffff
    800054b2:	cde080e7          	jalr	-802(ra) # 8000418c <end_op>
    return -1;
    800054b6:	57fd                	li	a5,-1
    800054b8:	a891                	j	8000550c <sys_link+0x13c>
    iunlockput(ip);
    800054ba:	8526                	mv	a0,s1
    800054bc:	ffffe097          	auipc	ra,0xffffe
    800054c0:	4e8080e7          	jalr	1256(ra) # 800039a4 <iunlockput>
    end_op();
    800054c4:	fffff097          	auipc	ra,0xfffff
    800054c8:	cc8080e7          	jalr	-824(ra) # 8000418c <end_op>
    return -1;
    800054cc:	57fd                	li	a5,-1
    800054ce:	a83d                	j	8000550c <sys_link+0x13c>
    iunlockput(dp);
    800054d0:	854a                	mv	a0,s2
    800054d2:	ffffe097          	auipc	ra,0xffffe
    800054d6:	4d2080e7          	jalr	1234(ra) # 800039a4 <iunlockput>
  ilock(ip);
    800054da:	8526                	mv	a0,s1
    800054dc:	ffffe097          	auipc	ra,0xffffe
    800054e0:	266080e7          	jalr	614(ra) # 80003742 <ilock>
  ip->nlink--;
    800054e4:	04a4d783          	lhu	a5,74(s1)
    800054e8:	37fd                	addiw	a5,a5,-1
    800054ea:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    800054ee:	8526                	mv	a0,s1
    800054f0:	ffffe097          	auipc	ra,0xffffe
    800054f4:	186080e7          	jalr	390(ra) # 80003676 <iupdate>
  iunlockput(ip);
    800054f8:	8526                	mv	a0,s1
    800054fa:	ffffe097          	auipc	ra,0xffffe
    800054fe:	4aa080e7          	jalr	1194(ra) # 800039a4 <iunlockput>
  end_op();
    80005502:	fffff097          	auipc	ra,0xfffff
    80005506:	c8a080e7          	jalr	-886(ra) # 8000418c <end_op>
  return -1;
    8000550a:	57fd                	li	a5,-1
}
    8000550c:	853e                	mv	a0,a5
    8000550e:	70b2                	ld	ra,296(sp)
    80005510:	7412                	ld	s0,288(sp)
    80005512:	64f2                	ld	s1,280(sp)
    80005514:	6952                	ld	s2,272(sp)
    80005516:	6155                	addi	sp,sp,304
    80005518:	8082                	ret

000000008000551a <sys_unlink>:
{
    8000551a:	7151                	addi	sp,sp,-240
    8000551c:	f586                	sd	ra,232(sp)
    8000551e:	f1a2                	sd	s0,224(sp)
    80005520:	eda6                	sd	s1,216(sp)
    80005522:	e9ca                	sd	s2,208(sp)
    80005524:	e5ce                	sd	s3,200(sp)
    80005526:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80005528:	08000613          	li	a2,128
    8000552c:	f3040593          	addi	a1,s0,-208
    80005530:	4501                	li	a0,0
    80005532:	ffffd097          	auipc	ra,0xffffd
    80005536:	6e6080e7          	jalr	1766(ra) # 80002c18 <argstr>
    8000553a:	18054163          	bltz	a0,800056bc <sys_unlink+0x1a2>
  begin_op();
    8000553e:	fffff097          	auipc	ra,0xfffff
    80005542:	bd0080e7          	jalr	-1072(ra) # 8000410e <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80005546:	fb040593          	addi	a1,s0,-80
    8000554a:	f3040513          	addi	a0,s0,-208
    8000554e:	fffff097          	auipc	ra,0xfffff
    80005552:	9be080e7          	jalr	-1602(ra) # 80003f0c <nameiparent>
    80005556:	84aa                	mv	s1,a0
    80005558:	c979                	beqz	a0,8000562e <sys_unlink+0x114>
  ilock(dp);
    8000555a:	ffffe097          	auipc	ra,0xffffe
    8000555e:	1e8080e7          	jalr	488(ra) # 80003742 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80005562:	00003597          	auipc	a1,0x3
    80005566:	18e58593          	addi	a1,a1,398 # 800086f0 <syscalls+0x2a0>
    8000556a:	fb040513          	addi	a0,s0,-80
    8000556e:	ffffe097          	auipc	ra,0xffffe
    80005572:	69e080e7          	jalr	1694(ra) # 80003c0c <namecmp>
    80005576:	14050a63          	beqz	a0,800056ca <sys_unlink+0x1b0>
    8000557a:	00003597          	auipc	a1,0x3
    8000557e:	17e58593          	addi	a1,a1,382 # 800086f8 <syscalls+0x2a8>
    80005582:	fb040513          	addi	a0,s0,-80
    80005586:	ffffe097          	auipc	ra,0xffffe
    8000558a:	686080e7          	jalr	1670(ra) # 80003c0c <namecmp>
    8000558e:	12050e63          	beqz	a0,800056ca <sys_unlink+0x1b0>
  if((ip = dirlookup(dp, name, &off)) == 0)
    80005592:	f2c40613          	addi	a2,s0,-212
    80005596:	fb040593          	addi	a1,s0,-80
    8000559a:	8526                	mv	a0,s1
    8000559c:	ffffe097          	auipc	ra,0xffffe
    800055a0:	68a080e7          	jalr	1674(ra) # 80003c26 <dirlookup>
    800055a4:	892a                	mv	s2,a0
    800055a6:	12050263          	beqz	a0,800056ca <sys_unlink+0x1b0>
  ilock(ip);
    800055aa:	ffffe097          	auipc	ra,0xffffe
    800055ae:	198080e7          	jalr	408(ra) # 80003742 <ilock>
  if(ip->nlink < 1)
    800055b2:	04a91783          	lh	a5,74(s2)
    800055b6:	08f05263          	blez	a5,8000563a <sys_unlink+0x120>
  if(ip->type == T_DIR && !isdirempty(ip)){
    800055ba:	04491703          	lh	a4,68(s2)
    800055be:	4785                	li	a5,1
    800055c0:	08f70563          	beq	a4,a5,8000564a <sys_unlink+0x130>
  memset(&de, 0, sizeof(de));
    800055c4:	4641                	li	a2,16
    800055c6:	4581                	li	a1,0
    800055c8:	fc040513          	addi	a0,s0,-64
    800055cc:	ffffb097          	auipc	ra,0xffffb
    800055d0:	704080e7          	jalr	1796(ra) # 80000cd0 <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800055d4:	4741                	li	a4,16
    800055d6:	f2c42683          	lw	a3,-212(s0)
    800055da:	fc040613          	addi	a2,s0,-64
    800055de:	4581                	li	a1,0
    800055e0:	8526                	mv	a0,s1
    800055e2:	ffffe097          	auipc	ra,0xffffe
    800055e6:	50c080e7          	jalr	1292(ra) # 80003aee <writei>
    800055ea:	47c1                	li	a5,16
    800055ec:	0af51563          	bne	a0,a5,80005696 <sys_unlink+0x17c>
  if(ip->type == T_DIR){
    800055f0:	04491703          	lh	a4,68(s2)
    800055f4:	4785                	li	a5,1
    800055f6:	0af70863          	beq	a4,a5,800056a6 <sys_unlink+0x18c>
  iunlockput(dp);
    800055fa:	8526                	mv	a0,s1
    800055fc:	ffffe097          	auipc	ra,0xffffe
    80005600:	3a8080e7          	jalr	936(ra) # 800039a4 <iunlockput>
  ip->nlink--;
    80005604:	04a95783          	lhu	a5,74(s2)
    80005608:	37fd                	addiw	a5,a5,-1
    8000560a:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    8000560e:	854a                	mv	a0,s2
    80005610:	ffffe097          	auipc	ra,0xffffe
    80005614:	066080e7          	jalr	102(ra) # 80003676 <iupdate>
  iunlockput(ip);
    80005618:	854a                	mv	a0,s2
    8000561a:	ffffe097          	auipc	ra,0xffffe
    8000561e:	38a080e7          	jalr	906(ra) # 800039a4 <iunlockput>
  end_op();
    80005622:	fffff097          	auipc	ra,0xfffff
    80005626:	b6a080e7          	jalr	-1174(ra) # 8000418c <end_op>
  return 0;
    8000562a:	4501                	li	a0,0
    8000562c:	a84d                	j	800056de <sys_unlink+0x1c4>
    end_op();
    8000562e:	fffff097          	auipc	ra,0xfffff
    80005632:	b5e080e7          	jalr	-1186(ra) # 8000418c <end_op>
    return -1;
    80005636:	557d                	li	a0,-1
    80005638:	a05d                	j	800056de <sys_unlink+0x1c4>
    panic("unlink: nlink < 1");
    8000563a:	00003517          	auipc	a0,0x3
    8000563e:	0c650513          	addi	a0,a0,198 # 80008700 <syscalls+0x2b0>
    80005642:	ffffb097          	auipc	ra,0xffffb
    80005646:	efc080e7          	jalr	-260(ra) # 8000053e <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    8000564a:	04c92703          	lw	a4,76(s2)
    8000564e:	02000793          	li	a5,32
    80005652:	f6e7f9e3          	bgeu	a5,a4,800055c4 <sys_unlink+0xaa>
    80005656:	02000993          	li	s3,32
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000565a:	4741                	li	a4,16
    8000565c:	86ce                	mv	a3,s3
    8000565e:	f1840613          	addi	a2,s0,-232
    80005662:	4581                	li	a1,0
    80005664:	854a                	mv	a0,s2
    80005666:	ffffe097          	auipc	ra,0xffffe
    8000566a:	390080e7          	jalr	912(ra) # 800039f6 <readi>
    8000566e:	47c1                	li	a5,16
    80005670:	00f51b63          	bne	a0,a5,80005686 <sys_unlink+0x16c>
    if(de.inum != 0)
    80005674:	f1845783          	lhu	a5,-232(s0)
    80005678:	e7a1                	bnez	a5,800056c0 <sys_unlink+0x1a6>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    8000567a:	29c1                	addiw	s3,s3,16
    8000567c:	04c92783          	lw	a5,76(s2)
    80005680:	fcf9ede3          	bltu	s3,a5,8000565a <sys_unlink+0x140>
    80005684:	b781                	j	800055c4 <sys_unlink+0xaa>
      panic("isdirempty: readi");
    80005686:	00003517          	auipc	a0,0x3
    8000568a:	09250513          	addi	a0,a0,146 # 80008718 <syscalls+0x2c8>
    8000568e:	ffffb097          	auipc	ra,0xffffb
    80005692:	eb0080e7          	jalr	-336(ra) # 8000053e <panic>
    panic("unlink: writei");
    80005696:	00003517          	auipc	a0,0x3
    8000569a:	09a50513          	addi	a0,a0,154 # 80008730 <syscalls+0x2e0>
    8000569e:	ffffb097          	auipc	ra,0xffffb
    800056a2:	ea0080e7          	jalr	-352(ra) # 8000053e <panic>
    dp->nlink--;
    800056a6:	04a4d783          	lhu	a5,74(s1)
    800056aa:	37fd                	addiw	a5,a5,-1
    800056ac:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800056b0:	8526                	mv	a0,s1
    800056b2:	ffffe097          	auipc	ra,0xffffe
    800056b6:	fc4080e7          	jalr	-60(ra) # 80003676 <iupdate>
    800056ba:	b781                	j	800055fa <sys_unlink+0xe0>
    return -1;
    800056bc:	557d                	li	a0,-1
    800056be:	a005                	j	800056de <sys_unlink+0x1c4>
    iunlockput(ip);
    800056c0:	854a                	mv	a0,s2
    800056c2:	ffffe097          	auipc	ra,0xffffe
    800056c6:	2e2080e7          	jalr	738(ra) # 800039a4 <iunlockput>
  iunlockput(dp);
    800056ca:	8526                	mv	a0,s1
    800056cc:	ffffe097          	auipc	ra,0xffffe
    800056d0:	2d8080e7          	jalr	728(ra) # 800039a4 <iunlockput>
  end_op();
    800056d4:	fffff097          	auipc	ra,0xfffff
    800056d8:	ab8080e7          	jalr	-1352(ra) # 8000418c <end_op>
  return -1;
    800056dc:	557d                	li	a0,-1
}
    800056de:	70ae                	ld	ra,232(sp)
    800056e0:	740e                	ld	s0,224(sp)
    800056e2:	64ee                	ld	s1,216(sp)
    800056e4:	694e                	ld	s2,208(sp)
    800056e6:	69ae                	ld	s3,200(sp)
    800056e8:	616d                	addi	sp,sp,240
    800056ea:	8082                	ret

00000000800056ec <sys_open>:

uint64
sys_open(void)
{
    800056ec:	7131                	addi	sp,sp,-192
    800056ee:	fd06                	sd	ra,184(sp)
    800056f0:	f922                	sd	s0,176(sp)
    800056f2:	f526                	sd	s1,168(sp)
    800056f4:	f14a                	sd	s2,160(sp)
    800056f6:	ed4e                	sd	s3,152(sp)
    800056f8:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    800056fa:	f4c40593          	addi	a1,s0,-180
    800056fe:	4505                	li	a0,1
    80005700:	ffffd097          	auipc	ra,0xffffd
    80005704:	4d8080e7          	jalr	1240(ra) # 80002bd8 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    80005708:	08000613          	li	a2,128
    8000570c:	f5040593          	addi	a1,s0,-176
    80005710:	4501                	li	a0,0
    80005712:	ffffd097          	auipc	ra,0xffffd
    80005716:	506080e7          	jalr	1286(ra) # 80002c18 <argstr>
    8000571a:	87aa                	mv	a5,a0
    return -1;
    8000571c:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    8000571e:	0a07c963          	bltz	a5,800057d0 <sys_open+0xe4>

  begin_op();
    80005722:	fffff097          	auipc	ra,0xfffff
    80005726:	9ec080e7          	jalr	-1556(ra) # 8000410e <begin_op>

  if(omode & O_CREATE){
    8000572a:	f4c42783          	lw	a5,-180(s0)
    8000572e:	2007f793          	andi	a5,a5,512
    80005732:	cfc5                	beqz	a5,800057ea <sys_open+0xfe>
    ip = create(path, T_FILE, 0, 0);
    80005734:	4681                	li	a3,0
    80005736:	4601                	li	a2,0
    80005738:	4589                	li	a1,2
    8000573a:	f5040513          	addi	a0,s0,-176
    8000573e:	00000097          	auipc	ra,0x0
    80005742:	972080e7          	jalr	-1678(ra) # 800050b0 <create>
    80005746:	84aa                	mv	s1,a0
    if(ip == 0){
    80005748:	c959                	beqz	a0,800057de <sys_open+0xf2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    8000574a:	04449703          	lh	a4,68(s1)
    8000574e:	478d                	li	a5,3
    80005750:	00f71763          	bne	a4,a5,8000575e <sys_open+0x72>
    80005754:	0464d703          	lhu	a4,70(s1)
    80005758:	47a5                	li	a5,9
    8000575a:	0ce7ed63          	bltu	a5,a4,80005834 <sys_open+0x148>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    8000575e:	fffff097          	auipc	ra,0xfffff
    80005762:	dbc080e7          	jalr	-580(ra) # 8000451a <filealloc>
    80005766:	89aa                	mv	s3,a0
    80005768:	10050363          	beqz	a0,8000586e <sys_open+0x182>
    8000576c:	00000097          	auipc	ra,0x0
    80005770:	902080e7          	jalr	-1790(ra) # 8000506e <fdalloc>
    80005774:	892a                	mv	s2,a0
    80005776:	0e054763          	bltz	a0,80005864 <sys_open+0x178>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    8000577a:	04449703          	lh	a4,68(s1)
    8000577e:	478d                	li	a5,3
    80005780:	0cf70563          	beq	a4,a5,8000584a <sys_open+0x15e>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80005784:	4789                	li	a5,2
    80005786:	00f9a023          	sw	a5,0(s3)
    f->off = 0;
    8000578a:	0209a023          	sw	zero,32(s3)
  }
  f->ip = ip;
    8000578e:	0099bc23          	sd	s1,24(s3)
  f->readable = !(omode & O_WRONLY);
    80005792:	f4c42783          	lw	a5,-180(s0)
    80005796:	0017c713          	xori	a4,a5,1
    8000579a:	8b05                	andi	a4,a4,1
    8000579c:	00e98423          	sb	a4,8(s3)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    800057a0:	0037f713          	andi	a4,a5,3
    800057a4:	00e03733          	snez	a4,a4
    800057a8:	00e984a3          	sb	a4,9(s3)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    800057ac:	4007f793          	andi	a5,a5,1024
    800057b0:	c791                	beqz	a5,800057bc <sys_open+0xd0>
    800057b2:	04449703          	lh	a4,68(s1)
    800057b6:	4789                	li	a5,2
    800057b8:	0af70063          	beq	a4,a5,80005858 <sys_open+0x16c>
    itrunc(ip);
  }

  iunlock(ip);
    800057bc:	8526                	mv	a0,s1
    800057be:	ffffe097          	auipc	ra,0xffffe
    800057c2:	046080e7          	jalr	70(ra) # 80003804 <iunlock>
  end_op();
    800057c6:	fffff097          	auipc	ra,0xfffff
    800057ca:	9c6080e7          	jalr	-1594(ra) # 8000418c <end_op>

  return fd;
    800057ce:	854a                	mv	a0,s2
}
    800057d0:	70ea                	ld	ra,184(sp)
    800057d2:	744a                	ld	s0,176(sp)
    800057d4:	74aa                	ld	s1,168(sp)
    800057d6:	790a                	ld	s2,160(sp)
    800057d8:	69ea                	ld	s3,152(sp)
    800057da:	6129                	addi	sp,sp,192
    800057dc:	8082                	ret
      end_op();
    800057de:	fffff097          	auipc	ra,0xfffff
    800057e2:	9ae080e7          	jalr	-1618(ra) # 8000418c <end_op>
      return -1;
    800057e6:	557d                	li	a0,-1
    800057e8:	b7e5                	j	800057d0 <sys_open+0xe4>
    if((ip = namei(path)) == 0){
    800057ea:	f5040513          	addi	a0,s0,-176
    800057ee:	ffffe097          	auipc	ra,0xffffe
    800057f2:	700080e7          	jalr	1792(ra) # 80003eee <namei>
    800057f6:	84aa                	mv	s1,a0
    800057f8:	c905                	beqz	a0,80005828 <sys_open+0x13c>
    ilock(ip);
    800057fa:	ffffe097          	auipc	ra,0xffffe
    800057fe:	f48080e7          	jalr	-184(ra) # 80003742 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    80005802:	04449703          	lh	a4,68(s1)
    80005806:	4785                	li	a5,1
    80005808:	f4f711e3          	bne	a4,a5,8000574a <sys_open+0x5e>
    8000580c:	f4c42783          	lw	a5,-180(s0)
    80005810:	d7b9                	beqz	a5,8000575e <sys_open+0x72>
      iunlockput(ip);
    80005812:	8526                	mv	a0,s1
    80005814:	ffffe097          	auipc	ra,0xffffe
    80005818:	190080e7          	jalr	400(ra) # 800039a4 <iunlockput>
      end_op();
    8000581c:	fffff097          	auipc	ra,0xfffff
    80005820:	970080e7          	jalr	-1680(ra) # 8000418c <end_op>
      return -1;
    80005824:	557d                	li	a0,-1
    80005826:	b76d                	j	800057d0 <sys_open+0xe4>
      end_op();
    80005828:	fffff097          	auipc	ra,0xfffff
    8000582c:	964080e7          	jalr	-1692(ra) # 8000418c <end_op>
      return -1;
    80005830:	557d                	li	a0,-1
    80005832:	bf79                	j	800057d0 <sys_open+0xe4>
    iunlockput(ip);
    80005834:	8526                	mv	a0,s1
    80005836:	ffffe097          	auipc	ra,0xffffe
    8000583a:	16e080e7          	jalr	366(ra) # 800039a4 <iunlockput>
    end_op();
    8000583e:	fffff097          	auipc	ra,0xfffff
    80005842:	94e080e7          	jalr	-1714(ra) # 8000418c <end_op>
    return -1;
    80005846:	557d                	li	a0,-1
    80005848:	b761                	j	800057d0 <sys_open+0xe4>
    f->type = FD_DEVICE;
    8000584a:	00f9a023          	sw	a5,0(s3)
    f->major = ip->major;
    8000584e:	04649783          	lh	a5,70(s1)
    80005852:	02f99223          	sh	a5,36(s3)
    80005856:	bf25                	j	8000578e <sys_open+0xa2>
    itrunc(ip);
    80005858:	8526                	mv	a0,s1
    8000585a:	ffffe097          	auipc	ra,0xffffe
    8000585e:	ff6080e7          	jalr	-10(ra) # 80003850 <itrunc>
    80005862:	bfa9                	j	800057bc <sys_open+0xd0>
      fileclose(f);
    80005864:	854e                	mv	a0,s3
    80005866:	fffff097          	auipc	ra,0xfffff
    8000586a:	d70080e7          	jalr	-656(ra) # 800045d6 <fileclose>
    iunlockput(ip);
    8000586e:	8526                	mv	a0,s1
    80005870:	ffffe097          	auipc	ra,0xffffe
    80005874:	134080e7          	jalr	308(ra) # 800039a4 <iunlockput>
    end_op();
    80005878:	fffff097          	auipc	ra,0xfffff
    8000587c:	914080e7          	jalr	-1772(ra) # 8000418c <end_op>
    return -1;
    80005880:	557d                	li	a0,-1
    80005882:	b7b9                	j	800057d0 <sys_open+0xe4>

0000000080005884 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80005884:	7175                	addi	sp,sp,-144
    80005886:	e506                	sd	ra,136(sp)
    80005888:	e122                	sd	s0,128(sp)
    8000588a:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    8000588c:	fffff097          	auipc	ra,0xfffff
    80005890:	882080e7          	jalr	-1918(ra) # 8000410e <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    80005894:	08000613          	li	a2,128
    80005898:	f7040593          	addi	a1,s0,-144
    8000589c:	4501                	li	a0,0
    8000589e:	ffffd097          	auipc	ra,0xffffd
    800058a2:	37a080e7          	jalr	890(ra) # 80002c18 <argstr>
    800058a6:	02054963          	bltz	a0,800058d8 <sys_mkdir+0x54>
    800058aa:	4681                	li	a3,0
    800058ac:	4601                	li	a2,0
    800058ae:	4585                	li	a1,1
    800058b0:	f7040513          	addi	a0,s0,-144
    800058b4:	fffff097          	auipc	ra,0xfffff
    800058b8:	7fc080e7          	jalr	2044(ra) # 800050b0 <create>
    800058bc:	cd11                	beqz	a0,800058d8 <sys_mkdir+0x54>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800058be:	ffffe097          	auipc	ra,0xffffe
    800058c2:	0e6080e7          	jalr	230(ra) # 800039a4 <iunlockput>
  end_op();
    800058c6:	fffff097          	auipc	ra,0xfffff
    800058ca:	8c6080e7          	jalr	-1850(ra) # 8000418c <end_op>
  return 0;
    800058ce:	4501                	li	a0,0
}
    800058d0:	60aa                	ld	ra,136(sp)
    800058d2:	640a                	ld	s0,128(sp)
    800058d4:	6149                	addi	sp,sp,144
    800058d6:	8082                	ret
    end_op();
    800058d8:	fffff097          	auipc	ra,0xfffff
    800058dc:	8b4080e7          	jalr	-1868(ra) # 8000418c <end_op>
    return -1;
    800058e0:	557d                	li	a0,-1
    800058e2:	b7fd                	j	800058d0 <sys_mkdir+0x4c>

00000000800058e4 <sys_mknod>:

uint64
sys_mknod(void)
{
    800058e4:	7135                	addi	sp,sp,-160
    800058e6:	ed06                	sd	ra,152(sp)
    800058e8:	e922                	sd	s0,144(sp)
    800058ea:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    800058ec:	fffff097          	auipc	ra,0xfffff
    800058f0:	822080e7          	jalr	-2014(ra) # 8000410e <begin_op>
  argint(1, &major);
    800058f4:	f6c40593          	addi	a1,s0,-148
    800058f8:	4505                	li	a0,1
    800058fa:	ffffd097          	auipc	ra,0xffffd
    800058fe:	2de080e7          	jalr	734(ra) # 80002bd8 <argint>
  argint(2, &minor);
    80005902:	f6840593          	addi	a1,s0,-152
    80005906:	4509                	li	a0,2
    80005908:	ffffd097          	auipc	ra,0xffffd
    8000590c:	2d0080e7          	jalr	720(ra) # 80002bd8 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80005910:	08000613          	li	a2,128
    80005914:	f7040593          	addi	a1,s0,-144
    80005918:	4501                	li	a0,0
    8000591a:	ffffd097          	auipc	ra,0xffffd
    8000591e:	2fe080e7          	jalr	766(ra) # 80002c18 <argstr>
    80005922:	02054b63          	bltz	a0,80005958 <sys_mknod+0x74>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    80005926:	f6841683          	lh	a3,-152(s0)
    8000592a:	f6c41603          	lh	a2,-148(s0)
    8000592e:	458d                	li	a1,3
    80005930:	f7040513          	addi	a0,s0,-144
    80005934:	fffff097          	auipc	ra,0xfffff
    80005938:	77c080e7          	jalr	1916(ra) # 800050b0 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    8000593c:	cd11                	beqz	a0,80005958 <sys_mknod+0x74>
    end_op();
    return -1;
  }
  iunlockput(ip);
    8000593e:	ffffe097          	auipc	ra,0xffffe
    80005942:	066080e7          	jalr	102(ra) # 800039a4 <iunlockput>
  end_op();
    80005946:	fffff097          	auipc	ra,0xfffff
    8000594a:	846080e7          	jalr	-1978(ra) # 8000418c <end_op>
  return 0;
    8000594e:	4501                	li	a0,0
}
    80005950:	60ea                	ld	ra,152(sp)
    80005952:	644a                	ld	s0,144(sp)
    80005954:	610d                	addi	sp,sp,160
    80005956:	8082                	ret
    end_op();
    80005958:	fffff097          	auipc	ra,0xfffff
    8000595c:	834080e7          	jalr	-1996(ra) # 8000418c <end_op>
    return -1;
    80005960:	557d                	li	a0,-1
    80005962:	b7fd                	j	80005950 <sys_mknod+0x6c>

0000000080005964 <sys_chdir>:

uint64
sys_chdir(void)
{
    80005964:	7135                	addi	sp,sp,-160
    80005966:	ed06                	sd	ra,152(sp)
    80005968:	e922                	sd	s0,144(sp)
    8000596a:	e526                	sd	s1,136(sp)
    8000596c:	e14a                	sd	s2,128(sp)
    8000596e:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80005970:	ffffc097          	auipc	ra,0xffffc
    80005974:	03a080e7          	jalr	58(ra) # 800019aa <myproc>
    80005978:	892a                	mv	s2,a0
  
  begin_op();
    8000597a:	ffffe097          	auipc	ra,0xffffe
    8000597e:	794080e7          	jalr	1940(ra) # 8000410e <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    80005982:	08000613          	li	a2,128
    80005986:	f6040593          	addi	a1,s0,-160
    8000598a:	4501                	li	a0,0
    8000598c:	ffffd097          	auipc	ra,0xffffd
    80005990:	28c080e7          	jalr	652(ra) # 80002c18 <argstr>
    80005994:	04054b63          	bltz	a0,800059ea <sys_chdir+0x86>
    80005998:	f6040513          	addi	a0,s0,-160
    8000599c:	ffffe097          	auipc	ra,0xffffe
    800059a0:	552080e7          	jalr	1362(ra) # 80003eee <namei>
    800059a4:	84aa                	mv	s1,a0
    800059a6:	c131                	beqz	a0,800059ea <sys_chdir+0x86>
    end_op();
    return -1;
  }
  ilock(ip);
    800059a8:	ffffe097          	auipc	ra,0xffffe
    800059ac:	d9a080e7          	jalr	-614(ra) # 80003742 <ilock>
  if(ip->type != T_DIR){
    800059b0:	04449703          	lh	a4,68(s1)
    800059b4:	4785                	li	a5,1
    800059b6:	04f71063          	bne	a4,a5,800059f6 <sys_chdir+0x92>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    800059ba:	8526                	mv	a0,s1
    800059bc:	ffffe097          	auipc	ra,0xffffe
    800059c0:	e48080e7          	jalr	-440(ra) # 80003804 <iunlock>
  iput(p->cwd);
    800059c4:	15093503          	ld	a0,336(s2)
    800059c8:	ffffe097          	auipc	ra,0xffffe
    800059cc:	f34080e7          	jalr	-204(ra) # 800038fc <iput>
  end_op();
    800059d0:	ffffe097          	auipc	ra,0xffffe
    800059d4:	7bc080e7          	jalr	1980(ra) # 8000418c <end_op>
  p->cwd = ip;
    800059d8:	14993823          	sd	s1,336(s2)
  return 0;
    800059dc:	4501                	li	a0,0
}
    800059de:	60ea                	ld	ra,152(sp)
    800059e0:	644a                	ld	s0,144(sp)
    800059e2:	64aa                	ld	s1,136(sp)
    800059e4:	690a                	ld	s2,128(sp)
    800059e6:	610d                	addi	sp,sp,160
    800059e8:	8082                	ret
    end_op();
    800059ea:	ffffe097          	auipc	ra,0xffffe
    800059ee:	7a2080e7          	jalr	1954(ra) # 8000418c <end_op>
    return -1;
    800059f2:	557d                	li	a0,-1
    800059f4:	b7ed                	j	800059de <sys_chdir+0x7a>
    iunlockput(ip);
    800059f6:	8526                	mv	a0,s1
    800059f8:	ffffe097          	auipc	ra,0xffffe
    800059fc:	fac080e7          	jalr	-84(ra) # 800039a4 <iunlockput>
    end_op();
    80005a00:	ffffe097          	auipc	ra,0xffffe
    80005a04:	78c080e7          	jalr	1932(ra) # 8000418c <end_op>
    return -1;
    80005a08:	557d                	li	a0,-1
    80005a0a:	bfd1                	j	800059de <sys_chdir+0x7a>

0000000080005a0c <sys_exec>:

uint64
sys_exec(void)
{
    80005a0c:	7145                	addi	sp,sp,-464
    80005a0e:	e786                	sd	ra,456(sp)
    80005a10:	e3a2                	sd	s0,448(sp)
    80005a12:	ff26                	sd	s1,440(sp)
    80005a14:	fb4a                	sd	s2,432(sp)
    80005a16:	f74e                	sd	s3,424(sp)
    80005a18:	f352                	sd	s4,416(sp)
    80005a1a:	ef56                	sd	s5,408(sp)
    80005a1c:	0b80                	addi	s0,sp,464
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80005a1e:	e3840593          	addi	a1,s0,-456
    80005a22:	4505                	li	a0,1
    80005a24:	ffffd097          	auipc	ra,0xffffd
    80005a28:	1d4080e7          	jalr	468(ra) # 80002bf8 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80005a2c:	08000613          	li	a2,128
    80005a30:	f4040593          	addi	a1,s0,-192
    80005a34:	4501                	li	a0,0
    80005a36:	ffffd097          	auipc	ra,0xffffd
    80005a3a:	1e2080e7          	jalr	482(ra) # 80002c18 <argstr>
    80005a3e:	87aa                	mv	a5,a0
    return -1;
    80005a40:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80005a42:	0c07c363          	bltz	a5,80005b08 <sys_exec+0xfc>
  }
  memset(argv, 0, sizeof(argv));
    80005a46:	10000613          	li	a2,256
    80005a4a:	4581                	li	a1,0
    80005a4c:	e4040513          	addi	a0,s0,-448
    80005a50:	ffffb097          	auipc	ra,0xffffb
    80005a54:	280080e7          	jalr	640(ra) # 80000cd0 <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    80005a58:	e4040493          	addi	s1,s0,-448
  memset(argv, 0, sizeof(argv));
    80005a5c:	89a6                	mv	s3,s1
    80005a5e:	4901                	li	s2,0
    if(i >= NELEM(argv)){
    80005a60:	02000a13          	li	s4,32
    80005a64:	00090a9b          	sext.w	s5,s2
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80005a68:	00391513          	slli	a0,s2,0x3
    80005a6c:	e3040593          	addi	a1,s0,-464
    80005a70:	e3843783          	ld	a5,-456(s0)
    80005a74:	953e                	add	a0,a0,a5
    80005a76:	ffffd097          	auipc	ra,0xffffd
    80005a7a:	0c4080e7          	jalr	196(ra) # 80002b3a <fetchaddr>
    80005a7e:	02054a63          	bltz	a0,80005ab2 <sys_exec+0xa6>
      goto bad;
    }
    if(uarg == 0){
    80005a82:	e3043783          	ld	a5,-464(s0)
    80005a86:	c3b9                	beqz	a5,80005acc <sys_exec+0xc0>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    80005a88:	ffffb097          	auipc	ra,0xffffb
    80005a8c:	05c080e7          	jalr	92(ra) # 80000ae4 <kalloc>
    80005a90:	85aa                	mv	a1,a0
    80005a92:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    80005a96:	cd11                	beqz	a0,80005ab2 <sys_exec+0xa6>
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80005a98:	6605                	lui	a2,0x1
    80005a9a:	e3043503          	ld	a0,-464(s0)
    80005a9e:	ffffd097          	auipc	ra,0xffffd
    80005aa2:	0ee080e7          	jalr	238(ra) # 80002b8c <fetchstr>
    80005aa6:	00054663          	bltz	a0,80005ab2 <sys_exec+0xa6>
    if(i >= NELEM(argv)){
    80005aaa:	0905                	addi	s2,s2,1
    80005aac:	09a1                	addi	s3,s3,8
    80005aae:	fb491be3          	bne	s2,s4,80005a64 <sys_exec+0x58>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005ab2:	f4040913          	addi	s2,s0,-192
    80005ab6:	6088                	ld	a0,0(s1)
    80005ab8:	c539                	beqz	a0,80005b06 <sys_exec+0xfa>
    kfree(argv[i]);
    80005aba:	ffffb097          	auipc	ra,0xffffb
    80005abe:	f2c080e7          	jalr	-212(ra) # 800009e6 <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005ac2:	04a1                	addi	s1,s1,8
    80005ac4:	ff2499e3          	bne	s1,s2,80005ab6 <sys_exec+0xaa>
  return -1;
    80005ac8:	557d                	li	a0,-1
    80005aca:	a83d                	j	80005b08 <sys_exec+0xfc>
      argv[i] = 0;
    80005acc:	0a8e                	slli	s5,s5,0x3
    80005ace:	fc0a8793          	addi	a5,s5,-64
    80005ad2:	00878ab3          	add	s5,a5,s0
    80005ad6:	e80ab023          	sd	zero,-384(s5)
  int ret = exec(path, argv);
    80005ada:	e4040593          	addi	a1,s0,-448
    80005ade:	f4040513          	addi	a0,s0,-192
    80005ae2:	fffff097          	auipc	ra,0xfffff
    80005ae6:	16e080e7          	jalr	366(ra) # 80004c50 <exec>
    80005aea:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005aec:	f4040993          	addi	s3,s0,-192
    80005af0:	6088                	ld	a0,0(s1)
    80005af2:	c901                	beqz	a0,80005b02 <sys_exec+0xf6>
    kfree(argv[i]);
    80005af4:	ffffb097          	auipc	ra,0xffffb
    80005af8:	ef2080e7          	jalr	-270(ra) # 800009e6 <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005afc:	04a1                	addi	s1,s1,8
    80005afe:	ff3499e3          	bne	s1,s3,80005af0 <sys_exec+0xe4>
  return ret;
    80005b02:	854a                	mv	a0,s2
    80005b04:	a011                	j	80005b08 <sys_exec+0xfc>
  return -1;
    80005b06:	557d                	li	a0,-1
}
    80005b08:	60be                	ld	ra,456(sp)
    80005b0a:	641e                	ld	s0,448(sp)
    80005b0c:	74fa                	ld	s1,440(sp)
    80005b0e:	795a                	ld	s2,432(sp)
    80005b10:	79ba                	ld	s3,424(sp)
    80005b12:	7a1a                	ld	s4,416(sp)
    80005b14:	6afa                	ld	s5,408(sp)
    80005b16:	6179                	addi	sp,sp,464
    80005b18:	8082                	ret

0000000080005b1a <sys_pipe>:

uint64
sys_pipe(void)
{
    80005b1a:	7139                	addi	sp,sp,-64
    80005b1c:	fc06                	sd	ra,56(sp)
    80005b1e:	f822                	sd	s0,48(sp)
    80005b20:	f426                	sd	s1,40(sp)
    80005b22:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80005b24:	ffffc097          	auipc	ra,0xffffc
    80005b28:	e86080e7          	jalr	-378(ra) # 800019aa <myproc>
    80005b2c:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80005b2e:	fd840593          	addi	a1,s0,-40
    80005b32:	4501                	li	a0,0
    80005b34:	ffffd097          	auipc	ra,0xffffd
    80005b38:	0c4080e7          	jalr	196(ra) # 80002bf8 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    80005b3c:	fc840593          	addi	a1,s0,-56
    80005b40:	fd040513          	addi	a0,s0,-48
    80005b44:	fffff097          	auipc	ra,0xfffff
    80005b48:	dc2080e7          	jalr	-574(ra) # 80004906 <pipealloc>
    return -1;
    80005b4c:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    80005b4e:	0c054463          	bltz	a0,80005c16 <sys_pipe+0xfc>
  fd0 = -1;
    80005b52:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    80005b56:	fd043503          	ld	a0,-48(s0)
    80005b5a:	fffff097          	auipc	ra,0xfffff
    80005b5e:	514080e7          	jalr	1300(ra) # 8000506e <fdalloc>
    80005b62:	fca42223          	sw	a0,-60(s0)
    80005b66:	08054b63          	bltz	a0,80005bfc <sys_pipe+0xe2>
    80005b6a:	fc843503          	ld	a0,-56(s0)
    80005b6e:	fffff097          	auipc	ra,0xfffff
    80005b72:	500080e7          	jalr	1280(ra) # 8000506e <fdalloc>
    80005b76:	fca42023          	sw	a0,-64(s0)
    80005b7a:	06054863          	bltz	a0,80005bea <sys_pipe+0xd0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80005b7e:	4691                	li	a3,4
    80005b80:	fc440613          	addi	a2,s0,-60
    80005b84:	fd843583          	ld	a1,-40(s0)
    80005b88:	68a8                	ld	a0,80(s1)
    80005b8a:	ffffc097          	auipc	ra,0xffffc
    80005b8e:	ae0080e7          	jalr	-1312(ra) # 8000166a <copyout>
    80005b92:	02054063          	bltz	a0,80005bb2 <sys_pipe+0x98>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    80005b96:	4691                	li	a3,4
    80005b98:	fc040613          	addi	a2,s0,-64
    80005b9c:	fd843583          	ld	a1,-40(s0)
    80005ba0:	0591                	addi	a1,a1,4
    80005ba2:	68a8                	ld	a0,80(s1)
    80005ba4:	ffffc097          	auipc	ra,0xffffc
    80005ba8:	ac6080e7          	jalr	-1338(ra) # 8000166a <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    80005bac:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80005bae:	06055463          	bgez	a0,80005c16 <sys_pipe+0xfc>
    p->ofile[fd0] = 0;
    80005bb2:	fc442783          	lw	a5,-60(s0)
    80005bb6:	07e9                	addi	a5,a5,26
    80005bb8:	078e                	slli	a5,a5,0x3
    80005bba:	97a6                	add	a5,a5,s1
    80005bbc:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    80005bc0:	fc042783          	lw	a5,-64(s0)
    80005bc4:	07e9                	addi	a5,a5,26
    80005bc6:	078e                	slli	a5,a5,0x3
    80005bc8:	94be                	add	s1,s1,a5
    80005bca:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    80005bce:	fd043503          	ld	a0,-48(s0)
    80005bd2:	fffff097          	auipc	ra,0xfffff
    80005bd6:	a04080e7          	jalr	-1532(ra) # 800045d6 <fileclose>
    fileclose(wf);
    80005bda:	fc843503          	ld	a0,-56(s0)
    80005bde:	fffff097          	auipc	ra,0xfffff
    80005be2:	9f8080e7          	jalr	-1544(ra) # 800045d6 <fileclose>
    return -1;
    80005be6:	57fd                	li	a5,-1
    80005be8:	a03d                	j	80005c16 <sys_pipe+0xfc>
    if(fd0 >= 0)
    80005bea:	fc442783          	lw	a5,-60(s0)
    80005bee:	0007c763          	bltz	a5,80005bfc <sys_pipe+0xe2>
      p->ofile[fd0] = 0;
    80005bf2:	07e9                	addi	a5,a5,26
    80005bf4:	078e                	slli	a5,a5,0x3
    80005bf6:	97a6                	add	a5,a5,s1
    80005bf8:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80005bfc:	fd043503          	ld	a0,-48(s0)
    80005c00:	fffff097          	auipc	ra,0xfffff
    80005c04:	9d6080e7          	jalr	-1578(ra) # 800045d6 <fileclose>
    fileclose(wf);
    80005c08:	fc843503          	ld	a0,-56(s0)
    80005c0c:	fffff097          	auipc	ra,0xfffff
    80005c10:	9ca080e7          	jalr	-1590(ra) # 800045d6 <fileclose>
    return -1;
    80005c14:	57fd                	li	a5,-1
}
    80005c16:	853e                	mv	a0,a5
    80005c18:	70e2                	ld	ra,56(sp)
    80005c1a:	7442                	ld	s0,48(sp)
    80005c1c:	74a2                	ld	s1,40(sp)
    80005c1e:	6121                	addi	sp,sp,64
    80005c20:	8082                	ret
	...

0000000080005c30 <kernelvec>:
    80005c30:	7111                	addi	sp,sp,-256
    80005c32:	e006                	sd	ra,0(sp)
    80005c34:	e40a                	sd	sp,8(sp)
    80005c36:	e80e                	sd	gp,16(sp)
    80005c38:	ec12                	sd	tp,24(sp)
    80005c3a:	f016                	sd	t0,32(sp)
    80005c3c:	f41a                	sd	t1,40(sp)
    80005c3e:	f81e                	sd	t2,48(sp)
    80005c40:	fc22                	sd	s0,56(sp)
    80005c42:	e0a6                	sd	s1,64(sp)
    80005c44:	e4aa                	sd	a0,72(sp)
    80005c46:	e8ae                	sd	a1,80(sp)
    80005c48:	ecb2                	sd	a2,88(sp)
    80005c4a:	f0b6                	sd	a3,96(sp)
    80005c4c:	f4ba                	sd	a4,104(sp)
    80005c4e:	f8be                	sd	a5,112(sp)
    80005c50:	fcc2                	sd	a6,120(sp)
    80005c52:	e146                	sd	a7,128(sp)
    80005c54:	e54a                	sd	s2,136(sp)
    80005c56:	e94e                	sd	s3,144(sp)
    80005c58:	ed52                	sd	s4,152(sp)
    80005c5a:	f156                	sd	s5,160(sp)
    80005c5c:	f55a                	sd	s6,168(sp)
    80005c5e:	f95e                	sd	s7,176(sp)
    80005c60:	fd62                	sd	s8,184(sp)
    80005c62:	e1e6                	sd	s9,192(sp)
    80005c64:	e5ea                	sd	s10,200(sp)
    80005c66:	e9ee                	sd	s11,208(sp)
    80005c68:	edf2                	sd	t3,216(sp)
    80005c6a:	f1f6                	sd	t4,224(sp)
    80005c6c:	f5fa                	sd	t5,232(sp)
    80005c6e:	f9fe                	sd	t6,240(sp)
    80005c70:	d97fc0ef          	jal	ra,80002a06 <kerneltrap>
    80005c74:	6082                	ld	ra,0(sp)
    80005c76:	6122                	ld	sp,8(sp)
    80005c78:	61c2                	ld	gp,16(sp)
    80005c7a:	7282                	ld	t0,32(sp)
    80005c7c:	7322                	ld	t1,40(sp)
    80005c7e:	73c2                	ld	t2,48(sp)
    80005c80:	7462                	ld	s0,56(sp)
    80005c82:	6486                	ld	s1,64(sp)
    80005c84:	6526                	ld	a0,72(sp)
    80005c86:	65c6                	ld	a1,80(sp)
    80005c88:	6666                	ld	a2,88(sp)
    80005c8a:	7686                	ld	a3,96(sp)
    80005c8c:	7726                	ld	a4,104(sp)
    80005c8e:	77c6                	ld	a5,112(sp)
    80005c90:	7866                	ld	a6,120(sp)
    80005c92:	688a                	ld	a7,128(sp)
    80005c94:	692a                	ld	s2,136(sp)
    80005c96:	69ca                	ld	s3,144(sp)
    80005c98:	6a6a                	ld	s4,152(sp)
    80005c9a:	7a8a                	ld	s5,160(sp)
    80005c9c:	7b2a                	ld	s6,168(sp)
    80005c9e:	7bca                	ld	s7,176(sp)
    80005ca0:	7c6a                	ld	s8,184(sp)
    80005ca2:	6c8e                	ld	s9,192(sp)
    80005ca4:	6d2e                	ld	s10,200(sp)
    80005ca6:	6dce                	ld	s11,208(sp)
    80005ca8:	6e6e                	ld	t3,216(sp)
    80005caa:	7e8e                	ld	t4,224(sp)
    80005cac:	7f2e                	ld	t5,232(sp)
    80005cae:	7fce                	ld	t6,240(sp)
    80005cb0:	6111                	addi	sp,sp,256
    80005cb2:	10200073          	sret
    80005cb6:	00000013          	nop
    80005cba:	00000013          	nop
    80005cbe:	0001                	nop

0000000080005cc0 <timervec>:
    80005cc0:	34051573          	csrrw	a0,mscratch,a0
    80005cc4:	e10c                	sd	a1,0(a0)
    80005cc6:	e510                	sd	a2,8(a0)
    80005cc8:	e914                	sd	a3,16(a0)
    80005cca:	6d0c                	ld	a1,24(a0)
    80005ccc:	7110                	ld	a2,32(a0)
    80005cce:	6194                	ld	a3,0(a1)
    80005cd0:	96b2                	add	a3,a3,a2
    80005cd2:	e194                	sd	a3,0(a1)
    80005cd4:	4589                	li	a1,2
    80005cd6:	14459073          	csrw	sip,a1
    80005cda:	6914                	ld	a3,16(a0)
    80005cdc:	6510                	ld	a2,8(a0)
    80005cde:	610c                	ld	a1,0(a0)
    80005ce0:	34051573          	csrrw	a0,mscratch,a0
    80005ce4:	30200073          	mret
	...

0000000080005cea <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    80005cea:	1141                	addi	sp,sp,-16
    80005cec:	e422                	sd	s0,8(sp)
    80005cee:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80005cf0:	0c0007b7          	lui	a5,0xc000
    80005cf4:	4705                	li	a4,1
    80005cf6:	d798                	sw	a4,40(a5)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    80005cf8:	c3d8                	sw	a4,4(a5)
}
    80005cfa:	6422                	ld	s0,8(sp)
    80005cfc:	0141                	addi	sp,sp,16
    80005cfe:	8082                	ret

0000000080005d00 <plicinithart>:

void
plicinithart(void)
{
    80005d00:	1141                	addi	sp,sp,-16
    80005d02:	e406                	sd	ra,8(sp)
    80005d04:	e022                	sd	s0,0(sp)
    80005d06:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005d08:	ffffc097          	auipc	ra,0xffffc
    80005d0c:	c76080e7          	jalr	-906(ra) # 8000197e <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80005d10:	0085171b          	slliw	a4,a0,0x8
    80005d14:	0c0027b7          	lui	a5,0xc002
    80005d18:	97ba                	add	a5,a5,a4
    80005d1a:	40200713          	li	a4,1026
    80005d1e:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80005d22:	00d5151b          	slliw	a0,a0,0xd
    80005d26:	0c2017b7          	lui	a5,0xc201
    80005d2a:	97aa                	add	a5,a5,a0
    80005d2c:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    80005d30:	60a2                	ld	ra,8(sp)
    80005d32:	6402                	ld	s0,0(sp)
    80005d34:	0141                	addi	sp,sp,16
    80005d36:	8082                	ret

0000000080005d38 <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    80005d38:	1141                	addi	sp,sp,-16
    80005d3a:	e406                	sd	ra,8(sp)
    80005d3c:	e022                	sd	s0,0(sp)
    80005d3e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005d40:	ffffc097          	auipc	ra,0xffffc
    80005d44:	c3e080e7          	jalr	-962(ra) # 8000197e <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    80005d48:	00d5151b          	slliw	a0,a0,0xd
    80005d4c:	0c2017b7          	lui	a5,0xc201
    80005d50:	97aa                	add	a5,a5,a0
  return irq;
}
    80005d52:	43c8                	lw	a0,4(a5)
    80005d54:	60a2                	ld	ra,8(sp)
    80005d56:	6402                	ld	s0,0(sp)
    80005d58:	0141                	addi	sp,sp,16
    80005d5a:	8082                	ret

0000000080005d5c <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    80005d5c:	1101                	addi	sp,sp,-32
    80005d5e:	ec06                	sd	ra,24(sp)
    80005d60:	e822                	sd	s0,16(sp)
    80005d62:	e426                	sd	s1,8(sp)
    80005d64:	1000                	addi	s0,sp,32
    80005d66:	84aa                	mv	s1,a0
  int hart = cpuid();
    80005d68:	ffffc097          	auipc	ra,0xffffc
    80005d6c:	c16080e7          	jalr	-1002(ra) # 8000197e <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    80005d70:	00d5151b          	slliw	a0,a0,0xd
    80005d74:	0c2017b7          	lui	a5,0xc201
    80005d78:	97aa                	add	a5,a5,a0
    80005d7a:	c3c4                	sw	s1,4(a5)
}
    80005d7c:	60e2                	ld	ra,24(sp)
    80005d7e:	6442                	ld	s0,16(sp)
    80005d80:	64a2                	ld	s1,8(sp)
    80005d82:	6105                	addi	sp,sp,32
    80005d84:	8082                	ret

0000000080005d86 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005d86:	1141                	addi	sp,sp,-16
    80005d88:	e406                	sd	ra,8(sp)
    80005d8a:	e022                	sd	s0,0(sp)
    80005d8c:	0800                	addi	s0,sp,16
  if(i >= NUM)
    80005d8e:	479d                	li	a5,7
    80005d90:	04a7cc63          	blt	a5,a0,80005de8 <free_desc+0x62>
    panic("free_desc 1");
  if(disk.free[i])
    80005d94:	0001c797          	auipc	a5,0x1c
    80005d98:	28c78793          	addi	a5,a5,652 # 80022020 <disk>
    80005d9c:	97aa                	add	a5,a5,a0
    80005d9e:	0187c783          	lbu	a5,24(a5)
    80005da2:	ebb9                	bnez	a5,80005df8 <free_desc+0x72>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005da4:	00451693          	slli	a3,a0,0x4
    80005da8:	0001c797          	auipc	a5,0x1c
    80005dac:	27878793          	addi	a5,a5,632 # 80022020 <disk>
    80005db0:	6398                	ld	a4,0(a5)
    80005db2:	9736                	add	a4,a4,a3
    80005db4:	00073023          	sd	zero,0(a4)
  disk.desc[i].len = 0;
    80005db8:	6398                	ld	a4,0(a5)
    80005dba:	9736                	add	a4,a4,a3
    80005dbc:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    80005dc0:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005dc4:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80005dc8:	97aa                	add	a5,a5,a0
    80005dca:	4705                	li	a4,1
    80005dcc:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    80005dd0:	0001c517          	auipc	a0,0x1c
    80005dd4:	26850513          	addi	a0,a0,616 # 80022038 <disk+0x18>
    80005dd8:	ffffc097          	auipc	ra,0xffffc
    80005ddc:	3f4080e7          	jalr	1012(ra) # 800021cc <wakeup>
}
    80005de0:	60a2                	ld	ra,8(sp)
    80005de2:	6402                	ld	s0,0(sp)
    80005de4:	0141                	addi	sp,sp,16
    80005de6:	8082                	ret
    panic("free_desc 1");
    80005de8:	00003517          	auipc	a0,0x3
    80005dec:	95850513          	addi	a0,a0,-1704 # 80008740 <syscalls+0x2f0>
    80005df0:	ffffa097          	auipc	ra,0xffffa
    80005df4:	74e080e7          	jalr	1870(ra) # 8000053e <panic>
    panic("free_desc 2");
    80005df8:	00003517          	auipc	a0,0x3
    80005dfc:	95850513          	addi	a0,a0,-1704 # 80008750 <syscalls+0x300>
    80005e00:	ffffa097          	auipc	ra,0xffffa
    80005e04:	73e080e7          	jalr	1854(ra) # 8000053e <panic>

0000000080005e08 <virtio_disk_init>:
{
    80005e08:	1101                	addi	sp,sp,-32
    80005e0a:	ec06                	sd	ra,24(sp)
    80005e0c:	e822                	sd	s0,16(sp)
    80005e0e:	e426                	sd	s1,8(sp)
    80005e10:	e04a                	sd	s2,0(sp)
    80005e12:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80005e14:	00003597          	auipc	a1,0x3
    80005e18:	94c58593          	addi	a1,a1,-1716 # 80008760 <syscalls+0x310>
    80005e1c:	0001c517          	auipc	a0,0x1c
    80005e20:	32c50513          	addi	a0,a0,812 # 80022148 <disk+0x128>
    80005e24:	ffffb097          	auipc	ra,0xffffb
    80005e28:	d20080e7          	jalr	-736(ra) # 80000b44 <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005e2c:	100017b7          	lui	a5,0x10001
    80005e30:	4398                	lw	a4,0(a5)
    80005e32:	2701                	sext.w	a4,a4
    80005e34:	747277b7          	lui	a5,0x74727
    80005e38:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005e3c:	14f71b63          	bne	a4,a5,80005f92 <virtio_disk_init+0x18a>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80005e40:	100017b7          	lui	a5,0x10001
    80005e44:	43dc                	lw	a5,4(a5)
    80005e46:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005e48:	4709                	li	a4,2
    80005e4a:	14e79463          	bne	a5,a4,80005f92 <virtio_disk_init+0x18a>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005e4e:	100017b7          	lui	a5,0x10001
    80005e52:	479c                	lw	a5,8(a5)
    80005e54:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80005e56:	12e79e63          	bne	a5,a4,80005f92 <virtio_disk_init+0x18a>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    80005e5a:	100017b7          	lui	a5,0x10001
    80005e5e:	47d8                	lw	a4,12(a5)
    80005e60:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005e62:	554d47b7          	lui	a5,0x554d4
    80005e66:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80005e6a:	12f71463          	bne	a4,a5,80005f92 <virtio_disk_init+0x18a>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005e6e:	100017b7          	lui	a5,0x10001
    80005e72:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005e76:	4705                	li	a4,1
    80005e78:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005e7a:	470d                	li	a4,3
    80005e7c:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80005e7e:	4b98                	lw	a4,16(a5)
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80005e80:	c7ffe6b7          	lui	a3,0xc7ffe
    80005e84:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <end+0xffffffff47fdc5ff>
    80005e88:	8f75                	and	a4,a4,a3
    80005e8a:	d398                	sw	a4,32(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005e8c:	472d                	li	a4,11
    80005e8e:	dbb8                	sw	a4,112(a5)
  status = *R(VIRTIO_MMIO_STATUS);
    80005e90:	5bbc                	lw	a5,112(a5)
    80005e92:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80005e96:	8ba1                	andi	a5,a5,8
    80005e98:	10078563          	beqz	a5,80005fa2 <virtio_disk_init+0x19a>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005e9c:	100017b7          	lui	a5,0x10001
    80005ea0:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    80005ea4:	43fc                	lw	a5,68(a5)
    80005ea6:	2781                	sext.w	a5,a5
    80005ea8:	10079563          	bnez	a5,80005fb2 <virtio_disk_init+0x1aa>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005eac:	100017b7          	lui	a5,0x10001
    80005eb0:	5bdc                	lw	a5,52(a5)
    80005eb2:	2781                	sext.w	a5,a5
  if(max == 0)
    80005eb4:	10078763          	beqz	a5,80005fc2 <virtio_disk_init+0x1ba>
  if(max < NUM)
    80005eb8:	471d                	li	a4,7
    80005eba:	10f77c63          	bgeu	a4,a5,80005fd2 <virtio_disk_init+0x1ca>
  disk.desc = kalloc();
    80005ebe:	ffffb097          	auipc	ra,0xffffb
    80005ec2:	c26080e7          	jalr	-986(ra) # 80000ae4 <kalloc>
    80005ec6:	0001c497          	auipc	s1,0x1c
    80005eca:	15a48493          	addi	s1,s1,346 # 80022020 <disk>
    80005ece:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80005ed0:	ffffb097          	auipc	ra,0xffffb
    80005ed4:	c14080e7          	jalr	-1004(ra) # 80000ae4 <kalloc>
    80005ed8:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    80005eda:	ffffb097          	auipc	ra,0xffffb
    80005ede:	c0a080e7          	jalr	-1014(ra) # 80000ae4 <kalloc>
    80005ee2:	87aa                	mv	a5,a0
    80005ee4:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80005ee6:	6088                	ld	a0,0(s1)
    80005ee8:	cd6d                	beqz	a0,80005fe2 <virtio_disk_init+0x1da>
    80005eea:	0001c717          	auipc	a4,0x1c
    80005eee:	13e73703          	ld	a4,318(a4) # 80022028 <disk+0x8>
    80005ef2:	cb65                	beqz	a4,80005fe2 <virtio_disk_init+0x1da>
    80005ef4:	c7fd                	beqz	a5,80005fe2 <virtio_disk_init+0x1da>
  memset(disk.desc, 0, PGSIZE);
    80005ef6:	6605                	lui	a2,0x1
    80005ef8:	4581                	li	a1,0
    80005efa:	ffffb097          	auipc	ra,0xffffb
    80005efe:	dd6080e7          	jalr	-554(ra) # 80000cd0 <memset>
  memset(disk.avail, 0, PGSIZE);
    80005f02:	0001c497          	auipc	s1,0x1c
    80005f06:	11e48493          	addi	s1,s1,286 # 80022020 <disk>
    80005f0a:	6605                	lui	a2,0x1
    80005f0c:	4581                	li	a1,0
    80005f0e:	6488                	ld	a0,8(s1)
    80005f10:	ffffb097          	auipc	ra,0xffffb
    80005f14:	dc0080e7          	jalr	-576(ra) # 80000cd0 <memset>
  memset(disk.used, 0, PGSIZE);
    80005f18:	6605                	lui	a2,0x1
    80005f1a:	4581                	li	a1,0
    80005f1c:	6888                	ld	a0,16(s1)
    80005f1e:	ffffb097          	auipc	ra,0xffffb
    80005f22:	db2080e7          	jalr	-590(ra) # 80000cd0 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80005f26:	100017b7          	lui	a5,0x10001
    80005f2a:	4721                	li	a4,8
    80005f2c:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80005f2e:	4098                	lw	a4,0(s1)
    80005f30:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80005f34:	40d8                	lw	a4,4(s1)
    80005f36:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80005f3a:	6498                	ld	a4,8(s1)
    80005f3c:	0007069b          	sext.w	a3,a4
    80005f40:	08d7a823          	sw	a3,144(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80005f44:	9701                	srai	a4,a4,0x20
    80005f46:	08e7aa23          	sw	a4,148(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80005f4a:	6898                	ld	a4,16(s1)
    80005f4c:	0007069b          	sext.w	a3,a4
    80005f50:	0ad7a023          	sw	a3,160(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80005f54:	9701                	srai	a4,a4,0x20
    80005f56:	0ae7a223          	sw	a4,164(a5)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80005f5a:	4705                	li	a4,1
    80005f5c:	c3f8                	sw	a4,68(a5)
    disk.free[i] = 1;
    80005f5e:	00e48c23          	sb	a4,24(s1)
    80005f62:	00e48ca3          	sb	a4,25(s1)
    80005f66:	00e48d23          	sb	a4,26(s1)
    80005f6a:	00e48da3          	sb	a4,27(s1)
    80005f6e:	00e48e23          	sb	a4,28(s1)
    80005f72:	00e48ea3          	sb	a4,29(s1)
    80005f76:	00e48f23          	sb	a4,30(s1)
    80005f7a:	00e48fa3          	sb	a4,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005f7e:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005f82:	0727a823          	sw	s2,112(a5)
}
    80005f86:	60e2                	ld	ra,24(sp)
    80005f88:	6442                	ld	s0,16(sp)
    80005f8a:	64a2                	ld	s1,8(sp)
    80005f8c:	6902                	ld	s2,0(sp)
    80005f8e:	6105                	addi	sp,sp,32
    80005f90:	8082                	ret
    panic("could not find virtio disk");
    80005f92:	00002517          	auipc	a0,0x2
    80005f96:	7de50513          	addi	a0,a0,2014 # 80008770 <syscalls+0x320>
    80005f9a:	ffffa097          	auipc	ra,0xffffa
    80005f9e:	5a4080e7          	jalr	1444(ra) # 8000053e <panic>
    panic("virtio disk FEATURES_OK unset");
    80005fa2:	00002517          	auipc	a0,0x2
    80005fa6:	7ee50513          	addi	a0,a0,2030 # 80008790 <syscalls+0x340>
    80005faa:	ffffa097          	auipc	ra,0xffffa
    80005fae:	594080e7          	jalr	1428(ra) # 8000053e <panic>
    panic("virtio disk should not be ready");
    80005fb2:	00002517          	auipc	a0,0x2
    80005fb6:	7fe50513          	addi	a0,a0,2046 # 800087b0 <syscalls+0x360>
    80005fba:	ffffa097          	auipc	ra,0xffffa
    80005fbe:	584080e7          	jalr	1412(ra) # 8000053e <panic>
    panic("virtio disk has no queue 0");
    80005fc2:	00003517          	auipc	a0,0x3
    80005fc6:	80e50513          	addi	a0,a0,-2034 # 800087d0 <syscalls+0x380>
    80005fca:	ffffa097          	auipc	ra,0xffffa
    80005fce:	574080e7          	jalr	1396(ra) # 8000053e <panic>
    panic("virtio disk max queue too short");
    80005fd2:	00003517          	auipc	a0,0x3
    80005fd6:	81e50513          	addi	a0,a0,-2018 # 800087f0 <syscalls+0x3a0>
    80005fda:	ffffa097          	auipc	ra,0xffffa
    80005fde:	564080e7          	jalr	1380(ra) # 8000053e <panic>
    panic("virtio disk kalloc");
    80005fe2:	00003517          	auipc	a0,0x3
    80005fe6:	82e50513          	addi	a0,a0,-2002 # 80008810 <syscalls+0x3c0>
    80005fea:	ffffa097          	auipc	ra,0xffffa
    80005fee:	554080e7          	jalr	1364(ra) # 8000053e <panic>

0000000080005ff2 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80005ff2:	7119                	addi	sp,sp,-128
    80005ff4:	fc86                	sd	ra,120(sp)
    80005ff6:	f8a2                	sd	s0,112(sp)
    80005ff8:	f4a6                	sd	s1,104(sp)
    80005ffa:	f0ca                	sd	s2,96(sp)
    80005ffc:	ecce                	sd	s3,88(sp)
    80005ffe:	e8d2                	sd	s4,80(sp)
    80006000:	e4d6                	sd	s5,72(sp)
    80006002:	e0da                	sd	s6,64(sp)
    80006004:	fc5e                	sd	s7,56(sp)
    80006006:	f862                	sd	s8,48(sp)
    80006008:	f466                	sd	s9,40(sp)
    8000600a:	f06a                	sd	s10,32(sp)
    8000600c:	ec6e                	sd	s11,24(sp)
    8000600e:	0100                	addi	s0,sp,128
    80006010:	8aaa                	mv	s5,a0
    80006012:	8c2e                	mv	s8,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80006014:	00c52d03          	lw	s10,12(a0)
    80006018:	001d1d1b          	slliw	s10,s10,0x1
    8000601c:	1d02                	slli	s10,s10,0x20
    8000601e:	020d5d13          	srli	s10,s10,0x20

  acquire(&disk.vdisk_lock);
    80006022:	0001c517          	auipc	a0,0x1c
    80006026:	12650513          	addi	a0,a0,294 # 80022148 <disk+0x128>
    8000602a:	ffffb097          	auipc	ra,0xffffb
    8000602e:	baa080e7          	jalr	-1110(ra) # 80000bd4 <acquire>
  for(int i = 0; i < 3; i++){
    80006032:	4981                	li	s3,0
  for(int i = 0; i < NUM; i++){
    80006034:	44a1                	li	s1,8
      disk.free[i] = 0;
    80006036:	0001cb97          	auipc	s7,0x1c
    8000603a:	feab8b93          	addi	s7,s7,-22 # 80022020 <disk>
  for(int i = 0; i < 3; i++){
    8000603e:	4b0d                	li	s6,3
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80006040:	0001cc97          	auipc	s9,0x1c
    80006044:	108c8c93          	addi	s9,s9,264 # 80022148 <disk+0x128>
    80006048:	a08d                	j	800060aa <virtio_disk_rw+0xb8>
      disk.free[i] = 0;
    8000604a:	00fb8733          	add	a4,s7,a5
    8000604e:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    80006052:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80006054:	0207c563          	bltz	a5,8000607e <virtio_disk_rw+0x8c>
  for(int i = 0; i < 3; i++){
    80006058:	2905                	addiw	s2,s2,1
    8000605a:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    8000605c:	05690c63          	beq	s2,s6,800060b4 <virtio_disk_rw+0xc2>
    idx[i] = alloc_desc();
    80006060:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80006062:	0001c717          	auipc	a4,0x1c
    80006066:	fbe70713          	addi	a4,a4,-66 # 80022020 <disk>
    8000606a:	87ce                	mv	a5,s3
    if(disk.free[i]){
    8000606c:	01874683          	lbu	a3,24(a4)
    80006070:	fee9                	bnez	a3,8000604a <virtio_disk_rw+0x58>
  for(int i = 0; i < NUM; i++){
    80006072:	2785                	addiw	a5,a5,1
    80006074:	0705                	addi	a4,a4,1
    80006076:	fe979be3          	bne	a5,s1,8000606c <virtio_disk_rw+0x7a>
    idx[i] = alloc_desc();
    8000607a:	57fd                	li	a5,-1
    8000607c:	c19c                	sw	a5,0(a1)
      for(int j = 0; j < i; j++)
    8000607e:	01205d63          	blez	s2,80006098 <virtio_disk_rw+0xa6>
    80006082:	8dce                	mv	s11,s3
        free_desc(idx[j]);
    80006084:	000a2503          	lw	a0,0(s4)
    80006088:	00000097          	auipc	ra,0x0
    8000608c:	cfe080e7          	jalr	-770(ra) # 80005d86 <free_desc>
      for(int j = 0; j < i; j++)
    80006090:	2d85                	addiw	s11,s11,1
    80006092:	0a11                	addi	s4,s4,4
    80006094:	ff2d98e3          	bne	s11,s2,80006084 <virtio_disk_rw+0x92>
    sleep(&disk.free[0], &disk.vdisk_lock);
    80006098:	85e6                	mv	a1,s9
    8000609a:	0001c517          	auipc	a0,0x1c
    8000609e:	f9e50513          	addi	a0,a0,-98 # 80022038 <disk+0x18>
    800060a2:	ffffc097          	auipc	ra,0xffffc
    800060a6:	0b4080e7          	jalr	180(ra) # 80002156 <sleep>
  for(int i = 0; i < 3; i++){
    800060aa:	f8040a13          	addi	s4,s0,-128
{
    800060ae:	8652                	mv	a2,s4
  for(int i = 0; i < 3; i++){
    800060b0:	894e                	mv	s2,s3
    800060b2:	b77d                	j	80006060 <virtio_disk_rw+0x6e>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    800060b4:	f8042503          	lw	a0,-128(s0)
    800060b8:	00a50713          	addi	a4,a0,10
    800060bc:	0712                	slli	a4,a4,0x4

  if(write)
    800060be:	0001c797          	auipc	a5,0x1c
    800060c2:	f6278793          	addi	a5,a5,-158 # 80022020 <disk>
    800060c6:	00e786b3          	add	a3,a5,a4
    800060ca:	01803633          	snez	a2,s8
    800060ce:	c690                	sw	a2,8(a3)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    800060d0:	0006a623          	sw	zero,12(a3)
  buf0->sector = sector;
    800060d4:	01a6b823          	sd	s10,16(a3)

  disk.desc[idx[0]].addr = (uint64) buf0;
    800060d8:	f6070613          	addi	a2,a4,-160
    800060dc:	6394                	ld	a3,0(a5)
    800060de:	96b2                	add	a3,a3,a2
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    800060e0:	00870593          	addi	a1,a4,8
    800060e4:	95be                	add	a1,a1,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    800060e6:	e28c                	sd	a1,0(a3)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    800060e8:	0007b803          	ld	a6,0(a5)
    800060ec:	9642                	add	a2,a2,a6
    800060ee:	46c1                	li	a3,16
    800060f0:	c614                	sw	a3,8(a2)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    800060f2:	4585                	li	a1,1
    800060f4:	00b61623          	sh	a1,12(a2)
  disk.desc[idx[0]].next = idx[1];
    800060f8:	f8442683          	lw	a3,-124(s0)
    800060fc:	00d61723          	sh	a3,14(a2)

  disk.desc[idx[1]].addr = (uint64) b->data;
    80006100:	0692                	slli	a3,a3,0x4
    80006102:	9836                	add	a6,a6,a3
    80006104:	058a8613          	addi	a2,s5,88
    80006108:	00c83023          	sd	a2,0(a6)
  disk.desc[idx[1]].len = BSIZE;
    8000610c:	0007b803          	ld	a6,0(a5)
    80006110:	96c2                	add	a3,a3,a6
    80006112:	40000613          	li	a2,1024
    80006116:	c690                	sw	a2,8(a3)
  if(write)
    80006118:	001c3613          	seqz	a2,s8
    8000611c:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80006120:	00166613          	ori	a2,a2,1
    80006124:	00c69623          	sh	a2,12(a3)
  disk.desc[idx[1]].next = idx[2];
    80006128:	f8842603          	lw	a2,-120(s0)
    8000612c:	00c69723          	sh	a2,14(a3)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80006130:	00250693          	addi	a3,a0,2
    80006134:	0692                	slli	a3,a3,0x4
    80006136:	96be                	add	a3,a3,a5
    80006138:	58fd                	li	a7,-1
    8000613a:	01168823          	sb	a7,16(a3)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    8000613e:	0612                	slli	a2,a2,0x4
    80006140:	9832                	add	a6,a6,a2
    80006142:	f9070713          	addi	a4,a4,-112
    80006146:	973e                	add	a4,a4,a5
    80006148:	00e83023          	sd	a4,0(a6)
  disk.desc[idx[2]].len = 1;
    8000614c:	6398                	ld	a4,0(a5)
    8000614e:	9732                	add	a4,a4,a2
    80006150:	c70c                	sw	a1,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80006152:	4609                	li	a2,2
    80006154:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[2]].next = 0;
    80006158:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    8000615c:	00baa223          	sw	a1,4(s5)
  disk.info[idx[0]].b = b;
    80006160:	0156b423          	sd	s5,8(a3)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80006164:	6794                	ld	a3,8(a5)
    80006166:	0026d703          	lhu	a4,2(a3)
    8000616a:	8b1d                	andi	a4,a4,7
    8000616c:	0706                	slli	a4,a4,0x1
    8000616e:	96ba                	add	a3,a3,a4
    80006170:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    80006174:	0ff0000f          	fence

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80006178:	6798                	ld	a4,8(a5)
    8000617a:	00275783          	lhu	a5,2(a4)
    8000617e:	2785                	addiw	a5,a5,1
    80006180:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80006184:	0ff0000f          	fence

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80006188:	100017b7          	lui	a5,0x10001
    8000618c:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    80006190:	004aa783          	lw	a5,4(s5)
    sleep(b, &disk.vdisk_lock);
    80006194:	0001c917          	auipc	s2,0x1c
    80006198:	fb490913          	addi	s2,s2,-76 # 80022148 <disk+0x128>
  while(b->disk == 1) {
    8000619c:	4485                	li	s1,1
    8000619e:	00b79c63          	bne	a5,a1,800061b6 <virtio_disk_rw+0x1c4>
    sleep(b, &disk.vdisk_lock);
    800061a2:	85ca                	mv	a1,s2
    800061a4:	8556                	mv	a0,s5
    800061a6:	ffffc097          	auipc	ra,0xffffc
    800061aa:	fb0080e7          	jalr	-80(ra) # 80002156 <sleep>
  while(b->disk == 1) {
    800061ae:	004aa783          	lw	a5,4(s5)
    800061b2:	fe9788e3          	beq	a5,s1,800061a2 <virtio_disk_rw+0x1b0>
  }

  disk.info[idx[0]].b = 0;
    800061b6:	f8042903          	lw	s2,-128(s0)
    800061ba:	00290713          	addi	a4,s2,2
    800061be:	0712                	slli	a4,a4,0x4
    800061c0:	0001c797          	auipc	a5,0x1c
    800061c4:	e6078793          	addi	a5,a5,-416 # 80022020 <disk>
    800061c8:	97ba                	add	a5,a5,a4
    800061ca:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    800061ce:	0001c997          	auipc	s3,0x1c
    800061d2:	e5298993          	addi	s3,s3,-430 # 80022020 <disk>
    800061d6:	00491713          	slli	a4,s2,0x4
    800061da:	0009b783          	ld	a5,0(s3)
    800061de:	97ba                	add	a5,a5,a4
    800061e0:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    800061e4:	854a                	mv	a0,s2
    800061e6:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    800061ea:	00000097          	auipc	ra,0x0
    800061ee:	b9c080e7          	jalr	-1124(ra) # 80005d86 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    800061f2:	8885                	andi	s1,s1,1
    800061f4:	f0ed                	bnez	s1,800061d6 <virtio_disk_rw+0x1e4>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    800061f6:	0001c517          	auipc	a0,0x1c
    800061fa:	f5250513          	addi	a0,a0,-174 # 80022148 <disk+0x128>
    800061fe:	ffffb097          	auipc	ra,0xffffb
    80006202:	a8a080e7          	jalr	-1398(ra) # 80000c88 <release>
}
    80006206:	70e6                	ld	ra,120(sp)
    80006208:	7446                	ld	s0,112(sp)
    8000620a:	74a6                	ld	s1,104(sp)
    8000620c:	7906                	ld	s2,96(sp)
    8000620e:	69e6                	ld	s3,88(sp)
    80006210:	6a46                	ld	s4,80(sp)
    80006212:	6aa6                	ld	s5,72(sp)
    80006214:	6b06                	ld	s6,64(sp)
    80006216:	7be2                	ld	s7,56(sp)
    80006218:	7c42                	ld	s8,48(sp)
    8000621a:	7ca2                	ld	s9,40(sp)
    8000621c:	7d02                	ld	s10,32(sp)
    8000621e:	6de2                	ld	s11,24(sp)
    80006220:	6109                	addi	sp,sp,128
    80006222:	8082                	ret

0000000080006224 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80006224:	1101                	addi	sp,sp,-32
    80006226:	ec06                	sd	ra,24(sp)
    80006228:	e822                	sd	s0,16(sp)
    8000622a:	e426                	sd	s1,8(sp)
    8000622c:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    8000622e:	0001c497          	auipc	s1,0x1c
    80006232:	df248493          	addi	s1,s1,-526 # 80022020 <disk>
    80006236:	0001c517          	auipc	a0,0x1c
    8000623a:	f1250513          	addi	a0,a0,-238 # 80022148 <disk+0x128>
    8000623e:	ffffb097          	auipc	ra,0xffffb
    80006242:	996080e7          	jalr	-1642(ra) # 80000bd4 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80006246:	10001737          	lui	a4,0x10001
    8000624a:	533c                	lw	a5,96(a4)
    8000624c:	8b8d                	andi	a5,a5,3
    8000624e:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    80006250:	0ff0000f          	fence

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80006254:	689c                	ld	a5,16(s1)
    80006256:	0204d703          	lhu	a4,32(s1)
    8000625a:	0027d783          	lhu	a5,2(a5)
    8000625e:	04f70863          	beq	a4,a5,800062ae <virtio_disk_intr+0x8a>
    __sync_synchronize();
    80006262:	0ff0000f          	fence
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80006266:	6898                	ld	a4,16(s1)
    80006268:	0204d783          	lhu	a5,32(s1)
    8000626c:	8b9d                	andi	a5,a5,7
    8000626e:	078e                	slli	a5,a5,0x3
    80006270:	97ba                	add	a5,a5,a4
    80006272:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80006274:	00278713          	addi	a4,a5,2
    80006278:	0712                	slli	a4,a4,0x4
    8000627a:	9726                	add	a4,a4,s1
    8000627c:	01074703          	lbu	a4,16(a4) # 10001010 <_entry-0x6fffeff0>
    80006280:	e721                	bnez	a4,800062c8 <virtio_disk_intr+0xa4>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80006282:	0789                	addi	a5,a5,2
    80006284:	0792                	slli	a5,a5,0x4
    80006286:	97a6                	add	a5,a5,s1
    80006288:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    8000628a:	00052223          	sw	zero,4(a0)
    wakeup(b);
    8000628e:	ffffc097          	auipc	ra,0xffffc
    80006292:	f3e080e7          	jalr	-194(ra) # 800021cc <wakeup>

    disk.used_idx += 1;
    80006296:	0204d783          	lhu	a5,32(s1)
    8000629a:	2785                	addiw	a5,a5,1
    8000629c:	17c2                	slli	a5,a5,0x30
    8000629e:	93c1                	srli	a5,a5,0x30
    800062a0:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    800062a4:	6898                	ld	a4,16(s1)
    800062a6:	00275703          	lhu	a4,2(a4)
    800062aa:	faf71ce3          	bne	a4,a5,80006262 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    800062ae:	0001c517          	auipc	a0,0x1c
    800062b2:	e9a50513          	addi	a0,a0,-358 # 80022148 <disk+0x128>
    800062b6:	ffffb097          	auipc	ra,0xffffb
    800062ba:	9d2080e7          	jalr	-1582(ra) # 80000c88 <release>
}
    800062be:	60e2                	ld	ra,24(sp)
    800062c0:	6442                	ld	s0,16(sp)
    800062c2:	64a2                	ld	s1,8(sp)
    800062c4:	6105                	addi	sp,sp,32
    800062c6:	8082                	ret
      panic("virtio_disk_intr status");
    800062c8:	00002517          	auipc	a0,0x2
    800062cc:	56050513          	addi	a0,a0,1376 # 80008828 <syscalls+0x3d8>
    800062d0:	ffffa097          	auipc	ra,0xffffa
    800062d4:	26e080e7          	jalr	622(ra) # 8000053e <panic>
	...

0000000080007000 <_trampoline>:
    80007000:	14051073          	csrw	sscratch,a0
    80007004:	02000537          	lui	a0,0x2000
    80007008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000700a:	0536                	slli	a0,a0,0xd
    8000700c:	02153423          	sd	ra,40(a0)
    80007010:	02253823          	sd	sp,48(a0)
    80007014:	02353c23          	sd	gp,56(a0)
    80007018:	04453023          	sd	tp,64(a0)
    8000701c:	04553423          	sd	t0,72(a0)
    80007020:	04653823          	sd	t1,80(a0)
    80007024:	04753c23          	sd	t2,88(a0)
    80007028:	f120                	sd	s0,96(a0)
    8000702a:	f524                	sd	s1,104(a0)
    8000702c:	fd2c                	sd	a1,120(a0)
    8000702e:	e150                	sd	a2,128(a0)
    80007030:	e554                	sd	a3,136(a0)
    80007032:	e958                	sd	a4,144(a0)
    80007034:	ed5c                	sd	a5,152(a0)
    80007036:	0b053023          	sd	a6,160(a0)
    8000703a:	0b153423          	sd	a7,168(a0)
    8000703e:	0b253823          	sd	s2,176(a0)
    80007042:	0b353c23          	sd	s3,184(a0)
    80007046:	0d453023          	sd	s4,192(a0)
    8000704a:	0d553423          	sd	s5,200(a0)
    8000704e:	0d653823          	sd	s6,208(a0)
    80007052:	0d753c23          	sd	s7,216(a0)
    80007056:	0f853023          	sd	s8,224(a0)
    8000705a:	0f953423          	sd	s9,232(a0)
    8000705e:	0fa53823          	sd	s10,240(a0)
    80007062:	0fb53c23          	sd	s11,248(a0)
    80007066:	11c53023          	sd	t3,256(a0)
    8000706a:	11d53423          	sd	t4,264(a0)
    8000706e:	11e53823          	sd	t5,272(a0)
    80007072:	11f53c23          	sd	t6,280(a0)
    80007076:	140022f3          	csrr	t0,sscratch
    8000707a:	06553823          	sd	t0,112(a0)
    8000707e:	00853103          	ld	sp,8(a0)
    80007082:	02053203          	ld	tp,32(a0)
    80007086:	01053283          	ld	t0,16(a0)
    8000708a:	00053303          	ld	t1,0(a0)
    8000708e:	12000073          	sfence.vma
    80007092:	18031073          	csrw	satp,t1
    80007096:	12000073          	sfence.vma
    8000709a:	8282                	jr	t0

000000008000709c <userret>:
    8000709c:	12000073          	sfence.vma
    800070a0:	18051073          	csrw	satp,a0
    800070a4:	12000073          	sfence.vma
    800070a8:	02000537          	lui	a0,0x2000
    800070ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800070ae:	0536                	slli	a0,a0,0xd
    800070b0:	02853083          	ld	ra,40(a0)
    800070b4:	03053103          	ld	sp,48(a0)
    800070b8:	03853183          	ld	gp,56(a0)
    800070bc:	04053203          	ld	tp,64(a0)
    800070c0:	04853283          	ld	t0,72(a0)
    800070c4:	05053303          	ld	t1,80(a0)
    800070c8:	05853383          	ld	t2,88(a0)
    800070cc:	7120                	ld	s0,96(a0)
    800070ce:	7524                	ld	s1,104(a0)
    800070d0:	7d2c                	ld	a1,120(a0)
    800070d2:	6150                	ld	a2,128(a0)
    800070d4:	6554                	ld	a3,136(a0)
    800070d6:	6958                	ld	a4,144(a0)
    800070d8:	6d5c                	ld	a5,152(a0)
    800070da:	0a053803          	ld	a6,160(a0)
    800070de:	0a853883          	ld	a7,168(a0)
    800070e2:	0b053903          	ld	s2,176(a0)
    800070e6:	0b853983          	ld	s3,184(a0)
    800070ea:	0c053a03          	ld	s4,192(a0)
    800070ee:	0c853a83          	ld	s5,200(a0)
    800070f2:	0d053b03          	ld	s6,208(a0)
    800070f6:	0d853b83          	ld	s7,216(a0)
    800070fa:	0e053c03          	ld	s8,224(a0)
    800070fe:	0e853c83          	ld	s9,232(a0)
    80007102:	0f053d03          	ld	s10,240(a0)
    80007106:	0f853d83          	ld	s11,248(a0)
    8000710a:	10053e03          	ld	t3,256(a0)
    8000710e:	10853e83          	ld	t4,264(a0)
    80007112:	11053f03          	ld	t5,272(a0)
    80007116:	11853f83          	ld	t6,280(a0)
    8000711a:	7928                	ld	a0,112(a0)
    8000711c:	10200073          	sret
	...
